#include <iostream>
#include <random>

using namespace std;

int main() {
  random_device
    rd;
  mt19937
    mt(rd());
  uniform_int_distribution<>
    rDis(1,1000000000),
    sDis(1,1000000),
    hDis(1,1000);
    
  cout << rDis(mt) << ' ' << sDis(mt) << ' ' << hDis(mt) << endl;
  
  return 0;
}

