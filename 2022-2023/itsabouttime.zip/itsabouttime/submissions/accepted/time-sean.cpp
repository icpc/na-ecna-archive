#include <iostream>
#include <cmath>

using namespace std;

int main(){
  int r,s,h;
  cin >> r >> s >> h;

  double circumference = 2.0*M_PI*r;
  double hpy = circumference/s;
  double dpy = hpy/h;

  // cout << "days per year: " << dpy << endl;
    double days = round(dpy);
    int best_n1 = -1;
    int best_n2 = -1;
    int best_n3 = -1;
    double best_difference = dpy;
    for(int n1 = 2; n1 <= 1000; n1++)
      for(int n2 = 2*n1; n2 <= 1000; n2+=n1)
	for(int n3 = 2*n2; n3 <= 1000; n3+=n2){
	  days = round(dpy);
	  //	  cout << n1 << " " << n2 << " " << n3;
	  if(round(dpy) < dpy){ // round down
	    days = days + 1.0/n1 -1.0/n2 + 1.0/n3;
	  }
	  else
	    days = days - 1.0/n1 + 1.0/n2 - 1.0/n3;
	  //  cout << " " << days << endl;
	  double diff = abs(days-dpy);
	  if(diff < best_difference){
	    //	    cout << "New best: " << n1 << " " << n2 << " " << n3 << " " << days <<endl;
	    best_difference = diff;
	    best_n1 = n1;
	    best_n2 = n2;
	    best_n3 = n3;
	  }

	}
    cout << best_n1 << " " << best_n2 << " " << best_n3   << endl;
    return 0;
}
  
    
