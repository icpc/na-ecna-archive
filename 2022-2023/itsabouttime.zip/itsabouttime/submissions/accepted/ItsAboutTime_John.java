import java.util.Scanner;

public class ItsAboutTime_John {

	public static final int PERIOD = 1000;
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		long r, s, h;
		
		r = in.nextLong();
		s = in.nextLong();
		h = in.nextLong();
		double tropicalYear = (2*Math.PI*r)/s/h;
//		tropicalYear = 365.24219;
		long d = (long)(tropicalYear + 0.5);
		
		int save1=0, save2=0, save3=0;
		double bestDiff = 2*tropicalYear;
		if (d < tropicalYear) {
			for(int n1=2; n1<=PERIOD/4; n1++) {
				for(int n2 = 2*n1; n2 <= PERIOD/2; n2 += n1) {
					for(int n3 = 2*n2; n3 <= PERIOD; n3 += n2) {
						double diff = Math.abs(tropicalYear - (d + 1.0/n1 - 1.0/n2 + 1.0/n3));
						if (diff < bestDiff) {
							bestDiff = diff;
							save1 = n1;
							save2 = n2;
							save3 = n3;
						}
					}
				}
			}
		}
		else {
			for(int n1=2; n1<=PERIOD/4; n1++) {
				for(int n2 = 2*n1; n2 <= PERIOD/2; n2 += n1) {
					for(int n3 = 2*n2; n3 <= PERIOD; n3 += n2) {
						double diff = Math.abs(tropicalYear - (d - 1.0/n1 + 1.0/n2 - 1.0/n3));
						if (diff < bestDiff) {
							bestDiff = diff;
							save1 = n1;
							save2 = n2;
							save3 = n3;
						}
					}
				}
			}
		}
		
		System.out.println(save1 + " " + save2 + " " + save3);

	}

}
