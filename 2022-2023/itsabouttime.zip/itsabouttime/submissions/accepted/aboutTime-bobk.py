#!/usr/bin/python3

(r, s, h) = map(int, input().split(' '))

distance = r * 2 * 3.141592653589793238

tropYearHours = distance / s

tropYear = tropYearHours / h

tropYearFrac = tropYear - int(tropYear)

error = 1.0
best = [0, 0, 0]

if tropYearFrac >= 0.5:
    tropYearFrac = 1.0 - tropYearFrac

for n1 in range(2, 251):
    m2 = 1
    while n1 * (m2 + 1) <= 500:
        m2 += 1
        m3 = 1
        while n1 * m2 * (m3 + 1) <= 1000:
            m3 += 1
            nLeapDays = (m2 - 1) * m3 + 1
            if abs(nLeapDays / (n1 * m2 * m3) - tropYearFrac) < error:
                error = abs(nLeapDays / (n1 * m2 * m3) - tropYearFrac)
                best = [n1, n1 * m2, n1 * m2 * m3]

print(best[0], best[1], best[2])
