#include <iostream>
#include <cmath>

using namespace std;

int main() {
    uint32_t
        r,s,h,
        best[3];
    double
        dist,
        tyHours,
        tYear,
        tYearFrac,
        error = 1.0,
        nLeapDays;

    cin >> r >> s >> h;

    dist = r * 2.0 * M_PI;
    tyHours = dist / s;
    tYear = tyHours / h;
    tYearFrac = tYear - (int64_t)(tYear);

    if (tYearFrac >= 0.5)
        tYearFrac = 1.0 - tYearFrac;

    for (int n1=2;n1<=250;n1++)
        for (int m2=2;n1*m2<=500;m2++)
            for (int m3=2;n1*m2*m3<=1000;m3++) {
                nLeapDays = (m2 - 1) * m3 + 1.0;
                if (fabs(nLeapDays / (n1 * m2 * m3) - tYearFrac) < error) {
                    error = fabs(nLeapDays / (n1 * m2 * m3) - tYearFrac);
                    best[0] = n1;
                    best[1] = n1 * m2;
                    best[2] = n1 * m2 * m3;
                }
            }

    cout << best[0] << ' ' << best[1] << ' ' << best[2] << endl;
    
    return 0;
}
