#!/usr/bin/python3

(r, s, h) = map(int, input().split(' '))

distance = r * 2 * 3.141592653589793238

tropYearHours = distance / s

tropYear = tropYearHours / h

tropYearFrac = tropYear - int(tropYear)

error = 1.0
best = [0, 0, 0]

if tropYearFrac >= 0.5:
    tropYearFrac = 1.0 - tropYearFrac

for n1 in range(2,1001):
    for n2 in range(1,1001):
        for n3 in range(1,1001):
            if n2 % n1 != 0 or n3 % n2 != 0:
                continue
            nLeapDays = (n2//n1 - 1) * n3//n2 + 1
            if abs(nLeapDays / n3 - tropYearFrac) < error:
                error = abs(nLeapDays / n3 - tropYearFrac)
                best = [n1, n2, n3]

print(best[0], best[1], best[2])
