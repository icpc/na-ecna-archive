#!/usr/bin/env python3

for i in range(1000000):
    print(i)
    print('hello')
