#!/usr/bin/env python3

for i in range(100):
    print(chr(i * 10))
