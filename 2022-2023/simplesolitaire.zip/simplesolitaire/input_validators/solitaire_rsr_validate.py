import sys

#for r in ['A','2','3','4','5','6','7','8','9','T','J','Q','K']:
#  for s in ['C','D','H','S']:
#    cards.append(r+s)
#cards.sort()

cards = ['2C', '2D', '2H', '2S', '3C', '3D', '3H', '3S', '4C', '4D', '4H', '4S', '5C', '5D', '5H', '5S', '6C', '6D', '6H', '6S', '7C', '7D', '7H', '7S', '8C', '8D', '8H', '8S', '9C', '9D', '9H', '9S', 'AC', 'AD', 'AH', 'AS', 'JC', 'JD', 'JH', 'JS', 'KC', 'KD', 'KH', 'KS', 'QC', 'QD', 'QH', 'QS', 'TC', 'TD', 'TH', 'TS']

inp = sys.stdin.readline().split()
if len(inp) != 13: sys.exit(43)
inp.extend(sys.stdin.readline().split())
if len(inp) != 26: sys.exit(43)
inp.extend(sys.stdin.readline().split())
if len(inp) != 39: sys.exit(43)
inp.extend(sys.stdin.readline().split())
if len(inp) != 52: sys.exit(43)

inp.sort()
if inp == cards:
  sys.exit(42)
else:
  sys.exit(43)
