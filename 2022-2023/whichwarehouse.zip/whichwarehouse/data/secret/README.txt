small1 - 1 node, 1 product
small2 - 2 nodes, 1 product at 1 node
small3 - 2 nodes, 1 product at 2 nodes, different amounts, same edge weights
small4 - 2 nodes, 1 product at 2 nodes, same amounts, different edge weights
small5,6 - 2 nodes, 2 products

large1,2 - two 100x100,100 products

single1 - complete 15 node graph, one product A throughout
single2 - same, but second product B at node where A ends up in single1; B must move
single3 - same, but second product B at node where A ends up in single1; A must move

allmove1 - 3x3 grid, all 4 products move from where they are
allmove2 - 30x30 grid, 1 product at all nodes except node 10, all move to 10

linear1 - 10 nodes in a row, all products in node 0
linear2 - 10 nodes in a row, all products in node 9
linear2 - 11 nodes in a row, all products in node 5, different distances from 5 to other nodes

special1 - complete graph, 3 nodes, cheapest move not in optimal solution
special2 - complete graph, 4 nodes, most expensive move in optimal solution

