#include <iostream>

using namespace std;

const uint32_t
    MAX_DEPTS = 1000000,
    MAX_SUBS = 100;

int32_t
    nDepts;

string
    deptList[MAX_DEPTS],
    line;

#pragma clang diagnostic push
#pragma ide diagnostic ignored "misc-no-recursion"
uint32_t parse(uint32_t pos) {
    string
        dept;
    int32_t
        nSubs;

    // skip leading whitespace
    while (pos < line.length() && isspace(line[pos]))
        pos++;

    // should have a number here
    if (pos == line.length() || !isdigit(line[pos]))
        exit(1);

    dept = "";
    while (pos < line.length() && isdigit(line[pos])) {
        dept += line[pos];
        pos++;
    }

    // check to make sure we don't have too many departments, add if okay
    if (nDepts == MAX_DEPTS)
        exit(2);

    deptList[nDepts++] = dept;
    if (dept.length() > 1 && dept[0] == '0')
        exit(6);

    // skip whitespace
    while (pos < line.length() && isspace(line[pos]))
        pos++;

    // process subordinate departments
    for (nSubs=0;nSubs < MAX_SUBS;nSubs++) {
        // if we reach the end, or see a ), we're done
        if (pos == line.length() || line[pos] == ')')
            return pos;

        // if we see a (, skip, recurse and eat the following )
        if (line[pos] == '(') {
            pos++;
            pos = parse(pos);

            // eat whitespace before )
            while (pos < line.length() && isspace(line[pos]))
                pos++;
            // make sure there's a ) there
            if (pos == line.length() || line[pos] != ')')
                exit(3);

            // eat any trailing whitespace
            while (pos < line.length() && isspace(line[pos]))
                pos++;
        }
    }

    // if next char is (, then there are too many subordinate departments
    if (pos < line.length() && line[pos] == '(')
        exit(4);

    // all done
    return pos;
}
#pragma clang diagnostic pop

int main() {

    nDepts = 0;
    getline(cin,line);
    parse(0);

    nDepts = 0;
    getline(cin, line);
    parse(0);

    getline(cin,line);
    if (cin)
        exit(5);

    return 42;
}
