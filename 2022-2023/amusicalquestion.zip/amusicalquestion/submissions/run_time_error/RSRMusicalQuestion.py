#!/usr/bin/env python3
import sys
try:
  (c,n) = map(int,sys.stdin.readline().split())
  a = [0]
  a.extend(list(map(int,sys.stdin.readline().split())))
  #print(a)
  used = [[[False for i in range(c+1)] for j in range(c+1)] for k in range(n+1)]
  m = 0
  used[0][0][0] = True
  for i in range(1,n+1):
    for j in range(c+1):
      for k in range(c+1):
        #used[i][j][k] = used[i-1][j][k] # can we just ignore a[i]?
        used[i][j][k] = used[i-1][j][k] or (j-a[i] >= 0 and used[i-1][j-a[i]][k]) or (k-a[i] >= 0 and used[i-1][j][k-a[i]])
        if used[i][j][k]:
          m = max(m,j+k)
  """
  for i in range(n+1):
    print(f'i = {i}:')
    for j in range(c+1):
      for k in range(c+1):
        print(f'{used[i][j][k]:6}',end='')
      print()
  """
  
  #print("max:",m)
  j = min(c,m)
  #print("j:",j)
  (x,y) = (0,m)
  diff = m
  for i in range(m-j,j+1):
  #  print(f"i: {i}, m-i: {m-i}")
  #  for k in range(n+1):
  #   print()
  #    print("k:",k,"m-i:",m-k)
    if used[n][i][m-i] and abs(m-2*i) < diff:
      diff = abs(m-2*i)
  #    print("diff:",diff)
      (x,y) = (i,m-i)
  print(max(x,y),min(x,y))
except:
  pass
