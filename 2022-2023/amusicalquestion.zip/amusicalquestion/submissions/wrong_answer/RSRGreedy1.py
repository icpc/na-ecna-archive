# Greedy 1: scan the list of times, placing a time into bin1 if there is room.
# Repeat with the remaining times for bin2.
# Try to balance with swapping
# Print largest first

import sys
[c,n] = list(map(int,sys.stdin.readline().split()))
t = list(map(int,sys.stdin.readline().split()))
bin1 = []
b1 = 0
leftover=[]
i = 0
while i < n and b1 < c:
  if b1+t[i] <= c:
     bin1.append(t[i])
     b1 += t[i]
  else:
     leftover.append(t[i])
  i += 1
while i < n:
   leftover.append(t[i])
   i += 1

bin2 = []
b2 = 0
i = 0
while i < len(leftover) and b2 < c:
  if b2+leftover[i] <= c:
     bin2.append(leftover[i])
     b2 += leftover[i]
  i += 1

# Try to minimize time diff by swapping
for i in range(len(bin1)):
  for j in range(len(bin2)):
    diff = abs(b1-b2)
    t1 = bin1[i]
    t2 = bin2[j]
    s1 = b1-t1+t2
    s2 = b2-t2+t1
    if s1 <=c and s2 <= c and abs(s1-s2) < diff: #swap
      bin1 = bin1[:i]+[t2]+bin1[i+1:]
      b1 = b1-t1+t2
      in2 = bin2[:j]+[t1]+bin2[j+1:]
      b2 = b2-t2+t1
      diff = abs(s1-s2)


# can we move anything from bin1 to bin2?
i=0
while i < len(bin1):
  diff = abs(b1-b2)
  t1 = bin1[i]
  s1 = b1-t1
  s2 = b2+t1
  if s2 <= c and abs(s1-s2) < diff: 
    bin1 = bin1[:i]+bin1[i+1:]
    b1 -= t1
    b2 += t1
    bin2.append(t1)
    diff = abs(b1-b2)
  else:
    i += 1
    
print(max(b1,b2),min(b1,b2))
