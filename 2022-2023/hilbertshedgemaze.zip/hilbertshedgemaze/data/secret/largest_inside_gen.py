print(100)
for i in range(1,51):
    print(f"{i} 0 {2**i - 2} {2**(i-1)} {2**(i-1) - 2}")
    print(f"{i} 0 {2**i - 2} {2**(i-1) + 1} {2**(i-1) - 2}")

