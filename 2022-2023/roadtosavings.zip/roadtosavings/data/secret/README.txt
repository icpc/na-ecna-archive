001-003: three smallest cases
004: largest case (100 vertex, complete graph)
005: 40, complete, one shortest path
006: 40, complete, two shortest paths
007: 40, complete, all edges equal
008: case where largest cost edges are only ones paved
009: case where all edges are paved
010: same as 009, but edge beween 1 and 2 not paved
011-020: random cases, 60-100 vertices, edge weights 1,2,3
021: smallest unconnected case
022: home, office disconnected from rest of graph
023: odd vertices connect, even vertices connected