#include <iostream>
using namespace std;

void sort(int a[], int length)
{
    for(int i=1; i<length; i++) {
        int sav = a[i];
        int j=i;
        while (j > 0 && a[j-1] > sav) {
            a[j] = a[j-1];
            j--;
        }
        a[j] = sav;
    }
}

int main()
{
    int team1[5];
    int team2[5];
    int icase = 0;

    for(int i=0; i<5; i++)
        cin >> team1[i];
    for(int i=0; i<5; i++)
        cin >> team2[i];
    sort(team1, 5);
    sort(team2, 5);
    int count = 0;
    for(int i=0; i<5; i++)
        if (team1[i] > team2[i])
            count++;
    cout << count << endl;
}
