#include <iostream>
#include <vector>

using namespace std;
void Sort(vector<int>& v){
  for(int i = 0; i < v.size(); i++)
    for(int j = 0; j < v.size()-1; j++){
      if(v[j] < v[j+1]){
	int temp = v[j];
	v[j] = v[j+1];
	v[j+1] = temp;
      }
    }
}


int main(){
  vector <int> us(5);
  vector <int> them(5);

  for(int i = 0; i < 5; i++){
    cin >> us[i];
  }

  for(int i = 0; i < 5; i++){
    cin >>them[i];
  }

  Sort(us);
  Sort(them);

  int total = 0;
  for(int i = 0; i< 5; i++)
    if(us[i] > them[i])
      total++;

  cout << total << endl;
  return 0;
}
