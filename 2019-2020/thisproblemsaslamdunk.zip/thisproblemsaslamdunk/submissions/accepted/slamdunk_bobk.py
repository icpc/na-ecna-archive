#!/usr/bin/pypy

l1 = map(int,raw_input().split())
l2 = map(int,raw_input().split())

l1.sort()
l2.sort()

n = 0
for i in xrange(5):
    if l1[i] > l2[i]:
        n += 1

print n
