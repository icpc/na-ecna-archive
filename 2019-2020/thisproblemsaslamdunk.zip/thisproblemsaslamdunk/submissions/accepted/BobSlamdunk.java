// Solution to "This Problem's a Slam Dunk"

import java.util.*;

public class BobSlamdunk {
  public static Scanner in;
  public static int[] su,us;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    casenum = 0;
      su = new int[5];
      us = new int[5];
      for (int i = 0; i < 5; i++)
        su[i] = in.nextInt();
      for (int i = 0; i < 5; i++)
        us[i] = in.nextInt();
      Arrays.sort(us);
      Arrays.sort(su);
      int count = 0;
      for (int i = 0; i < 5; i++)
        if (su[i] > us[i]) count++;
      System.out.println(count);
  }
}
