#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[]){
//  ifstream fin;
//  fin.open(argv[1]);

//  if(!fin.is_open()){
//    cout << "Error- cannor open file" << endl;
//    exit(1);
//  }

  int n;
  cin >> n;
  if(n < 2){
    cout << "Error- n too small" << endl;
    exit(1);
  }
  if(n > 10000){
    cout << "Error- n too large" << endl;
    exit(1);
  }

  for(int i = 0; i < n; i++){

    int cur;
    cin >> cur;
    if(!cin){
      cout << "Error- ran out of input instances" << endl;
      exit(1);
    }
    if(cur < 2){
      cout << "Error- opus " << cur << " too small " << endl;
      exit(1);
    }
    if(cur > 1000000){
      cout << "Error- opus " << cur << " too large " << endl;
      exit(1);
    }
  }
  cout << "OK" << endl;
  return 42;
}
