#include <iostream>
using namespace std;

const int MAXP = 10000;

int profs[MAXP];
long opusNums[MAXP];
int nprofs;

void printProfs()
{
    for(int i=0; i<nprofs; i++)
        if (profs[i] != -1) cout << profs[i] << ' ';
    cout << endl;
}

int main()
{
    cin >> nprofs;
    for(int i=0; i<nprofs; i++) {
        cin >> opusNums[i];
        profs[i] = i+1;
    }
    int curr = 0;
    int numThere = nprofs;
    while (numThere > 1) {
//printProfs();
        int count = opusNums[curr]-1;
        for(int i=0; i<count; i++) {
            curr++;
            if (curr == nprofs)
                curr = 0;
            if (profs[curr] == -1)
                i--;
        }
        profs[curr] = -1;
        numThere--;
        while (profs[curr] == -1) {
            curr++;
            if (curr == nprofs)
                curr = 0;
        }
    }
    int i=0;
    while (profs[i] == -1)
        i++;
    cout << profs[i] << endl;
}
