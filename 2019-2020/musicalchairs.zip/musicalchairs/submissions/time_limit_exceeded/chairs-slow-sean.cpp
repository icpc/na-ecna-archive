#include <iostream>
#include <vector>

using namespace std;

struct person{
  int opus;
  int orig_pos;
};

int main(){
  int n;
  cin >> n;
  vector<person> numbers(n);
  for(int i = 0; i < n; i++){
    cin >> numbers[i].opus;
    numbers[i].orig_pos = i+1;
  }
  int cur_number = numbers[0].opus;
  int num_alive = n;
  int cur_elim = 0;
  while(numbers.size() > 1){
    for(int i = 0; i < cur_number-1; i++){
      cur_elim++;
      if(cur_elim >= num_alive)
	cur_elim = 0;
    }
      
   
    if(cur_elim == -1)
      cur_elim = numbers.size()-1;
    cur_number = numbers[(cur_elim+1)%num_alive].opus;
    numbers.erase(numbers.begin()+cur_elim);
    num_alive--;
    if(cur_elim >= numbers.size())
      cur_elim = 0;
      
    // cout << "Removing " << cur_elim << endl;
  }
  cout << numbers[0].orig_pos << endl;
  return 0;
}
    
