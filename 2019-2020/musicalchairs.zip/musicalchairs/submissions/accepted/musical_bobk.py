#!/usr/bin/python

profNums = []

nProfs = int(raw_input())
#nProfs = 10000
for i in xrange(nProfs):
    profNums.append(i)

favorites = map(int,raw_input().split())
#favorites = [1] * 10000

cur = 0
while nProfs > 1:
    cur = (cur + favorites[cur] - 1) % nProfs
#    profNums[cur:nProfs-1] = profNums[cur+1:]
#    favorites[cur:nProfs-1] = favorites[cur+1:]
    for i in xrange(cur,nProfs-1):
        profNums[i] = profNums[i+1]
        favorites[i] = favorites[i+1]
    nProfs -= 1
    cur %= nProfs

print profNums[0] + 1
