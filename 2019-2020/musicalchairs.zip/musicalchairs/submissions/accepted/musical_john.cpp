#include <iostream>
using namespace std;

const int MAXP = 10000;

int profs[MAXP];
long opusNums[MAXP];
int nprofs;

void printProfs()
{
    for(int i=0; i<nprofs; i++)
        cout << profs[i] << ' ';
    cout << endl;
}

int main()
{
    cin >> nprofs;
    for(int i=0; i<nprofs; i++) {
        cin >> opusNums[i];
        profs[i] = i+1;
    }
    int curr = 0;
    while (nprofs > 1) {
//printProfs();
        int nextOut = (curr + opusNums[curr] - 1)%nprofs;
        for(int i=nextOut+1; i<nprofs; i++) {
            opusNums[i-1] = opusNums[i];
            profs[i-1] = profs[i];
        }
        nprofs--;
        curr = nextOut%nprofs;
    }
    cout << profs[0] << endl;
}
