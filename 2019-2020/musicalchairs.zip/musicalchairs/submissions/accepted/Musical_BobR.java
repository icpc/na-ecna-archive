// Solution to "Musical Chairs"

import java.util.*;

class Pair { // each pair represents a professor's opus number (o) and
             // professor number (i)
  public Integer o,i;
  public Pair(int o, int i) {
    this.o = o; this.i = i;
  }
}

public class Musical_BobR {
  public static Scanner in;
  public static int n; // number of faculty
  public static ArrayList<Pair> op; // list of opus numbers, one per faculty

  public static void main(String[] args) {
    in = new Scanner(System.in);
    n = in.nextInt();
    op = new ArrayList<Pair>();
    for (int i = 0; i < n; i++) {
      op.add(new Pair(in.nextInt(),i+1)); // faculty numbered 1..n
    }
    int next = 0; // position of next person in line
    for (int i = 0; i < n-1; i++) { // i counts number of rounds needed
      // get the next op value:
      next = next%(n-i); // if next is >= line length, back to 0
      Pair v = op.get(next);
      int r = (v.o-1+next)%(n-i); // since v can be large, don't just count
      op.remove(r);
      next = r;
    }
    System.out.println(op.get(0).i);
  } 

  // For debugging:
  public static void display() {
    for (Pair i:op) {
      System.out.print("("+i.o+","+i.i+") ");
    }
    System.out.println();
  }
}
