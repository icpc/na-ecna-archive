// Solution to Hardware Sales

import java.util.*;

class BobItem {
  public String number; // 6-digit id
  public int[] sold; // # sold in each store
  public int index; // time of first occurrence
  public BobItem(String number, int i) {
    this.number = number;
    index = i;
    sold = new int[3];
  }
}


public class BobHardware {
  public static Scanner in;
  public static int[] n;
  public static HashMap<String,BobItem> count;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    n = new int[3];
    int index = 0;
    casenum = 0;
      n[0] = in.nextInt();
      n[1] = in.nextInt();
      n[2] = in.nextInt();
      count = new HashMap<String,BobItem>();
      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < n[i]; j++) {
          String id = in.next();
          int c = in.nextInt();
          BobItem it = count.get(id);
          if (it == null) {
            it = new BobItem(id,index++);
            count.put(id,it);
          }
          it.sold[i] += c;
        }
      }
      // pull out all items that have sold[i] >= 20 for i = 0,1,2:
      ArrayList<BobItem> keep = new ArrayList<BobItem>();
      for (BobItem it: count.values()) {
        if (it.sold[0] >= 20 && it.sold[1] >= 20 && it.sold[2] >= 20)
          keep.add(it);
      }
      keep.sort(new Comparator<BobItem>() {
                     public int compare(BobItem i1, BobItem i2) {
                       return i1.index - i2.index;
                     }
                });
      System.out.print(keep.size());
      for (BobItem it : keep) {
        System.out.print(" "+it.number);
      }
      System.out.println();
  }
}
