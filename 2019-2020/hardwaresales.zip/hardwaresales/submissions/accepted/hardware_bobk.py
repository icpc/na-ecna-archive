#!/usr/bin/pypy

def process(sales):
    global outList

    items = []

    for i in xrange(0,len(sales),2):
        inList = False
        for j in xrange(len(items)):
            if sales[i] == items[j][0]:
                items[j][1] += int(sales[i+1])
                inList = True
        if not inList:
            items.append([sales[i],int(sales[i+1])])

    for i in items:
        if i[1] >= 20:
            inList = False
            for j in xrange(len(outList)):
                if outList[j][0] == i[0]:
                    outList[j][1] += 1
                    inList = True
            if not inList:
                outList.append([i[0],1])

(n1,n2,n3) = map(int,raw_input().split())

list1 = raw_input().split()
list2 = raw_input().split()
list3 = raw_input().split()

outList = []

process(list1)
process(list2)
process(list3)

i = 0
while i < len(outList):
    if outList[i][1] != 3:
        del outList[i]
    else:
        i += 1

print len(outList),
for item in outList:
    print item[0],
print
