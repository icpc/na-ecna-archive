#include <iostream>
#include <cstdio>
using namespace std;

const int MAX = 1000;

int ids[3*MAX];
int numIds;
int numSold[3][3*MAX];    // numSold[i][j] = number of units store i sold of item j
int numSold20[MAX];       // items which sold 20 or more in each store

int find(int id)
{
    for(int i=0; i<numIds; i++)
        if (ids[i] == id)
            return i;
    ids[numIds++] = id;                       // first time we've seen this id
    return numIds-1;
}

void processStoreList(int s, int num)
{
    int id, nsold;
    for(int i=0; i<num; i++) {
        cin >> id >> nsold;
        int index = find(id);
        numSold[s][index] += nsold;
    }
}

int main()
{
    int s1, s2, s3, icase=0;

    cin >> s1 >> s2 >> s3;
    numIds = 0;
    for(int i=0; i<s1+s2+s3; i++)
        numSold[0][i] = numSold[1][i] = numSold[2][i] = 0;
    processStoreList(0, s1);
    processStoreList(1, s2);
    processStoreList(2, s3);

    int count = 0;
    for(int i=0; i<numIds; i++) {
        if (numSold[0][i] >= 20 && numSold[1][i] >= 20 && numSold[2][i] >= 20) {
            numSold20[count] = ids[i];
            count++;
        }
    }

    cout << count;
    for(int i=0; i<count; i++)
        printf(" %06d", numSold20[i]);
    cout << endl;

}
