#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct item{
  string id;
  int quantity1;
  int quantity2;
  int quantity3;
};

int Find(vector<item>& v, string id){
  for(int i = 0; i < v.size(); i++)
    if(v[i].id == id)
      return i;

  return -1;
}
      
int main(){
  vector<item> item_list;

  int n1,n2,n3;
  cin >> n1 >> n2 >> n3;

 
  vector<int> valid(n1, 0);
 
  for(int i = 0; i < n1; i++){
    string id;
    int quantity;
    cin >> id >> quantity;
    int pos = Find(item_list, id);
    if(pos != -1){
      item_list[pos].quantity1 += quantity;
    }
    else{
      item new_item;
      new_item.id = id;
      new_item.quantity1 = quantity;
      new_item.quantity2 = 0;
      new_item.quantity3 = 0;
      item_list.push_back(new_item);
    }
  }

  for(int i = 0; i < n2; i++){
    string id;
    cin >> id;
    int quantity;
    cin >> quantity;
    int pos = Find(item_list, id);
    if(pos != -1)
      item_list[pos].quantity2 += quantity;
    
  }
  for(int i = 0; i < n3; i++){
     string id;
     cin >> id;
     int quantity;
     cin >> quantity;
     int pos = Find(item_list, id);
     if(pos != -1)
       item_list[pos].quantity3 += quantity;
  }

  int num_valid = 0;
  for(int i = 0; i < item_list.size(); i++){
    if(item_list[i].quantity1 >= 20 && item_list[i].quantity2 >= 20 &&
       item_list[i].quantity3 >= 20)
      num_valid++;
  }
  cout << num_valid << " ";
  for(int i = 0; i < item_list.size(); i++){
    if(item_list[i].quantity1 >= 20 && item_list[i].quantity2 >= 20 &&
       item_list[i].quantity3 >= 20)
      cout << item_list[i].id << " ";
    
  }
  cout << endl;
  
  
  return 0;
}
