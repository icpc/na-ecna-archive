#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main(){
  int l,h,p,e,n;
  cin >> l >> h >> p >> e >> n;

  int lab_num = 0;
  int lab_den = 0;
  int hw_num = 0;
  int hw_den = 0;
  int proj_num = 0;
  int proj_den = 0;
  int exam_num = 0;
  int exam_den = 0;
  

  for(int i = 0; i < n; i++){
    string type;
    cin >> type; // the number and the colon
    string junk;
    cin >> junk;
    int num,den;
    char slash;
    cin >> num >> slash >> den;
    if(type == "Lab"){
      lab_num = lab_num + num;
      lab_den = lab_den + den;
    }
    else if(type == "Hw"){
      hw_num = hw_num + num;
      hw_den = hw_den + den;
    }
    else if(type == "Proj"){
      proj_num = proj_num + num;
      proj_den = proj_den + den;
    }
    else if(type == "Exam"){
      exam_num = exam_num + num;
      exam_den = exam_den + den;
    }
    else{
      cout << "Illegal category: " << type << endl;
    }
  }
  double lab_grade = (double)lab_num/(double)lab_den;
  double hw_grade = (double) hw_num/(double)hw_den;
  double proj_grade = (double) proj_num/(double) proj_den;
  double exam_grade = (double) exam_num/(double) exam_den;

  double percentage = lab_grade * l + hw_grade * h + proj_grade * p + exam_grade * e;
  cout << floor(percentage) << endl;
  return 0;
}

    
				 
  
