#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
    int labp, hwp, projp, examp, np;
    int icase=0;

    cin >> labp >> hwp >> projp >> examp >> np;
        double labAchieved=0, labTotal=0;
        double hwAchieved=0, hwTotal=0;
        double projAchieved=0, projTotal=0;
        double examAchieved=0, examTotal=0;
        for(int i=0; i<np; i++) {
            string type, num, grade;
            cin >> type;       // type of assignment
            cin >> num;        // assignment number, ignored
            cin >> grade;      // score + '/' + maxscore
            int index = grade.find("/");
            int score = atoi(grade.substr(0, index).c_str());
            int maxScore = atoi(grade.substr(index+1).c_str());
            if (type == "Lab") {
                labAchieved += score;
                labTotal += maxScore;
            }
            else if (type == "Hw") {
                hwAchieved += score;
                hwTotal += maxScore;
            }
            else if (type == "Proj") {
                projAchieved += score;
                projTotal += maxScore;
            }
            else if (type == "Exam") {
                examAchieved += score;
                examTotal += maxScore;
            }
            else {
                cerr << "ERROR: invalid type " << type << endl;     // should never happen
                exit(-1);
            }
        }
        double finalPercent = labp*(labAchieved/labTotal)
                                + hwp*(hwAchieved/hwTotal)
                                + projp*(projAchieved/projTotal)
                                + examp*(examAchieved/examTotal);
        cout << (int)finalPercent << endl;
}
