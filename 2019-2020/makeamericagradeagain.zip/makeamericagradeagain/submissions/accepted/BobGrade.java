// Solution to Make America Grade Again

import java.util.*;
//import java.util.regex.*;

public class BobGrade {
  public static int l,h,p,e,n;
  public static int lr,hr,pr,er, ls,hs,ps,es;
  public static Scanner in;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    casenum = 0;
    l = in.nextInt();
    h = in.nextInt();
    p = in.nextInt();
    e = in.nextInt();
    n = in.nextInt();

    lr=hr=pr=er=ls=hs=ps=es=0;
    for (int i = 0; i < n; i++) {
    String cat = in.next();
    String ignore = in.next();
    String temp[] =in.next().split("/");
    int r = Integer.parseInt(temp[0]);
    int s = Integer.parseInt(temp[1]);
    switch(cat) {
      case "Exam": er+=r; es+=s; break;
      case "Hw": hr+=r; hs+=s; break;
      case "Proj": pr+=r; ps+=s; break;
      case "Lab": lr+=r; ls+=s; break;
    }
    }
    if (ls==0) ls=1;
    if (es==0) es=1;
    if (ps==0) ps=1;
    if (hs==0) hs=1;
    int grade = (int)(h*1.0*hr/hs+e*1.0*er/es+l*1.0*lr/ls+p*1.0*pr/ps);
    System.out.println(grade);
  }
}
