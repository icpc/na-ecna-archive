#!/usr/bin/pypy

(l,h,p,e,n) = map(int,raw_input().split())

lNum = 0
lDen = 0
hNum = 0
hDen = 0
pNum = 0
pDen = 0
eNum = 0
eDen = 0

for i in xrange(n):
    (cat,num,score) = raw_input().split()
    (num,den) = map(int,score.split('/'))

    if cat == "Lab":
        lNum += num
        lDen += den
    if cat == "Hw":
        hNum += num
        hDen += den
    if cat == "Proj":
        pNum += num
        pDen += den
    if cat == "Exam":
        eNum += num
        eDen += den

M = lDen * hDen * pDen * eDen

num = l * lNum * M / lDen + h * hNum * M / hDen + p * pNum * M / pDen + e * eNum * M / eDen

print num // M
