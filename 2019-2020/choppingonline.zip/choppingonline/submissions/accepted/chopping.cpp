#include<iostream>
#include <cmath>
#include <cstdio>
using namespace std;

class Point
{
public:
    double px, py;

    Point(double x=0, double y=0)
    {
        px = x;
        py = y;
    }
};

class TU
{
public:
     double t, u;
};

class Line
{
public:
    Point p1, p2;
    double dx, dy;

    Line(int p1x, int p1y, int p2x, int p2y)
    {
        p1.px = p1x;
        p1.py = p1y;
        p2.px = p2x;
        p2.py = p2y;
        dx = p2x-p1x;
        dy = p2y-p1y;
    }

    bool isParallel(Line l)
    {
        return (l.dx*dy == l.dy*dx);
    }

    TU* intersection(Line l)
    {
        if (isParallel(l))
            return 0;
        TU *retval = new TU();
        double den = l.dx*dy - l.dy*dx;
        double ddx = l.p1.px - p1.px;
        double ddy = l.p1.py - p1.py;
        retval->t = (l.dx*ddy - l.dy*ddx)/den;
        retval->u = (ddy*dx - ddx*dy)/den;
        return retval;
    }

    Point* calcPoint(double t)
    {
        return new Point(p1.px + dx*t, p1.py + dy*t);
    }
};

Line *lines[7];     // 4 edges of sheet and 3 cuts

double getLength(int numLines)
{
    Line l = *(lines[numLines]);
    double tlow = -1000.0;
    double thigh = 1000.0;
    for(int i=0; i<numLines; i++) {
        TU *ans = l.intersection(*(lines[i]));
        if (ans == 0)
            continue;
        if (ans->t <= 0.0 && ans->t > tlow)
            tlow = ans->t;
        else if (ans->t >= 1.0 && ans->t < thigh)
            thigh = ans->t;
    }
    Point *p1 = l.calcPoint(tlow);
    Point *p2 = l.calcPoint(thigh);
    double dx = p1->px-p2->px;
    double dy = p1->py-p2->py;
    return sqrt(dx*dx + dy*dy);
}

double calcDist(int ax, int ay, int bx, int by, int cx, int cy)
{
    lines[4] = new Line(ax, ay, bx, by);
    double length = getLength(4);
    lines[5] = new Line(bx, by, cx, cy);
    length += getLength(5);
    lines[6] = new Line(cx, cy, ax, ay);
    length += getLength(6);
    return length;
}

int main()
{
    int w, h, icase=0;
    int t1x, t1y, t2x, t2y, t3x, t3y;

    cin >> w >> h;
    lines[0] = new Line(0, 0, w, 0);
    lines[1] = new Line(w, 0, w, h);
    lines[2] = new Line(w, h, 0, h);
    lines[3] = new Line(0, h, 0, 0);
    cin >> t1x >> t1y >> t2x >> t2y >> t3x >> t3y;

    double bestDist = calcDist(t2x, t2y, t1x, t1y, t3x, t3y);
    int bestOrder = 0;
    double dist = calcDist(t1x, t1y, t2x, t2y, t3x, t3y);
    if (dist < bestDist) {
        bestDist = dist;
        bestOrder = 1;
    }
    dist = calcDist(t1x, t1y, t3x, t3y, t2x, t2y);
    if (dist < bestDist) {
        bestDist = dist;
        bestOrder = 2;
    }
    dist = calcDist(t3x, t3y, t1x, t1y, t2x, t2y);
    if (dist < bestDist) {
        bestDist = dist;
        bestOrder = 3;
    }
    dist = calcDist(t3x, t3y, t2x, t2y, t1x, t1y);
    if (dist < bestDist) {
        bestDist = dist;
        bestOrder = 4;
    }
    dist = calcDist(t2x, t2y, t3x, t3y, t1x, t1y);
    if (dist < bestDist) {
        bestDist = dist;
        bestOrder = 5;
    }
    printf("%.2f\n", bestDist);
    switch (bestOrder) {
    case 0: cout << "A-B A-C B-C" << endl; break;
    case 1: cout << "A-B B-C A-C" << endl; break;
    case 2: cout << "A-C B-C A-B" << endl; break;
    case 3: cout << "A-C A-B B-C" << endl; break;
    case 4: cout << "B-C A-B A-C" << endl; break;
    case 5: cout << "B-C A-C A-B" << endl; break;
    }
}

