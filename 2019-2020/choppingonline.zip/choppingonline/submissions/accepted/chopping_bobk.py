#!/usr/bin/pypy

def dist(p,q):
    return ((p[0]-q[0])*(p[0]-q[0])+(p[1]-q[1])*(p[1]-q[1])) ** 0.5

def intersect(p,q):
    global t
    global u

    rx = p[1][0] - p[0][0]
    ry = p[1][1] - p[0][1]

    sx = q[1][0] - q[0][0]
    sy = q[1][1] - q[0][1]

    vx = q[0][0] - p[0][0]
    vy = q[0][1] - p[0][1]

    d = rx * sy - ry * sx

#    print (rx,ry),(sx,sy),(vx,vy),d

    if d == 0:
        return False
    else:
        t = (vx * sy - vy * sx) / float(d)
        u = (vx * ry - vy * rx) / float(d)
        if 0 <= t and t <= 1 and 0 <= u and u <= 1:
            return True
        else:
            return False

def findBounds(ax,ay,bx,by,index):
    global lines
    global w
    global h
    global borders
    global t
    global u

    dx = bx - ax
    dy = by - ay
    dist = w + h

    p = [(ax-dist*dx,ay-dist*dy),(bx+dist*dx,by+dist*dy)]

    t = 0
    u = 0
    uList = []
    for b in borders:
        if intersect(b,p):
            uList.append(u)

    uList.sort()
    i = 1
    while i < len(uList):
        if uList[i] == uList[i-1]:
            del uList[i]
        else:
            i += 1

    lines[index][0][0] = p[0][0] + uList[0] * (p[1][0] - p[0][0])
    lines[index][0][1] = p[0][1] + uList[0] * (p[1][1] - p[0][1])
    lines[index][3][0] = p[0][0] + uList[1] * (p[1][0] - p[0][0])
    lines[index][3][1] = p[0][1] + uList[1] * (p[1][1] - p[0][1])

(w,h,ax,ay,bx,by,cx,cy) = map(int,raw_input().split())

borders = [[(0,0),(0,h)],[(0,h),(w,h)],[(w,h),(w,0)],[(w,0),(0,0)]]

lines = [[[0,0],[ax,ay],[bx,by],[0,0]],\
         [[0,0],[bx,by],[cx,cy],[0,0]],\
         [[0,0],[cx,cy],[ax,ay],[0,0]]]

endPoints = [[[0,3],[1,2],[0,2],'A-B A-C B-C'],\
             [[0,3],[1,3],[1,2],'A-B B-C A-C'],\
             [[1,3],[1,2],[0,3],'A-C A-B B-C'],\
             [[1,2],[0,2],[0,3],'A-C B-C A-B'],\
             [[0,2],[0,3],[1,2],'B-C A-B A-C'],\
             [[1,2],[0,3],[1,3],'B-C A-C A-B']]

findBounds(ax,ay,bx,by,0)
findBounds(bx,by,cx,cy,1)
findBounds(cx,cy,ax,ay,2)

minDist = 3 * (w + h)
bestI = -1

for i in (0,1,2,3,4,5):
    d = 0
    for j in (0,1,2):
        d += dist(lines[j][endPoints[i][j][0]],lines[j][endPoints[i][j][1]])
    if d < minDist:
        minDist = d
        bestI = i

print  "{0:.02f}".format(minDist)
print endPoints[bestI][3]
