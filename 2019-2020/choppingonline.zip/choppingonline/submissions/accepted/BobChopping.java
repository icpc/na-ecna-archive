// Solution to "Chopping Online"

import java.util.*;

public class BobChopping {
  public static int w,h;
  public static double A[],B[],C[];
  public static Scanner in;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    casenum = 0;
    String[] out={"A-B A-C B-C","A-B B-C A-C","A-C A-B B-C","A-C B-C A-B",
                  "B-C A-B A-C","B-C A-C A-B"};
    w = in.nextInt();
    h = in.nextInt();

    A = new double[2]; B = new double[2]; C = new double[2];

    A[0] = in.nextInt(); A[1] = in.nextInt();
    B[0] = in.nextInt(); B[1] = in.nextInt();
    C[0] = in.nextInt(); C[1] = in.nextInt();

    // Find points of intersection of rays with the border of the rectangle
    // E.g., ABX is the point where a ray from A through B hits the edge.
    // A value of null means the ray lies along an edge
    double[] ABX = raytoedge(A,B);
    double[] BAX = raytoedge(B,A);
    double[] ACX = raytoedge(A,C);
    double[] CAX = raytoedge(C,A);
    double[] BCX = raytoedge(B,C);
    double[] CBX = raytoedge(C,B);

    // Now simply enumerate the six cases:

    double min = Double.MAX_VALUE;
    int mincase = -1;

    // Case 0: AB, AC, BC:
    double cut = d(ABX,BAX)+d(A,ACX)+d(B,C);
    if (cut < min) { min = cut; mincase = 0;}
    // Case 1: AB, BC, AC:
    cut = d(ABX,BAX)+d(B,BCX)+d(A,C);
    if (cut < min) { min = cut; mincase = 1;}
    // Case 2: AC, AB, BC:
    cut = d(ACX,CAX)+d(A,ABX)+d(B,C);
    if (cut < min) { min = cut; mincase = 2;}
    // Case 3: AC, BC, AB:
    cut = d(ACX,CAX)+d(C,CBX)+d(A,B);
    if (cut < min) { min = cut; mincase = 3;}
    // Case 4: BC, AB, AC:
    cut = d(BCX,CBX)+d(B,BAX)+d(A,C);
    if (cut < min) { min = cut; mincase = 4;}
    // Case 5: BC, AC, AB:
    cut = d(BCX,CBX)+d(C,CAX)+d(A,B);
    if (cut < min) { min = cut; mincase = 5;}
    System.out.printf("%.2f\n%s\n",min,out[mincase]);
  }

  public static double[] raytoedge(double P[], double Q[]) {
    // First see if this lies along a boundary:
    if ((P[0] == 0 && Q[0] == 0) || (P[0] == w && Q[0] == w) ||
        (P[1] == 0 && Q[1] == 0) || (P[1] == h && Q[1] == h))
        return null;

    // left or right edge:
    if (P[0]!=Q[0]) {
      double t = P[0]/(P[0]-Q[0]);
      double y = P[1]+t*(Q[1]-P[1]);
      if (t >= 1.0 && y >= 0 && y <= h) return new double[] {0,y};
      t = (w-P[0])/(Q[0]-P[0]);
      y = P[1]+t*(Q[1]-P[1]);
      if (t >= 1.0 && y >= 0 && y <= h) return new double[] {w,y};
    }
    // top or bottom edge:
    double t = P[1]/(P[1]-Q[1]);
    double x = P[0]+t*(Q[0]-P[0]);
    if (t >= 1.0 && x >= 0 && x <= w) return new double[] {x,0};
    t = (h-P[1])/(Q[1]-P[1]);
    x = P[0]+t*(Q[0]-P[0]);
    if (t >= 1.0 && x >= 0 && x <= w) return new double[] {x,h};

    return null;
  }

  public static double d(double[] P, double[] Q) {
    if (P==null || Q==null) return 0;
    return Math.sqrt((P[0]-Q[0])*(P[0]-Q[0])+(P[1]-Q[1])*(P[1]-Q[1]));
  }
}
