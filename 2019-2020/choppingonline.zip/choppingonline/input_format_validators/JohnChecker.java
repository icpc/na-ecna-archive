import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MINWH = 1;
	public static final int MAXWH = 1000;
	public static final int MINXY = 0;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int w, h, ax, ay, bx, by, cx, cy;
		String line;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 8)
            printError(nLines, "number of values on line incorrect");
        w = Integer.parseInt(st.nextToken());
        h = Integer.parseInt(st.nextToken());
        ax = Integer.parseInt(st.nextToken());
        ay = Integer.parseInt(st.nextToken());
        bx = Integer.parseInt(st.nextToken());
        by = Integer.parseInt(st.nextToken());
        cx = Integer.parseInt(st.nextToken());
        cy = Integer.parseInt(st.nextToken());
        checkIntBounds(w, MINWH, MAXWH, "w", nLines);
        checkIntBounds(h, MINWH, MAXWH, "h", nLines);
        checkIntBounds(ax, MINXY, w, "ax", nLines);
        checkIntBounds(ay, MINXY, h, "ay", nLines);
        checkIntBounds(bx, MINXY, w, "bx", nLines);
        checkIntBounds(by, MINXY, h, "by", nLines);
        checkIntBounds(cx, MINXY, w, "cx", nLines);
        checkIntBounds(cy, MINXY, h, "cy", nLines);

		if (in.hasNextLine())
			printError(nLines, "incorrect number of lines");
        System.exit(42);
	}
}
