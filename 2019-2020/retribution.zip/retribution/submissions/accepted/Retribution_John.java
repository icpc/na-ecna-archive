import java.util.*;

public class Retribution_John {

    public static point[] judges, tar, feather;
    public static boolean[]  usedJT, usedJF, usedT, usedF;
    public static int nJudge, nTar, nFeath;

    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        nJudge = in.nextInt();
        nTar = in.nextInt();
        nFeath = in.nextInt();
        judges = new point[nJudge];
        usedJT = new boolean[nJudge];
        usedJF = new boolean[nJudge];
        element [] a = new element[nJudge*nTar + nJudge*nFeath];
        for(int i=0; i<nJudge; i++) {
            judges[i] = new point();
            judges[i].x  = in.nextDouble();
            judges[i].y = in.nextDouble();
            usedJT[i] = usedJF[i] = false;
        }
        int nElem = 0;
        tar = new point[nTar];
        usedT = new boolean[nTar];
        for(int i=0; i<nTar; i++) {
            tar[i] = new point();
            tar[i].x  = in.nextDouble();
            tar[i].y = in.nextDouble();
            usedT[i] = false;
            for(int j=0; j<nJudge; j++) {
                double xdiff = judges[j].x-tar[i].x;
                double ydiff = judges[j].y-tar[i].y;
                a[nElem] = new element();
                a[nElem].dist = Math.sqrt(xdiff*xdiff + ydiff*ydiff);
                a[nElem].iJ = j;
                a[nElem].iTF = i;
                a[nElem].isTar = true;
                nElem++;
            }
        }
        feather = new point[nFeath];
        usedF = new boolean[nFeath];
        for(int i=0; i<nFeath; i++) {
            feather[i] = new point();
            feather[i].x  = in.nextDouble();
            feather[i].y = in.nextDouble();
            usedF[i] = false;
            for(int j=0; j<nJudge; j++) {
                double xdiff = judges[j].x-feather[i].x;
                double ydiff = judges[j].y-feather[i].y;
                a[nElem] = new element();
                a[nElem].dist = Math.sqrt(xdiff*xdiff + ydiff*ydiff);
                a[nElem].iJ = j;
                a[nElem].iTF = i;
                a[nElem].isTar = false;
                nElem++;
            }
        }
        qsort(a);
        double total = 0.0;
        for(int i=0; i<nElem; i++) {
            if (a[i].isTar) {
                if (usedJT[a[i].iJ] || usedT[a[i].iTF])
                    continue;
                total += a[i].dist;
                usedJT[a[i].iJ] = true;
                usedT[a[i].iTF] = true;
            }
            else {
                if (usedJF[a[i].iJ] || usedF[a[i].iTF])
                    continue;
                total += a[i].dist;
                usedJF[a[i].iJ] = true;
                usedF[a[i].iTF] = true;
            }
        }
        System.out.printf("%.6f\n", total);
    }

    public static void qsort(element[] a)
    {
        qsort(a, 0, a.length-1);
    }

    public static void qsort(element[] a, int low, int high)
    {
        if (low < high) {
            int p = partition(a, low, high);
            qsort(a, low, p-1);
            qsort(a, p+1, high);
        }
    }

    public static int partition(element[] arr, int start, int end){
        element pivot = arr[end];

        for(int i=start; i<end; i++){
            if(arr[i].compareTo(pivot) < 0) {
                element temp = arr[start];
                arr[start]=arr[i];
                arr[i]=temp;
                start++;
            }
        }

        element temp = arr[start];
        arr[start] = pivot;
        arr[end] = temp;

        return start;
    }
}

class point {
    public double x, y;
}

class element {
    public double dist;
    public int iJ;
    public int iTF;
    public boolean isTar;

    public int compareTo(element other)
    {
        if (dist < other.dist)
            return -1;
        else if (dist > other.dist)
            return 1;
        else if (iJ < other.iJ)
            return -1;
        else if (iJ > other.iJ)
            return 1;
        else
            return iTF - other.iTF;
    };
}

