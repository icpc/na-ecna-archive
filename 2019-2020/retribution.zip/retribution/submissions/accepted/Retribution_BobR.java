// (Inefficient) solution to Retribution.
import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;


public class Retribution_BobR {

  public static class Dist {
    public int j,t,f;
    public double d;
    public Dist(int j, int t, int f) {
      this.j = j; this.t = t; this.f = f;
      if (f<0) {
        this.d = Math.sqrt(dist(xt[t],yt[t],xj[j],yj[j]));
      } else {
        this.d = Math.sqrt(dist(xf[f],yf[f],xj[j],yj[j]));
      }
    }
  }

  public static Scanner in;
  public static int n,m,p;
  public static int[] xj,yj,xt,yt,xf,yf;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    n = in.nextInt();
    m = in.nextInt();
    p = in.nextInt();
    xj = new int[n];
    yj = new int[n];
    xt = new int[m];
    yt = new int[m];
    xf = new int[p];
    yf = new int[p];
    for (int i = 0; i < n; i++) {
      xj[i] = in.nextInt();
      yj[i] = in.nextInt();
    }
    for (int i = 0; i < m; i++) {
      xt[i] = in.nextInt();
      yt[i] = in.nextInt();
    }
    for (int i = 0; i < p; i++) {
      xf[i] = in.nextInt();
      yf[i] = in.nextInt();
    }

    Dist[] tar = new Dist[n*m];
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        tar[m*i+j] = new Dist(i,j,-1);
      }
    }
    Arrays.sort(tar,new Comparator<Dist>() {
       public int compare(Dist a, Dist b) {
          if (a.d - b.d < 0) return -1;
          else if (a.d - b.d > 0) return 1;
          else return 0;
       }
      });
    double total = 0;
    boolean jused[] = new boolean[n];
    Arrays.fill(jused,false);
    boolean tused[] = new boolean[m];
    Arrays.fill(tused,false);

    for (int i = 0; i < n*m; i++) {
      if (jused[tar[i].j] || tused[tar[i].t]) continue;
      total += tar[i].d;
      jused[tar[i].j] = true;
      tused[tar[i].t] = true;
    }

    Dist[] feat = new Dist[n*p];
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        feat[p*i+j] = new Dist(i,-1,j);
      }
    }
    Arrays.sort(feat,new Comparator<Dist>() {
       public int compare(Dist a, Dist b) {
          if (a.d - b.d < 0) return -1;
          else if (a.d - b.d > 0) return 1;
          else return 0;
       }
      });
    Arrays.fill(jused,false);
    boolean fused[] = new boolean[p];
    Arrays.fill(fused,false);

    for (int i = 0; i < n*m; i++) {
      if (jused[feat[i].j] || fused[feat[i].f]) continue;
      total += feat[i].d;
      jused[feat[i].j] = true;
      fused[feat[i].f] = true;
    }

    System.out.println(total);
  }

  public static int dist(int x1, int y1, int x2, int y2) {
    return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
  }
}
