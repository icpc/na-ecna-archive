#!/usr/bin/python

import math

def dist2(a,b):
    return (a[0]-b[0])*(a[0]-b[0]) + (a[1]-b[1])*(a[1]-b[1])

def isLess(a,b):
    global heap

    if heap[a][0] < heap[b][0]:
        return True
    elif heap[a][0] > heap[b][0]:
        return False
    elif heap[a][1] < heap[b][1]:
        return True
    elif heap[a][1] > heap[b][1]:
        return False
    else:
        return heap[a][2] < heap[b][2]

def mySort(start,end):
    global heap

    bdy = start

    if start < end:
        for i in xrange(start+1,end+1):
            if isLess(i,start):
                bdy += 1
                (heap[bdy],heap[i]) = (heap[i],heap[bdy])

        (heap[start],heap[bdy]) = (heap[bdy],heap[start])

        mySort(start,bdy-1)
        mySort(bdy+1,end)

def hInsert(d):
    global heap
    global nHeap

#    print nHeap

    heap[nHeap] = d
    pos = nHeap
    nHeap += 1

    while pos != 0:
        parent = (pos - 1) // 2
        if not isLess(pos,parent):
            break
        (heap[parent],heap[pos]) = (heap[pos],heap[parent])
        pos = parent

def hRemoveMin():
    global heap
    global nHeap

    nHeap -= 1

    heap[0] = heap[nHeap]

    pos = 0

    while pos < nHeap // 2:
        c = 2 * pos + 1
        if c < nHeap - 1 and isLess(c+1,c):
            c += 1
        if not isLess(c,pos):
            break
        (heap[pos],heap[c]) = (heap[c],heap[pos])
        pos = c

(n,m,p) = map(int,raw_input().split())

judgeloc = []
tarloc = []
featherloc = []

for i in xrange(n):
    (x,y) = map(int,raw_input().split())
    judgeloc.append((x,y))

for i in xrange(m):
    (x,y) = map(int,raw_input().split())
    tarloc.append((x,y))

for i in xrange(p):
    (x,y) = map(int,raw_input().split())
    featherloc.append((x,y))

answer = 0

judgeTarred = [False] * n
judgeFeathered = [False] * n
tarUsed = [False] * m
feathersUsed = [False] * p

answer = 0

#tarHeap = [0]*(n*m)
#featherHeap = [0]*(n*p)

if m >= p:
    heap = [0]*(n*m)
else:
    heap = [0]*(n*p)
nHeap = 0

k = 0
for i in xrange(n):
    for j in xrange(m):
        dist = (dist2(judgeloc[i],tarloc[j]),i,j)
        #hInsert(dist)
        heap[k] = dist
        k += 1

mySort(0,k-1)

#tarHeap.sort(key=lambda t:t[0])
#featherHeap.sort(key=lambda t:t[0])

nj = n
k = 0
while nj > 0:
    (d,j,t) = heap[k]
    k += 1
    #hRemoveMin()
    if judgeTarred[j] == False and tarUsed[t] == False:
        answer += math.sqrt(d)# ** 0.5
        judgeTarred[j] = True
        tarUsed[t] = True
        nj -= 1

#
#
#

nHeap = 0
k = 0
for i in xrange(n):
    for j in xrange(p):
        dist = (dist2(judgeloc[i],featherloc[j]),i,j)
        #hInsert(dist)
        heap[k] = dist
        k += 1

mySort(0,k-1)

nj = n
k = 0
while nj > 0:
    (d,j,t) = heap[k]
    k += 1
    #hRemoveMin()
    if judgeFeathered[j] == False and feathersUsed[t] == False:
        answer += math.sqrt(d)# ** 0.5
        judgeFeathered[j] = True
        feathersUsed[t] = True
        nj -= 1


print answer
