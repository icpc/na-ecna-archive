#!/usr/bin/pypy

(n,m) = map(int,raw_input().split())
seats = map(int,raw_input().split())

orig = m

count = 0

while seats[m-1] != orig:
    count += 1
    m = seats[m-1]

if count == 0:
    print 0
else:
    print count + 1
