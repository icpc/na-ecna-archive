// Solution to Flight Turbulence

import java.util.*;

public class BobFlight {
  public static int n,m;
  public static Scanner in;
  public static int[] assigned;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    casenum = 0;
      n = in.nextInt();
      m = in.nextInt()-1; // adjust to array indexing
      assigned = new int[n];
      for (int i = 0; i < n; i++) {
        assigned[i] = in.nextInt()-1; // adjust to array indexing
      }
      int i = m;
      int count = 1;
      while(assigned[i] != m) {
        i = assigned[i];
        count++;
      }
      // The trick: if passenger m is already in the correct seat, nobody
      // has to move, but if not, then at least two people have to move.
      if (count==1) count=0;
      System.out.println(count);
  }
}
