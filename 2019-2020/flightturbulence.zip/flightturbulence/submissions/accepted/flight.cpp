#include <iostream>
using namespace std;

const int MAX = 200;


int main()
{
    int seats[MAX+1];
    int n, m, start, icase=0;

    cin >> n >> m;
    int numChanged = 0;
    for(int i=1; i<=n; i++) {
        cin >> seats[i];
    }
    if (seats[m] != m) {
        int end = m;
        while (seats[m] != end) {
            numChanged++;
            m = seats[m];
        }
        numChanged++;
    }
    cout  << numChanged << endl;
}
