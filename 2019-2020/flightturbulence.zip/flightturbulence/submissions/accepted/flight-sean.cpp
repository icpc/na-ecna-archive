#include <iostream>
#include <vector>

using namespace std;

int main(){
  int n, m;
  cin >> n >> m;
  m--;
  vector<int> reservations(n, -1);
  for(int i = 0; i < n; i++){
    cin >> reservations[i];
    reservations[i]--; // count from 0 instead of 1
  }

  int count = 0;
  while(reservations[m] != m && reservations[m] != -1){
    int old = m;
    m = reservations[m];
    reservations[old] = -1;
    count++;
  }
  cout << count << endl;
  return 0;
}
