// Since I have almost no memory of how to do linear programming, I just used
// tutorials at places like:
//    http://pages.intnet.mu/cueboy/education/notes/algebra/simplex.htm
//    http://college.cengage.com/mathematics/larson/elementary_linear/4e/
//         shared/downloads/c09s3.pdf
//    http://www.math.wsu.edu/faculty/dzhang/201/
//         Guideline%20to%20Simplex%20Method.pdf

import java.util.Scanner;

public class Cheese_BobR {
  public static Scanner in;
  public static int n,m; // # kinds of cheese, # blends
  public static double p[][]; // the Simplex tableau

  public static void main(String[] args) {
    in = new Scanner(System.in);
    n = in.nextInt(); // number of cheese types = number of constraint eqs
    m = in.nextInt(); // number of blends = number of unknown variables
    p = new double[n+1][m+n+1]; // 1 extra row for objective;
                              // n+1 extra cols for slack vars and "b" vector

    // Read in constraint bounds (RHS of the lin prog inequality)
    for (int i = 0; i < n; i++) {
      p[i][m+n] = in.nextDouble(); // amount of cheese type i
    }

    // Read in percentages for the m blends:
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < n; j++) {
        p[j][i] = in.nextDouble(); // % of cheese i for blend j
		p[j][i] /= 100.0;
      }
      p[n][i] = -in.nextDouble(); // profit for blend j = objective func coeff
    }

    // Set up slack variables:
    for (int i = 0; i < n; i++) {
      p[i][m+i] = 1;
    }

    simplex();
    System.out.printf("%.2f\n",p[n][m+n]);
  }

  public static void simplex() {
    // find smallest negative value in bottom row; quit if none:
    int mincol;
    while ((mincol = minneg()) >= 0) {
      int minrow = minratio(mincol);
      if (minrow < 0) break;
      double div = p[minrow][mincol];
      for (int j = 0; j < n+m+1; j++) {
        p[minrow][j] = p[minrow][j]/div;
      }
      for (int i = 0; i < n+1; i++) {
        if (i==minrow) continue;
        double mult = p[i][mincol];
        for (int j = 0; j < n+m+1; j++) {
          p[i][j] = p[i][j]-mult*p[minrow][j];
        }
      }
    }
  }

  public static int minneg() {
    double min = Double.MAX_VALUE;
    int mincol = -1;
    for (int i = 0; i < m+n+1; i++) {
      if (p[n][i] < 0 && p[n][i] < min) {
        min = p[n][i];
        mincol = i;
      }
    }
    return mincol;
  }

  public static int minratio(int col) {
    double minrat = Double.MAX_VALUE;
    int minrow = -1;
    for (int i = 0; i < n; i++) {
      if (p[i][col] > 0) {
        double r = p[i][m+n]/p[i][col];
        if (r < minrat) {
          minrat = r;
          minrow = i;
        }
      }
    }
    return minrow;
  }

  // for debugging:
  public static void display() {
    for (int i = 0; i < n+1; i++) {
      for (int j = 0; j < m+n+1; j++) {
        System.out.printf("%7.2f",p[i][j]);
      }
      System.out.println();
    }
  }
}
