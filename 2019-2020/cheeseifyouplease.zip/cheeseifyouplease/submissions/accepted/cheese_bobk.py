#!/usr/bin/python

(nCheeses,nBlends) = map(int,raw_input().split())

amounts = map(int,raw_input().split())

blendInfo = []
for b in xrange(nBlends):
    line = map(float,raw_input().split())
    percentages = line[0:nCheeses]
    for i in xrange(len(percentages)):
        percentages[i] /= 100.0
    blendInfo.append([percentages,line[nCheeses]])

#print blendInfo

# tableau
# first row: 1 -p0 -p1 ... -p(b-1) 0*nCheeses 0
# subsequent nCheeses rows: 0 info[b][c]*nBlends I*nCheeses w[c]

tableau = []
for i in xrange(nCheeses+1):
    tableau.append([0]*(nCheeses+nBlends+1))

for b in xrange(nBlends):
    tableau[0][b] = -blendInfo[b][1]
for c in xrange(nCheeses):
    for b in xrange(nBlends):
        tableau[c+1][b] = blendInfo[b][0][c]
    for i in xrange(nCheeses):
        if i == c:
            tableau[c+1][i+nBlends] = 1
        else:
            tableau[c+1][i+nBlends] = 0
    tableau[c+1][nCheeses+nBlends] = amounts[c]

#for r in xrange(len(tableau)):
#    print tableau[r]

while True:
    bestCol = -1
    bestVal = 99999
    for c in xrange(nBlends+nCheeses+1):
        if tableau[0][c] < 0 and tableau[0][c] < bestVal:
            bestVal = tableau[0][c]
            bestCol = c
    if bestCol == -1:
        break

#    print "choose col",pCol,tableau[0][pCol]

    bestRow = -1
    bestVal = 99999
    for r in xrange(1,nCheeses+1):
        if tableau[r][bestCol] > 0:
            test = tableau[r][nBlends+nCheeses] / tableau[r][bestCol]
            if test < bestVal:
                bestRow = r
                bestVal = test

    if bestRow == -1:
        break

    # process pivot row
    pivot = tableau[bestRow][bestCol]
#    print "pivot",pivot
    for c in xrange(nBlends+nCheeses+1):
        tableau[bestRow][c] /= pivot
    for r in xrange(0,nCheeses+1):
        if r != bestRow:
            prev = tableau[r][bestCol]
            for c in xrange(nBlends+nCheeses+1):
                tableau[r][c] = tableau[r][c] - prev * tableau[bestRow][c]

#    for r in xrange(len(tableau)):
#        print tableau[r]


print "{0:.02f}".format(tableau[0][nBlends+nCheeses])
