#!/usr/bin/python

(nCheeses,nBlends) = map(int,raw_input().split())

amounts = map(int,raw_input().split())

blendInfo = []
for b in xrange(nBlends):
    line = map(float,raw_input().split())
    percentages = line[0:nCheeses]
    for i in xrange(len(percentages)):
        percentages[i] /= 100.0
    blendInfo.append([percentages,line[nCheeses]])

blendInfo.sort(reverse=True,key=lambda x:x[1])

profit = 0.0

for b in blendInfo:
    least = 9999999999
    for i in xrange(nCheeses):
        if b[0][i] > 0:
            nPounds = amounts[i] / b[0][i]
            if nPounds < least:
                least = nPounds
    profit += b[1] * least
    for i in xrange(nCheeses):
        amounts[i] -= least * b[0][i]

#print blendInfo

print "{0:.02f}".format(profit)
