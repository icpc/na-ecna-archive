#!/usr/bin/python

import random
import sys

nCheeses = int(sys.argv[1])
nBlends = int(sys.argv[2])

print nCheeses,nBlends
for i in xrange(nCheeses):
    print random.randint(0,500),
print

for i in xrange(nBlends):
    total = 0
    percentages = []
    for j in xrange(nCheeses):
        r = random.randint(0,10)
        total += r
        percentages.append(r)
    p = 0
    maxC = -1
    maxV = -1
    for j in xrange(nCheeses):
        percentages[j] = (1000 * percentages[j]) // total
        p += percentages[j]
        if percentages[j] > maxV:
            maxV = percentages[j]
            maxC = j
    percentages[maxC] += 1000 - p
    for j in xrange(nCheeses):
        print percentages[j] / 10.0,
    print "{0:.02f}".format(random.randint(1,1000) / 100.0)

#
# add these to add individual cheeses to be sold. for a penny
#
#for i in xrange(nCheeses):
#    for j in xrange(nCheeses):
#        if i == j:
#            print 100.0,
#        else:
#            print 0.0,
#    print 0.01
