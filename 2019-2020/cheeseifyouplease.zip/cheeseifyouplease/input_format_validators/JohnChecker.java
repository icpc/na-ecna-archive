import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MINN = 1;
	public static final int MAXN = 50;
	public static final int MINM = 1;
	public static final int MAXM = 50;
	public static final int MINW = 0;
	public static final int MAXW = 500;
	public static final double MINP = 0.0;
	public static final double MAXP = 100.0;
	public static final double MINT = 0.0;
	public static final double MAXT = 10.0;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
//		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void checkDoubleBounds(double x, double min, double max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static int nextInt(StringTokenizer st)
    {
        return Integer.parseInt(st.nextToken());
    }

    public static double nextDouble(StringTokenizer st)
    {
        return Double.parseDouble(st.nextToken());
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int n, m, w;
		double p, t;
		String line;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 2)
            printError(nLines, "number of values on line incorrect");
        n = nextInt(st);
        m = nextInt(st);
        checkIntBounds(n, MINN, MAXN, "n", nLines);
        checkIntBounds(m, MINM, MAXM, "m", nLines);

        line = in.nextLine();
        nLines++;
        st = new StringTokenizer(line);
        if (st.countTokens() != n)
            printError(nLines, "number of values on line incorrect");
        for(int i=0; i<n; i++) {
            w = nextInt(st);
            checkIntBounds(w, MINW, MAXW, "w", nLines);
        }
        for(int i=0; i<m; i++) {
            line = in.nextLine();
            nLines++;
            st = new StringTokenizer(line);
            if (st.countTokens() != n+1)
                printError(nLines, "number of values on line incorrect");
            for(int j=0; j<n; j++) {
                p = nextDouble(st);
                checkDoubleBounds(p, MINP, MAXP, "p", nLines);
            }
            t = nextDouble(st);
            checkDoubleBounds(t, MINT, MAXT, "t", nLines);
        }
		if (in.hasNextLine())
			printError(nLines, "incorrect number of lines");
        System.exit(42);
	}
}
