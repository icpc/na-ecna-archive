#include <iostream>
using namespace std;

const int MAXB = 150;    // number of storage bins
const int NUMC = 5;     // number of companies
const int EMPTY = -1;
const int INF = 1000000000;

int bins[MAXB];
int weights[MAXB] = {0};
int totalWeights[NUMC] = {0};         // total weights for all bins for a company
int counts[NUMC] = {0};   // number of each company in final bins
int first[NUMC], last [NUMC];   // location of first and last company bin prior to moving

int costs[NUMC][MAXB];  // costs[i][j] = cost for company i's bins to start at location j
int bestCost = INF;     // optimal cost of moving bins

int calcCost(int comp, int bin, int nBins)
{
    if (bin + counts[comp] >nBins)
        return INF;
    int ans = totalWeights[comp];
    for(int b=bin; b<bin+counts[comp]; b++)
        if (bins[b] == comp)
            ans -= weights[b];
    return ans;
}

void calcCosts(int nBins)
{
    for(int comp = 0; comp < NUMC; comp++) {
        for(int bin = 0; bin <nBins; bin++)
            costs[comp][bin] = calcCost(comp, bin, nBins);
    }
}

bool okToPlace(int len, int bin, int placed[])
{
    for(int i=0; i<len; i++)
        if (placed[bin+i] != EMPTY)
            return false;
    return true;
}

void calcBestCost(int nBins, int comp, int placed[], int currCost)
{
    if (currCost >= bestCost)
        return;
    if (comp == NUMC) {
        if (currCost < bestCost) {
            bestCost = currCost;
        }
        return;
    }
    for(int b=0; b<=nBins-counts[comp]; b++) {
        if (okToPlace(counts[comp], b, placed)) {
            for(int i=0; i<counts[comp]; i++)
                placed[b+i] = comp;
            currCost += costs[comp][b];
            calcBestCost(nBins, comp+1, placed, currCost);
            currCost -= costs[comp][b];
            for(int i=0; i<counts[comp]; i++)
                placed[b+i] = EMPTY;
        }
    }
}

void calcBestCost(int nBins)
{
    int *placed = new int[nBins];
    for(int i=0; i<nBins; i++)
        placed[i] = EMPTY;
    calcBestCost(nBins, 0, placed, 0);
}

int main()
{
    int n, m;
    string s;

    cin >> s;
    n = s.length();
    for(int i=0; i<n; i++) {
        cin >> weights[i];
        switch (s[i]) {
        case 'A' : bins[i] = 0;
              counts[0]++;
              totalWeights[0] += weights[i];
              break;
        case 'E' : bins[i] = 1;
              counts[1]++;
              totalWeights[1] += weights[i];
              break;
        case 'I' : bins[i] = 2;
              counts[2]++;
              totalWeights[2] += weights[i];
              break;
        case 'O' : bins[i] = 3;
              counts[3]++;
              totalWeights[3] += weights[i];
              break;
        case 'U' : bins[i] = 4;
              totalWeights[4] += weights[i];
              counts[4]++;
              break;
        default :
            bins[i] = EMPTY;
        }
    }
    cin >> m;
    for(int i=0; i<m; i++) {
        int b;
        cin >> b;
        b--;
        counts[bins[b]]--;
        totalWeights[bins[b]] -= weights[b];
        bins[b] = EMPTY;
        weights[b] = 0;
    }
/*
for(int i=0; i<n; i++)
if (bins[i] == EMPTY)
cout << ' ';
else
cout << bins[i];
cout << endl;
/**/
    cin >> s;
    for(int i=0; i<s.length(); i++) {
        switch (s[i]) {
        case 'A' : counts[0]++;
              break;
        case 'E' : counts[1]++;
              break;
        case 'I' : counts[2]++;
              break;
        case 'O' : counts[3]++;
              break;
        case 'U' : counts[4]++;
              break;
        }
    }

    calcCosts(n);
/*
for(int i=0; i<NUMC; i++){
cout << "Company " << i << ":";
for(int j=0; j<n; j++) {
cout << ' ' << costs[i][j];
}
cout << endl;
}
/**/
    calcBestCost(n);
    cout << bestCost << endl;
}
