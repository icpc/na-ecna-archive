import java.util.Scanner;
import java.util.Arrays;

public class Bin_BobR {
  public static Scanner in;
  public static int n; // number of bins
  public static int cost[]; // cost of moving this bin
  public static int contents[]; // company owning this bin
  public static int count[]; // final number of bins for each company
  public static int startloc[]; // starting locations of companies' bins
  public static int newstart[]; // starting location of moved bins
  public static int endloc[]; // ending locations of companies' bins
  public static int newbins[]; // new arrangement of bins
  public static int mincost;

  public static void main(String[] args) {
    in = new Scanner(System.in);
    String s = in.nextLine();
    n = s.length();
    contents = new int[n];
    cost = new int[n];
    startloc = new int[6];
    Arrays.fill(startloc,-1);
    endloc = new int[6];
    Arrays.fill(endloc,-2);
    count = new int[6];
    mincost = Integer.MAX_VALUE;

    // Input initial arrangement:
    for (int i = 0; i < n; i++) {
      int code = convert(s.charAt(i));
      contents[i] = code;
      count[code]++;
    }
    for (int i = 0; i < n; i++) {
      cost[i] = in.nextInt();
    }

    // Input deletions:
    int d = in.nextInt();
    for (int i = 0; i < d; i++) {
      int bin = in.nextInt();
      int code = contents[bin-1];
      cost[bin-1] = 0;
      count[code]--;
      contents[bin-1] = convert('X');
    }
    for (int i = 0; i < n; i++) {
      int c = contents[i];
      if (startloc[c] < 0) {
        startloc[c] = i;
        endloc[c] = i;
      }
      else (endloc[c]) = i;
    }

    // Input additions:
    s = in.next();
    for (int i = 0; i < s.length(); i++) {
      count[convert(s.charAt(i))]++;
    }

    // Getting ready...
    newbins = new int[n];
    Arrays.fill(newbins,0);
    newstart = new int[6];
    if (count[0] == n) System.out.println(0);
    else {
      solve(1,0); // solve, starting with company 1
      System.out.println(mincost);
    }
    
  }

  public static int convert(char x) {
    return "XAEIOU".indexOf(x);
  }

  public static void solve(int c, int costsofar) {
    if (c > 5) { // done
      if (costsofar < mincost) {
        mincost = costsofar;
      }
      return;
    }
    if (count[c] <= 0) { // nothing to do--move on to next company
      newstart[c] = 6;
      solve(c+1,costsofar);
    } else {
      int i = 0;
      while(i <= n-count[c]) { // i = new start loc of c's bins
        if (newbins[i] < c && newbins[i] > 0) {
          i++;
          continue; // already used this bin
        }
        // make sure there are enough empty bins to hold count[c] items:
        boolean ok=true;
        int resume = -1;
        for (int j = 1; j < c; j++) {
          if (newstart[j] >= i && newstart[j] < i+count[c]) {
            ok = false;
            resume = Math.max(resume,newstart[j]+count[j]);
          }
        }
        if (!ok) {
          i = resume;
          continue; // not enough consecutive empty bins; try next i
        }

        newstart[c] = i; // begin filling bins with c at location i

        int thiscost = 0;

        // bins already occupied by c will be skipped over; empty bins
        // will be filled by moving old bins (if any), then adding new bins

        int j = startloc[c]; // first old bin to (maybe) be moved

        for (int k = i; k < i+count[c]; k++) {
          while (j >= 0 && j <= endloc[c]) {
            if (contents[j]==0) j++;
            else if (j >= i && j < i+count[c]) j++;
            else break;
          }
          if (j >= 0 && j <= endloc[c]) {
            thiscost += cost[j];
            j++;
          }
          if (costsofar+thiscost > mincost) {
            break;
          }
          newbins[k] = c;
        }
        if (costsofar+thiscost > mincost) {
          Arrays.fill(newbins,i,i+count[c],0);
          newstart[c] = -1;          
          i++;
          continue;
        }

        // All of c's bins have been moved; proceed:
        solve(c+1,costsofar+thiscost);
        // Get ready for new placement of c's bins:
        Arrays.fill(newbins,i,i+count[c],0);
        newstart[c] = -1;          
        i++;
      }
      newstart[c] = -1;
    }
  }
}
