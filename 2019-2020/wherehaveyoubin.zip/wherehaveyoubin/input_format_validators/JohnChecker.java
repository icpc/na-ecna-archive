import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MAXB = 150;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int r, m;
		String line, bins;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        int len = line.length();
        if (len > MAXB)
            printError(nLines, "line too long");
        if (len == 0)
            printError(nLines, "missing first line");
        int nopenings = 0;
        for(int i=0; i<len; i++) {
            char ch = line.charAt(i);
            if (ch != 'A' && ch != 'E' && ch != 'I' && ch != 'O' && ch != 'U' && ch != 'X')
                printError(nLines, "illegal character: " + ch);
            if (ch == 'X')
                nopenings++;
        }
        bins = line;
        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != len)
            printError(nLines, "number of values on line incorrect");
        for(int i=0; i<len; i++) {
            int val;
            val = Integer.parseInt(st.nextToken());
            if (bins.charAt(i) == 'X' && val != 0)
                printError(nLines, "Non zero value for unowned warehouse #" + (i+1) + ": " + val);
            else if (bins.charAt(i)!= 'X' && (val < 1 || val > 100))
                printError(nLines, "Bad value for owned warehouse #" + (i+1) + ": " + val);

        }
        line = in.nextLine();
        nLines++;
        st = new StringTokenizer(line);
        if (st.countTokens() == 0)
            printError(nLines, "number of values on line incorrect");
        int d = Integer.parseInt(st.nextToken());
        if (d < 0 || d > len)
            printError(nLines, "Illegal # of deletions: " + d);
        if (st.countTokens() != d)
            printError(nLines, "number of values on line incorrect");
        for(int i=0; i<d; i++) {
            int val = Integer.parseInt(st.nextToken());
            if (val < 1 || val > len)
                printError(nLines, "Deletion bin number out of range: " + d);
            if (bins.charAt(val-1) == 'X')
                printError(nLines, "Deletion bin unowned: " + d);
        }
        line = in.nextLine();
        nLines++;
        st = new StringTokenizer(line);
        if (st.countTokens() != 1)
            printError(nLines, "number of values on line incorrect");
        int nadditions = line.length();
        if (nadditions == 1 && line.charAt(0) == 'X') {

        }
        else {
            if (nadditions > nopenings+d)
                printError(nLines, "too many additions: " + line.length());
            for(int i=0; i<nadditions; i++) {
                char ch = line.charAt(i);
                if (ch != 'A' && ch != 'E' && ch != 'I' && ch != 'O' && ch != 'U')
                    printError(nLines, "illegal character: " + ch);
            }
        }
		if (in.hasNextLine())
			printError(nLines, "incorrect number of lines");
        System.exit(42);
	}
}
