import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MINNM = 1;
	public static final int MAXNM = 100;
	public static final int MINT = 1;
	public static final int MAXT = 52;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int n, m;
		String line;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 2)
            printError(nLines, "number of values on line incorrect");
        n = Integer.parseInt(st.nextToken());
        checkIntBounds(n, MINNM, MAXNM, "n", nLines);
        m = Integer.parseInt(st.nextToken());
        checkIntBounds(m, MINNM, MAXNM, "m", nLines);

        int numT = 0;
        for(int i=1; i<=n; i++) {
            line = in.nextLine();
            nLines++;
            if (line.length() != m)
                printError(nLines, "number of characters on line incorrect");
            for(int j=0; j<m; j++) {
                char ch = line.charAt(j);
                if (ch != '$' && ch != '#' && ch != '.')
                    printError(nLines, "illegal character: " + ch);
                if (ch == '$')
                    numT++;
            }
        }
        checkIntBounds(numT, MINT, MAXT, "t", nLines);
		if (in.hasNextLine())
			printError(nLines, "too many lines");
        System.exit(42);
	}
}
