import java.util.*;

public class Squares_John_Trans {
  public static final  int MAXD = 100;
  public static final  int FOUND = 0;
  public static final  int STOP = 1;
  public static final  int FILL = 2;

  public static char grid[][], save[][]; public static String labels =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  public static int ilabel = 0;

  public static void printGrid(int n, int m) {
    for(int i=0; i<n; i++) {
        for(int j=0; j<m; j++) {
            System.out.print(grid[i][j]);
        }
        System.out.println();
    }
  }

  public static int check(int r, int c, int sze, boolean found,
     int nRows, int nCols) {
//cout << "checking (" << r << ',' << c << ") with size " << sze << endl;
    if (r+sze-1 >= nRows || c+sze-1 >= nCols)
        return STOP;
    int retVal = FILL;
    for(int i=r; i<r+sze; i++) {
        switch (grid[i][c+sze-1]) {
        case '$' : if (found)           // already found a '$'
                    return STOP;
                   retVal = FOUND;
        case '.' : break;
        default : return STOP;
        }
    }
    for(int j=c; j<c+sze-1; j++) {
        switch (grid[r+sze-1][j]) {
        case '$' : if (found)           // already found a '$'
                    return STOP;
                   retVal = FOUND;
        case '.' : break;
        default : return STOP;
        }
    }
    return retVal;
  }

  public static int fillShell(int r, int c, int sze, char label) {
    for(int i=r; i<r+sze; i++) {
        grid[i][c+sze-1] = label;
    }
    for(int j=c; j<c+sze-1; j++) {
        grid[r+sze-1][j] = label;
    }
    return FILL;
  }

  public static void unfill(int r, int c, int sze) {
    for(int i=r; i<r+sze; i++)
        for(int j=c; j<c+sze; j++)
            grid[i][j] = save[i][j];
  }

  public static boolean fillGrid(int r, int c, int iLabel, int nRows, int nCols) {
//cout << "r, c = " << r << ',' << c << endl;
//printGrid(nRows, nCols);
    while (r < nRows && grid[r][c] != '.' && grid[r][c] != '$') {
        c++;
        if (c == nCols) {
            r++;
            c = 0;
        }
    }
//cout << "  new r, c = " << r << ',' << c << endl;
    if (r == nRows)
        return true;

    char label = labels.charAt(iLabel);
    int sqSize = 1;
    boolean found = false;
    int ans = check(r, c, sqSize, found, nRows, nCols);
    while (ans == FILL) {
        fillShell(r, c, sqSize, label);
        ans = check(r, c, ++sqSize, found, nRows, nCols);
    }
    if (ans == STOP) {
        unfill(r, c, sqSize-1); // couldn't find a '$';
        return false;
    }
    found = true;               // else, found a '$';
    do {
        fillShell(r, c, sqSize, label);
        if (fillGrid(r, c, iLabel+1, nRows, nCols))
            return true;
        ans = check(r, c, ++sqSize, found, nRows, nCols);
    } while (ans == FILL);
                                // couldn't make it work
    unfill(r, c, sqSize-1);
    return false;
  }

  public static void main(String[]args) {
    grid = new char[MAXD][MAXD];
    save = new char[MAXD][MAXD];
    int n, m;

    Scanner in = new Scanner(System.in);

    n = in.nextInt();
    m = in.nextInt();
    for(int i=0; i<n; i++) {
        String line = in.next();
        for(int j=0; j<m; j++) {
            grid[i][j] = line.charAt(j);
            save[i][j] = grid[i][j];
        }
    }

    if (!fillGrid(0, 0, 0, n, m))
        System.out.println("elgnatcer");
    else
        printGrid(n, m);
  }
}
