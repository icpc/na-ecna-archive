#include <iostream>
using namespace std;

const int MAXD = 100;
const int FOUND = 0;
const int STOP = 1;
const int FILL = 2;

char grid[MAXD][MAXD], save[MAXD][MAXD];
string labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
int ilabel = 0;

void printGrid(int n, int m)
{
    for(int i=0; i<n; i++) {
        for(int j=0; j<m; j++) {
            cout << grid[i][j];
        }
        cout << endl;
    }
}

int check(int r, int c, int sze, bool found, int nRows, int nCols)
{
//cout << "checking (" << r << ',' << c << ") with size " << sze << endl;
    if (r+sze-1 >= nRows || c+sze-1 >= nCols)
        return STOP;
    int retVal = FILL;
    for(int i=r; i<r+sze; i++) {
        switch (grid[i][c+sze-1]) {
        case '$' : if (found)           // already found a '$'
                    return STOP;
                   retVal = FOUND;
        case '.' : break;
        default : return STOP;
        }
    }
    for(int j=c; j<c+sze-1; j++) {
        switch (grid[r+sze-1][j]) {
        case '$' : if (found)           // already found a '$'
                    return STOP;
                   retVal = FOUND;
        case '.' : break;
        default : return STOP;
        }
    }
    return retVal;
}

int fillShell(int r, int c, int sze, char label)
{
    for(int i=r; i<r+sze; i++) {
        grid[i][c+sze-1] = label;
    }
    for(int j=c; j<c+sze-1; j++) {
        grid[r+sze-1][j] = label;
    }
    return FILL;
}

void unfill(int r, int c, int sze)
{
    for(int i=r; i<r+sze; i++)
        for(int j=c; j<c+sze; j++)
            grid[i][j] = save[i][j];
}

bool fillGrid(int r, int c, int iLabel, int nRows, int nCols)
{
//cout << "r, c = " << r << ',' << c << endl;
//printGrid(nRows, nCols);
    while (r < nRows && grid[r][c] != '.' && grid[r][c] != '$') {
        c++;
        if (c == nCols) {
            r++;
            c = 0;
        }
    }
//cout << "  new r, c = " << r << ',' << c << endl;
    if (r == nRows)
        return true;

    char label = labels[iLabel];
    int sqSize = 1;
    bool found = false;
    int ans = check(r, c, sqSize, found, nRows, nCols);
    while (ans == FILL) {
        fillShell(r, c, sqSize, label);
        ans = check(r, c, ++sqSize, found, nRows, nCols);
    }
    if (ans == STOP) {
        unfill(r, c, sqSize-1); // couldn't find a '$';
        return false;
    }
    found = true;               // else, found a '$';
    do {
        fillShell(r, c, sqSize, label);
        if (fillGrid(r, c, iLabel+1, nRows, nCols))
            return true;
        ans = check(r, c, ++sqSize, found, nRows, nCols);
    } while (ans == FILL);
                                // couldn't make it work
    unfill(r, c, sqSize-1);
    return false;
}

int main()
{
    int n, m;

    cin >> n >> m;
    for(int i=0; i<n; i++) {
        for(int j=0; j<m; j++) {
            cin >> grid[i][j];
            save[i][j] = grid[i][j];
        }
    }

    if (!fillGrid(0, 0, 0, n, m))
        cout << "elgnatcer" << endl;
    else
        printGrid(n, m);
}
