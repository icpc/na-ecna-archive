#!/usr/bin/python

import random
import sys

nNodes = int(sys.argv[1])

pairs = []
for i in xrange(nNodes):
    for j in xrange(i+1,nNodes):
        pairs.append( (i,j) )

aList = []
for i in xrange(nNodes):
    aList.append([])

i = len(pairs)
while i > 0:
#    print i
    j = random.randint(0,i-1)
    i -= 1
    p = pairs[j]
    del pairs[j]
    a1 = len(aList[p[0]])
    a2 = len(aList[p[1]])
    if a1 == 3 or a2 == 3:
        continue
    aList[p[0]].append([p[1],random.randint(1,20),(a1*135)%360])
    aList[p[1]].append([p[0],random.randint(1,20),(a2*135)%360])


# output
print nNodes,(nNodes-1),"45 45"
for n in aList:
    print len(n),
    for e in n:
        print (e[0]+1),e[1],e[2],
    print
#print aList
