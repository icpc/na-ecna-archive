#!/usr/bin/python

import random

def edgeFill(n):
    global aList
    while len(aList[n]) < 5:
        # pick a random destination
        while True:
            dest = random.randint(1,999)
            # dest cannot be same as source
            if n == dest:
                continue
            # if destination not full then keep looking
            if len(aList[dest]) == 5:
                continue
            # make sure there isn't already an edge between source and dest
            i = 0
            while i < len(aList[dest]):
                if aList[dest][0] == n:
                    break
                i += 1
            if i == len(aList[dest]):
                break
        # pick a random angle for both sides
        while True:
            angle1 = random.randint(0,3) * 90 + 45
            # if angle unused, stop
            i = 0
            while i < len(aList[n]):
                if angle1 == aList[n][i][2]:
                    break
                i += 1
            if i == len(aList[n]):
                break
        while True:
            angle2 = random.randint(0,3) * 90 + 45
            # if angle unused, stop
            i = 0
            while i < len(aList[dest]):
                if angle2 == aList[dest][i][2]:
                    break
                i += 1
            if i == len(aList[dest]):
                break
        # add edge
        aList[n].append([dest,1,angle1])
        aList[dest].append([n,1,angle2])

aList = []
for i in xrange(1000):
    aList.append([])

# create the central path
# 0->2
aList[0].append([2,1,90])

# interior nodes along central path, up and down, not including 998
for i in xrange(2,997,2):
    aList[i].append([i+2,1,90])
    aList[i].append([i-2,1,270])

# node 998 up and down
aList[998].append([996,1,270])
aList[998].append([999,1,90]) # this is why 998 is separate

# 999->998
aList[999].append([998,1,270])

# create the back-and-forth return path

# 999-997
aList[999].append([997,1,90])
aList[997].append([999,1,180])
# 997-998
aList[997].append([998,1,0])
aList[998].append([997,1,180])

# left side, 1 to 993
for i in xrange(1,996,4):
    # connect to center node same level
    aList[i].append([i+1,1,0])
    aList[i+1].append([i,1,180])
    # connect to center node one level up
    aList[i].append([i+3,1,180])
    aList[i+3].append([i,1,180])

# right side, 3 to 995
for i in xrange(3,996,4):
    # connect to center node same level
    aList[i].append([i+1,1,180])
    aList[i+1].append([i,1,0])
    # connect to center node one level up
    aList[i].append([i+3,1,0])
    aList[i+3].append([i,1,0])

# loop around the outer nodes

# 2-3
aList[2].append([3,1,0])
aList[3].append([2,1,270])

# 3->7
aList[3].append([7,1,90])

# up the right side 7 to 991 up and down
for i in xrange(7,992,4):
    aList[i].append([i+4,1,90])
    aList[i].append([i-4,1,270])

# 995->991
aList[995].append([991,1,270])

# 995-997
aList[995].append([997,1,90])
aList[997].append([995,1,90])

# 997->993
aList[997].append([993,1,270])

# down the left side 5 to 993 up and down
for i in xrange(5,994,4):
    aList[i].append([i+4,1,90])
    aList[i].append([i-4,1,270])

# 1 -> 5
aList[1].append([5,1,90])

# finally, 1-0
aList[1].append([0,1,270])
aList[0].append([1,1,180])

# fill in node 0
edgeFill(0)
# fill in node 999
edgeFill(999)
# and then the rest
for i in xrange(1,999):
    edgeFill(i)

# output
print "1000 999 45 45"
for n in aList:
    print len(n),
    for e in n:
        print (e[0]+1),e[1],e[2],
    print
#print aList
