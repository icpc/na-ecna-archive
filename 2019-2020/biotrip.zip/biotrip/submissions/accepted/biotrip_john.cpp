#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int MAXJ = 1000;
const int MAXD = 5;

const int INF = 10000000;

struct vertex_info
{
    int w;      // vertex connected to
    int len;    // edge length
    int ang;    // angle edge leaves this vertex
    int vnum;   // graph vertex # for this (vertex,ang) pair;
};

struct vertex_input {
    int m;
    vertex_info edges[MAXD];
} input[MAXJ+1];

class edge
{
public:
    int dest;
    int len;
    edge *next;

    edge(int d, int l, edge* n=0) : dest(d), len(l), next(n)
    {}
};

struct vertex
{
    int baseNum;
    edge *list;
    bool visited;
    int dist;
} graph[MAXJ*MAXD];

class pqEntry
{
public:
    int v;
    int dist;

    pqEntry(int iv, int d) : v(iv), dist(d)
    {}
};

class mycomparison
{
public:
    bool operator() (const pqEntry& lhs, const pqEntry&rhs) const
    {
        return (lhs.dist > rhs.dist);
    }
};

priority_queue<pqEntry, vector<pqEntry>, mycomparison> pq;

void printGraph(int nV)
{
    for(int i=0; i<nV; i++) {
        cerr << i << ":";
        for(edge* p=graph[i].list; p != 0; p=p->next) {
            cerr << " " << p->dest << "(" << p->len << ")";
        }
        cerr << endl;
    }
}
void dijkstra(int src, int nV)
{
//cerr << "Dijkstras" << endl;
    for(int i=0; i<nV; i++) {
        graph[i].dist = INF;
        graph[i].visited = false;
    }
    graph[src].dist = 0;
    pqEntry e(src, 0);
    pq.push(e);
    while (!pq.empty()) {
        pqEntry e = pq.top();
        pq.pop();
//cerr << "  processing vertex " << e.v << endl;
        if (graph[e.v].visited)
            continue;
        graph[e.v].visited = true;
        for(edge* p = graph[e.v].list; p != 0; p = p->next) {
            int w = p->dest;
            int dist = graph[e.v].dist + p->len;
//cerr << "    neighboring vertex " << w << ": curr dist = " << graph[w].dist << ", new dist = " << dist << endl;
            if (dist < graph[w].dist) {
                graph[w].dist = dist;
                pqEntry e2(w, dist);
                pq.push(e2);
            }
        }
    }
}

void addEdge(int v, int w, int len)
{
    graph[v].list = new edge(w, len, graph[v].list);
}

int findVertexNum(int w, int v)
{
//cerr << "  looking for vertex " << v << " in list of vertex " << w << endl;
    for(int j=0; j<input[w].m; j++) {
        if (input[w].edges[j].w == v) {
            return input[w].edges[j].vnum;
        }
    }
    cerr << "ERROR: Could not find edge from " << w << " to " << v << endl;
    exit(-1);
}

bool canUseEdge(int ang1, int ang2, int d1, int d2)
{
    if (ang1 > 360)
        ang1 -= 360;
//cerr << "  checking if angle " << ang2 << " is in range" << endl;
    int upper = ang1+d1;
    if (upper >= 360)
        upper -= 360;
    int lower = ang1-d2;
    if (lower < 0)
        lower += 360;
    if (upper > lower)
        return (ang2 <= upper && ang2 >= lower);
    else
        return (ang2 <= upper || ang2 >= lower);

}
int main()
{
    int nVert, dest, a1, a2;

    cin >> nVert >> dest >> a1 >> a2;
    int vnum = 1;
    for(int i=1; i<=nVert; i++) {
        cin >> input[i].m;
        for(int j=0; j<input[i].m; j++) {
            cin >> input[i].edges[j].w >> input[i].edges[j].len >> input[i].edges[j].ang;
            input[i].edges[j].vnum = vnum++;
        }
    }
                            // build graph
    for(int i=1; i<=nVert; i++) {
        vertex_input inp = input[i];
        for(int j=0; j<inp.m; j++) {
            vertex_info inf = inp.edges[j];
//cerr << "processing vertex " << i << ", edge " << inf.w << ',' << inf.len << ',' << inf.ang <<',' << inf.vnum << endl;
                                            // determine which edges you can leave from when entering at angle inf.ang
            for(int k=0; k<inp.m; k++) {
                if (canUseEdge(inf.ang+180, inp.edges[k].ang, a1, a2)) {
                    int wnum = findVertexNum(inp.edges[k].w, i);
//cerr << "  Adding edge between " << inf.vnum << " and " << wnum << " with length " << inp.edges[k].len << endl;
                    addEdge(inf.vnum, wnum, inp.edges[k].len);
                }
            }
        }
    }
                            // create "farmhouse" vertex - attached to vertex 1
    for(int j=0; j<input[1].m; j++) {
        int wnum = findVertexNum(input[1].edges[j].w, 1);
        addEdge(0,wnum,input[1].edges[j].len);
        addEdge(input[1].edges[j].vnum,0,0);
    }

//    printGraph(vnum);
    dijkstra(0, vnum);
    int* saveDists = new int[input[dest].m];
    for(int j=0; j<input[dest].m; j++) {
        int w = input[dest].edges[j].vnum;
        saveDists[j] = graph[w].dist;
//        cerr << "distance to " << w << " = " << graph[w].dist << endl;
    }
    int minDist = INF;
    for(int j=0; j<input[dest].m; j++) {
        dijkstra(input[dest].edges[j].vnum, vnum);
//        cerr << "distance back to 0 from " << input[dest].edges[j].vnum << " = " << graph[0].dist << endl;
        if (saveDists[j] + graph[0].dist < minDist)
            minDist = saveDists[j] + graph[0].dist;
    }
if (minDist < INF)
    cout << minDist << endl;
else
  cout << "impossible" << endl;
}
