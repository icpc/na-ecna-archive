#!/usr/bin/python

def hInsert(d):
    global heap
    global nHeap

#    print nHeap

    heap[nHeap] = d
    pos = nHeap
    nHeap += 1

    while pos != 0:
        parent = (pos - 1) // 2
        if heap[parent][0] <= heap[pos][0]:
            break
        (heap[parent],heap[pos]) = (heap[pos],heap[parent])
        pos = parent

def hRemoveMin():
    global heap
    global nHeap

    nHeap -= 1

    heap[0] = heap[nHeap]

    pos = 0

    while pos < nHeap // 2:
        c = 2 * pos + 1
        if c < nHeap - 1 and heap[c+1][0] < heap[c][0]:
            c += 1
        if heap[pos][0] <= heap[c][0]:
            break
        (heap[pos],heap[c]) = (heap[c],heap[pos])
        pos = c

def hRemove(v):
    global heap
    global nHeap

    nHeap -= 1

    pos = 0
    while heap[pos][1] != v:
        pos += 1

    heap[pos] = heap[nHeap]

    while pos < nHeap // 2:
        c = 2 * pos + 1
        if c < nHeap - 1 and heap[c+1][0] < heap[c][0]:
            c += 1
        if heap[pos][0] <= heap[c][0]:
            break
        (heap[pos],heap[c]) = (heap[c],heap[pos])
        pos = c

# adjacency list input method (original method)
(nJunctions,dest,a1,a2) = map(int,raw_input().split())

if dest == 1:
    print 0
    exit(0)

nv = 0
junctions = []
vertexList = []
cost = []
selected = []
heap = []
nHeap = 0

def dijkstra(v):
    global cost
    global selected
    global heap
    global nHeap
    cost = [totalDist] * nv
    selected = [False] * nv
    cost[v] = 0
    heap = [None]*nv
    nHeap = 0
#    for i in xrange(nv):
#        hInsert([cost[i],i])
    hInsert([0,v])

#    while True:
    while nHeap > 0:
#        w = -1

        # find w with min cost
        w = heap[0][1]
        hRemoveMin()
#        for i in xrange(nv):
#            if selected[i] == False:
#                w = i
#                break

#        if w == -1:
#            break

#        for i in xrange(nv):
#            if selected[i] == False and cost[i] < cost[w]:
#                w = i

        # select that w
        selected[w] = True

        # update fringe
        for x in vertexList[w]:
            if selected[x[0]] == False and cost[w] + x[1] < cost[x[0]]:
                if cost[x[0]] < totalDist:
                    hRemove(x[0])
                cost[x[0]] = cost[w] + x[1]
                hInsert([cost[x[0]],x[0]])

#    print "cost:",cost

for i in xrange(nJunctions):
    junctions.append([])
    info = map(int,raw_input().split())
    for j in xrange(info[0]):
        junctions[i].append(info[1+3*j:4+3*j])
        vertexList.append([])
        vertexList.append([])
        junctions[i][j].append(nv)
        junctions[i][j].append(nv+1)
        nv += 2

vertexList.append([])
nv += 1

# edge list input method

# build the adjacency lists
# first, add edges between junctions
for j in xrange(len(junctions)):
    for v in junctions[j]:
        for w in junctions[v[0]-1]:
            if w[0] == j + 1:
                vertexList[v[4]].append([w[3],v[1]])

# next, add edges within each junction
for j in junctions:
    for v in j:
        angle = (v[2] + 180) % 360
        for w in j:
#            print w[2]-angle,a1,a2
#            if w[2] - angle <= a1 and w[2] - angle >= -a2:
            angle2 = (w[2] - angle + 360) % 360
#            if (angle2 < 180 and angle2 <= a1) or \
 #              (angle2 > 180 and 360 - angle2 <= a2) or \
  #             (angle2 == 180 and (a1 == 180 or a2 == 180)):
            vertexList[v[3]].append([w[4],0])

#print junctions
#print nv
#print vertexList

# find total distance of all edges in both directions
totalDist = 1
for j in junctions:
    for v in j:
        totalDist += v[1]

bestToDest = [0] * nv
cost = [0] * nv

bestGlobal = totalDist

# iterate over all edges touching junction 1
for v in junctions[0]:
    # find shortest paths
    dijkstra(v[4])
    vertexList[nv-1] = []
    # remember best distance to dest along all paths
#    print len(bestToDest),len(cost)
    for i in xrange(nv):
        bestToDest[i] = cost[i]
#    print "cost2:",cost
    # iterate over all edges touching dest; skip unreachable edges
    for w in junctions[dest-1]:
#        print "best out:",bestToDest[w[3]]
        if bestToDest[w[3]] != totalDist:
            # find shortest path back
            dijkstra(w[3])
#            vertexList[nv-1].append([w[3],0])
#    dijkstra(nv-1)

            # iterate over all edges touching junction 1
            for x in junctions[0]:
                if bestToDest[w[3]] + cost[x[3]] < bestGlobal:
                    bestGlobal = bestToDest[w[3]] + cost[x[3]]

if bestGlobal < totalDist:
    print bestGlobal
else:
    print "impossible"
