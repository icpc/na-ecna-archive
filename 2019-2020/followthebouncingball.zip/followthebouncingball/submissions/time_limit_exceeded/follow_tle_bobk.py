#!/usr/bin/python

import heapq

def findDist(p1,p2):
    return ((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1])) ** 0.5

def intersect(P,Q):
    global t

    rx = P[1][0] - P[0][0]
    ry = P[1][1] - P[0][1]

    sx = Q[1][0] - Q[0][0]
    sy = Q[1][1] - Q[0][1]

    vx = Q[0][0] - P[0][0]
    vy = Q[0][1] - P[0][1]

    d = rx * sy - ry * sx

#    print (rx,ry),(sx,sy),(vx,vy),d

    if d == 0:
        return False
    else:
        t = (vx * sy - vy * sx) / float(d)
        u = (vx * ry - vy * rx) / float(d)
#        print "info:",P,Q,t,u
#        if 0 <= t and t <= 1 and 0 <= u and u <= 1:
        if 1e-8 <= t and t <= 0.99999999 and 1e-8 <= u and u <= 0.99999999:
            return True
        else:
            return False

(w,h,n,m,l,r,s) = raw_input().split()
w = int(w)
h = int(h)
n = int(n)
m = int(m)
l = float(l)
r = int(r)
s = int(s)

polyList = []
for i in xrange(m):
    line = map(int,raw_input().split())
    vertices = []
    for j in xrange(line[0]):
        vertices.append([line[2*j+1],line[2*j+2]])
    polyList.append([line[0],line[2*line[0]+1],vertices])

#print polyList

segList = []

for k in xrange(len(polyList)):
    p = polyList[k]
    for i in xrange(p[0]):
        j = (i + 1) % p[0]
        dx = p[2][j][0] - p[2][i][0]
        dy = p[2][j][1] - p[2][i][1]
        mag = dx * dx + dy * dy
        dx /= mag ** 0.5
        dy /= mag ** 0.5
        segList.append([k,[p[2][i],p[2][j]],[-dy,dx]])

segList.append([-1,[[0,0],[0,h]],[1,0]])
segList.append([-1,[[w,0],[w,h]],[-1,0]])
segList.append([-1,[[0,h],[w,h]],[0,-1]])
segList.append([-1,[[0,0],[w,0]],[0,1]])

#print "seglist:",segList

maxDist = w
if h > maxDist:
    maxDist = h
maxDist *= 2

r *= maxDist
s *= maxDist
t=0
#for s1 in segList:
#    for s2 in segList:
#        if intersect(s1[1],s2[1]):
#            print "Error:",s1,s2,"intersect"
queue = []
for i in xrange(n):
    # yes, that's a minus. expecting a reflection
    heapq.heappush(queue,[i,[[l-r,s],[l,0]],i,len(segList)-1])

while len(queue) > 0:
#    print "Processing",queue[0]

    list = [queue[0]]
    heapq.heappop(queue)

    while len(queue) > 0 and queue[0][0] - list[0][0] <= 1e-7:
        list.append(queue[0])
        heapq.heappop(queue)

    # now count hits for each ball in the simultaneous list
    for b in list:
        poly = segList[b[3]][0]
        if poly >= 0:
            polyList[poly][1] -= 1

    # now process the balls in the list
    for b in list:
        (curTime,segP,ball,seg) = b

        poly = segList[seg][0]
        if poly < 0:
            reflects = True
        elif polyList[poly][1] > 0:
            reflects = True
        else:
            reflects = False
#    print reflects

        if reflects:
            bestSeg = segList[seg]
            endX = segP[0][0] + 2 * (segP[1][0] - segP[0][0])
            endY = segP[0][1] + 2 * (segP[1][1] - segP[0][1])

            dot = (segP[1][0] - segP[0][0]) * bestSeg[2][0] + (segP[1][1] - segP[0][1]) * bestSeg[2][1]

            refX = endX - 2 * dot * bestSeg[2][0]
            refY = endY - 2 * dot * bestSeg[2][1]
        else:
            refX = segP[0][0] + 2 * (segP[1][0] - segP[0][0])
            refY = segP[0][1] + 2 * (segP[1][1] - segP[0][1])

        segP[0] = segP[1]
        segP[1] = [refX,refY]

        segP[1][0] = segP[0][0] + (segP[1][0] - segP[0][0]) * maxDist
        segP[1][1] = segP[0][1] + (segP[1][1] - segP[0][1]) * maxDist

    #    print segP

        bestT = 2
        t = 2
        bestSeg = None
        for s in xrange(len(segList)):
            if segList[s][0] >= 0 and polyList[segList[s][0]][1] < 1:
                continue
            if intersect(segP,segList[s][1]):
    #            print t,s
                if t > 0 and t < bestT:
                    bestT = t
                    bestSeg = s
        #print segP,bestSeg,bestT

        segP[1][0] = segP[0][0] + (segP[1][0] - segP[0][0]) * bestT
        segP[1][1] = segP[0][1] + (segP[1][1] - segP[0][1]) * bestT

        deltaT = findDist(segP[0],segP[1])

        if bestSeg != None and segList[bestSeg][0] > -2:
            heapq.heappush(queue,[curTime+deltaT,segP,ball,bestSeg])

#    if bestT < 2:
#        ip = [0,0]
#        ip[0] = segP[0][0] + (segP[1][0] - segP[0][0]) * bestT
#        ip[1] = segP[0][1] + (segP[1][1] - segP[0][1]) * bestT
#        deltaT = findDist(ip,segP[0])
#        reflects = True
#        if bestSeg[0] >= 0:
#            print "hit polygon",bestSeg[0],polyList[bestSeg[0]][1]
#            polyList[bestSeg[0]][1] -= 1
#            if polyList[bestSeg[0]][1] <= 0:
#                i = 0
#                reflects = False
#                while i < len(segList):
#                    if segList[i][0] == bestSeg[0]:
#                        del segList[i]
#                    else:
#                        i += 1
#
#        if reflects:
#            segP[1][0] = segP[0][0] + (segP[1][0] - segP[0][0]) * bestT
#            segP[1][1] = segP[0][1] + (segP[1][1] - segP[0][1]) * bestT
#            print segP


#        else:
#            refX = segP[1][0]
#            refY = segP[1][1]
#            segP[1] = segP[0]
#            segP[1][0] = segP[0][0] + (segP[1][0] - segP[0][0]) * bestT
#            segP[1][1] = segP[0][1] + (segP[1][1] - segP[0][1]) * bestT

#            refX = segP[0][0] + 2 * (segP[1][0] - segP[0][0])
#            refY = segP[0][1] + 2 * (segP[1][1] - segP[0][1])

#        print segP[1],refX,refY
#        dist = ((refX-segP[1][0])*(refX-segP[1][0])+(refY-segP[1][1])*(refY-segP[1][1])) ** 0.5
#        dist = findDist([refX,refY],segP[1])

#        refX = segP[1][0] + (refX - segP[1][0]) * maxDist / dist
#        refY = segP[1][1] + (refY - segP[1][1]) * maxDist / dist

#        print "Processing",curTime,curTime+deltaT,segP,ball

#        seg = [segP[1],[refX,refY]]
#        print seg,endX,endY,dist

#        if bestSeg[0] > -2:
#            print "enqueueing",[curTime+deltaT,seg]
#            heapq.heappush(queue,[curTime+deltaT,seg,ball])
#        else:
#            print "ball",ball,"leaves"
#    else:
#        print "intersect with nothing"

for p in polyList:
    if p[1] < 0:
        print 0,
    else:
        print p[1],
print
#print maxLen
