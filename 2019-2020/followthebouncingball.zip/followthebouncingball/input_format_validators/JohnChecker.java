import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MINWH = 1;
	public static final int MAXWH = 1000;
	public static final int MINB = 1;
	public static final int MAXB = 500;
	public static final int MINOBJ = 1;
	public static final int MAXOBJ = 20;
	public static final int MINR = -10;
	public static final int MAXR = 10;
	public static final int MINS = 1;
	public static final int MAXS = 10;
	public static final int MINP = 1;
	public static final int MAXP = 10;
	public static final int MINQ = 1;
	public static final int MAXQ = 1000;
	public static final int MAXSEGS = 200;
    public static double ZEROLIM = 1.0E-9;

    public static object[] objects = new object[MAXOBJ];
    public static segment[] segs = new segment[MAXSEGS];

    public static int nSegs = 0;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
//		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void checkDoubleBounds(double x, double min, double max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static int nextInt(StringTokenizer st)
    {
        return Integer.parseInt(st.nextToken());
    }

    public static boolean intersection(segment r, segment s)   // check for intersection of ball vector with segment s
    {
        double t, u;
        double a = r.a.x;
        double b = r.a.y;
        double c = s.a.x;
        double d = s.a.y;
        double det = -a*d + b*c;
        if (Math.abs(det) <= ZEROLIM)
            return false;
        double e = s.p1.x - r.p1.x;
        double f = s.p1.y - r.p1.y;
        u = (-e*b+f*a)/det;
        if (u < 0.0 || u > 1.0)
            return false;
        t = (-e*d + f*c)/det;
        return (t >= 0.0 && t <= 1.0);
    }

    public static void checkForIntersection(int iseg, int nSegs, int okSeg, int nLines)
    {
        for(int k=0; k<nSegs; k++) {
            if (intersection(segs[k], segs[iseg]) && k != okSeg)
                printError(nLines, "segment " + segs[k] + " and segment " + segs[iseg] + " intersect");
        }
    }

    public static void checkConvexAndClockwise(int start, int stop, int nLines)
    {
        double val;
        for(int i=start; i<stop; i++) {
            val = segs[i].a.x*segs[i+1].a.y - segs[i].a.y*segs[i+1].a.x;
            if (val >= 0)
                printError(nLines, "non-convex or non-clockwise segments: " + segs[i] + " to " + segs[i+1]);
        }
        val = segs[stop].a.x*segs[start].a.y - segs[stop].a.y*segs[start].a.x;
        if (val >= 0)
            printError(nLines, "non-convex or non-clockwise segments: " + segs[stop] + " to " + segs[start]);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int w, h, n, m, r, s;
		double l;
		String line;
		int nLines=0;
		for(int i=0; i<MAXOBJ; i++)
            objects[i] = new object();
        for(int i=0; i<MAXSEGS; i++)
            segs[i] = new segment();

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 7)
            printError(nLines, "number of values on line incorrect");
        w = nextInt(st);
        h = nextInt(st);
        n = nextInt(st);
        m = nextInt(st);
        l = Double.parseDouble(st.nextToken());
        r = nextInt(st);
        s = nextInt(st);
        checkIntBounds(w, MINWH, MAXWH, "w", nLines);
        checkIntBounds(h, MINWH, MAXWH, "h", nLines);
        checkIntBounds(n, MINB, MAXB, "n", nLines);
        checkIntBounds(m, MINOBJ, MAXOBJ, "m", nLines);
        checkDoubleBounds(l, 0, w, "l", nLines);
        checkIntBounds(r, MINR, MAXR, "r", nLines);
        checkIntBounds(s, MINS, MAXS, "s", nLines);

        for(int i=0; i<m; i++) {
            nLines++;
            int p = in.nextInt();
            checkIntBounds(p, MINP, MAXP, "p", nLines);
            line = in.nextLine();
            st = new StringTokenizer(line);
            if (st.countTokens() != 2*p+1)
                printError(nLines, "number of values on line incorrect");
            int prevx, prevy;
            prevx = nextInt(st);
            prevy = nextInt(st);
            checkIntBounds(prevx, 1, w-1, "x", nLines);
            checkIntBounds(prevy, 1, h-1, "y", nLines);
            for(int j=1; j<p; j++) {
                int x, y;
                x = nextInt(st);
                y = nextInt(st);
                checkIntBounds(x, 1, w-1, "x", nLines);
                checkIntBounds(y, 1, h-1, "y", nLines);
                segs[nSegs].initSeg(prevx, prevy, x, y, i);
                prevx = x;
                prevy = y;
                nSegs++;
                if (j == 1)
                    checkForIntersection(nSegs-1, nSegs-1, -1, nLines);
                else
                    checkForIntersection(nSegs-1, nSegs-2, -1, nLines);
            }
            segs[nSegs].initSeg(prevx, prevy, (int)segs[nSegs-p+1].p1.x, (int)segs[nSegs-p+1].p1.y, i);
            nSegs++;
            checkForIntersection(nSegs-1, nSegs-2, nSegs-p, nLines);
            checkConvexAndClockwise(nSegs-p, nSegs-1, nLines);
            int q = nextInt(st);
            checkIntBounds(q, MINQ, MAXQ, "q", nLines);
        }
		if (in.hasNextLine())
			printError(nLines, "incorrect number of lines");
        System.exit(42);
	}
}

class object {
    public int nsegs;
}

class pv
{
    public double x, y;

    public pv()
    {
        x = 0;
        y = 0;
    }

    public pv(pv a)
    {
        x = a.x;
        y = a.y;
    }

    public double length()
    {
        return Math.sqrt(x*x+y*y);
    }

}

class segment
{
    public pv p1 = new pv();          // "first" endpoint
    public pv a = new pv();
    public pv n = new pv();        // edge runs from p1 to p1+a; n = normal to a pointing away from object (normalized)
    int iObj;       // index to object;

    public void initSeg(int x1, int y1, int x2, int y2, int index)
    {
        p1.x = x1;
        p1.y = y1;
        a.x = x2-x1;
        a.y = y2-y1;
        n.x = -a.y;
        n.y = a.x;
        double len = Math.sqrt(n.x*n.x + n.y*n.y);
        n.x /= len;
        n.y /= len;
        iObj = index;
    }

    public pv reflection(pv a)
    {
//cout << "reflection " << a << " on " << n << endl;
        pv aref = new pv(a);
        double dotProd = a.x*n.x + a.y*n.y;
        aref.x -= 2*dotProd*n.x;
        aref.y -= 2*dotProd*n.y;
        if (Math.abs(aref.x - (int)(aref.x+0.5)) < JohnChecker.ZEROLIM)
            aref.x = (int)(aref.x+0.5);
        if (Math.abs(aref.y - (int)(aref.y+0.5)) < JohnChecker.ZEROLIM)
            aref.y = (int)(aref.y+0.5);
        return aref;
    }

    public String toString()
    {
        return "("+p1.x+","+p1.y+")-("+(p1.x+a.x)+","+(p1.y+a.y)+")";
    }
};
