#!/usr/bin/python

import sys
import heapq

def findDist(p1,p2):
    return ((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1])) ** 0.5

def cp(a,b,c):
    return (b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])

def intersect(P,Q):
    global t

    rx = P[1][0] - P[0][0]
    ry = P[1][1] - P[0][1]

    sx = Q[1][0] - Q[0][0]
    sy = Q[1][1] - Q[0][1]

    vx = Q[0][0] - P[0][0]
    vy = Q[0][1] - P[0][1]

    d = rx * sy - ry * sx

#    print (rx,ry),(sx,sy),(vx,vy),d

    if d == 0:
        return False
    else:
        t = (vx * sy - vy * sx) / float(d)
        u = (vx * ry - vy * rx) / float(d)
#        print "info:",P,Q,t,u
#        if 0 <= t and t <= 1 and 0 <= u and u <= 1:
        if 1e-8 <= t and t <= 0.99999999 and 1e-8 <= u and u <= 0.99999999:
            return True
        else:
            return False

(w,h,n,m,l,r,s) = raw_input().split()
w = int(w)
h = int(h)
n = int(n)
m = int(m)
l = float(l)
r = int(r)
s = int(s)

if w < 1 or w > 1000 or h < 1 or h > 1000:
    print "bad board dimensions"
    sys.exit(3)

if n < 1 or n > 500:
    print "bad ball count"
    sys.exit(4)

if m < 1 or m > 20:
    print "bad object count"
    sys.exit(5)

if l < 0 or l > w:
    print "bad gun location"
    sys.exit(6)

if r < -10 or r > 10 or s < 1 or s > 10:
    print "bad gun vector"
    sys.exit(7)

polyList = []
for i in xrange(m):
    line = map(int,raw_input().split())
    vertices = []
    for j in xrange(line[0]):
        vertices.append([line[2*j+1],line[2*j+2]])
    polyList.append([line[0],line[2*line[0]+1],vertices])
    for i in xrange(line[0]):
        if cp(vertices[i],vertices[(i+1)%line[0]],vertices[(i+2)%line[0]]) >= 0:
            print "Error: not clockwise"
            sys.exit(2)

#print polyList

segList = []

for k in xrange(len(polyList)):
    p = polyList[k]
    for i in xrange(p[0]):
        j = (i + 1) % p[0]
        dx = p[2][j][0] - p[2][i][0]
        dy = p[2][j][1] - p[2][i][1]
        mag = dx * dx + dy * dy
        dx /= mag ** 0.5
        dy /= mag ** 0.5
        segList.append([k,[p[2][i],p[2][j]],[-dy,dx]])

segList.append([-1,[[0,0],[0,h]],[1,0]])
segList.append([-1,[[w,0],[w,h]],[-1,0]])
segList.append([-1,[[0,h],[w,h]],[0,-1]])
segList.append([-2,[[0,0],[w,0]],[0,1]])

for s1 in segList:
    for s2 in segList:
        if intersect(s1[1],s2[1]):
            print "Error:",s1,s2,"intersect"
            sys.exit(1)

sys.exit(42)
