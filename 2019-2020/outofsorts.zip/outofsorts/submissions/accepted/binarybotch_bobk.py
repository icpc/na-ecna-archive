#!/usr/bin/python

#n = int(raw_input())

#data = []

#while len(data) < n:
#    tmp = map(int,raw_input().split())
#    data.extend(tmp)

(n,m,a,c,x) = map(int,raw_input().split())
data = [0]*n

for i in xrange(n):
    x = (x*a + c) % m
    data[i] = x

#print data

def search(lowPos,highPos,minVal,maxVal):
    if lowPos > highPos:
        return 0

    nGood = 0

    midPos = (lowPos + highPos) // 2
    midVal = data[midPos]

#    print lowPos,highPos,minVal,maxVal,midPos,midVal

    if midVal >= minVal and midVal <= maxVal:
        nGood += 1

    if midVal < maxVal:
        nGood += search(lowPos,midPos-1,minVal,midVal)
    else:
        nGood += search(lowPos,midPos-1,minVal,maxVal)

    if midVal > minVal:
        nGood += search(midPos+1,highPos,midVal,maxVal)
    else:
        nGood += search(midPos+1,highPos,minVal,maxVal)

    return nGood

print search(0,n-1,0,max(data))
