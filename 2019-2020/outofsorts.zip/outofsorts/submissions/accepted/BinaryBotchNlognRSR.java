// Just do a plain old binary search for every value

import java.util.*;

public class BinaryBotchNlognRSR {
  public static int n,val[];
  public static long m,a,c,x0;
  public static int ans;
  public static Scanner in;

  public static void main(String[] args)
  { 
      in = new Scanner(System.in);
      n = in.nextInt();
      m = in.nextLong();
      a = in.nextLong();
      c = in.nextLong();
      x0 = in.nextLong();

      val = new int[n];
      for (int i = 0; i < n; i++) {
        val[i] = (int)((a*x0+c)%m);
        x0 = val[i];
      }

    ans = 0;
    for (int i = 0; i < n; i++) {
      if (bsearch(0,n-1,val[i]) >= 0) ans++;
    }
    System.out.println(ans);
  }

  public static int bsearch(int lo, int hi, long x) {
    if (lo > hi) return -1;

    int mid = (lo+hi)/2;
    long midval = val[mid];
    if (midval == x) {
      return mid;
    } else if (x < midval) {
      return bsearch(lo,mid-1,x);
    } else {
      return bsearch(mid+1,hi,x);
    }
  }
}
