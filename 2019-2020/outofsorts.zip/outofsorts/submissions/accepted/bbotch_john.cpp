#include <iostream>
using namespace std;

int *arr;

int bsearch(int a[], int x, int low, int high)
{
//cout << x << ' ' << low << '-' << high << endl;
    if (low > high)
        return -1;
    int mid = (low+high)/2;
    if (a[mid] == x)
        return mid;
    else if (a[mid] > x)
        return bsearch(a, x, low, mid-1);
    else
        return bsearch(a, x, mid+1, high);
}

int main()
{
    long n, m, a, c, x;

    cin >> n >> m >> a >> c >> x;
    arr = new int[n];
    for(int i=0; i<n; i++) {
        arr[i] = (a*x + c)%m;
        x = arr[i];
    }

    int foundCount = 0;
    for(int i=0; i<n; i++) {
        int loc = bsearch(arr, arr[i], 0, n-1);
        if (loc != -1) {
            foundCount++;
            if (loc != i)
                cout << "duplicate in array: " << arr[i] << " found at " << i << " and " << loc << endl;
        }
    }
    cout << foundCount << endl;
}
