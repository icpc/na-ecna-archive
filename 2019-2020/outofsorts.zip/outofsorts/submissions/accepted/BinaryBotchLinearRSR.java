// Traverse the list in "midpoint order" (i.e., midpoint,
// midpoint of left half, midpoint of right half, midpoint of left 1/4,
// midpoint of second 1/4, ...). Keep a search interval based on all
// observed values and only count a value as "findable" if it lies within
// that search interval.

import java.util.*;

public class BinaryBotchLinearRSR {
  public static int n,val[];
  public static long m,a,c,x0;
  public static int ans;
  public static Scanner in;

  public static void main(String[] args)
  { 
      in = new Scanner(System.in);
      n = in.nextInt();
      m = in.nextLong();
      a = in.nextLong();
      c = in.nextLong();
      x0 = in.nextLong();

      val = new int[n];
      for (int i = 0; i < n; i++) {
        val[i] = (int)((a*x0+c)%m);
        x0 = val[i];
      }

    ans = 0;
    search(0,n-1, Integer.MIN_VALUE, Integer.MAX_VALUE);
    System.out.println(ans);
  }

  public static void search(int lo, int hi, int min, int max) {
    if (lo > hi) return;

    int mid = (lo+hi)/2;
    int midval = val[mid];
    if (midval >= min && midval <= max)
      ans++;

    int newmin = Math.max(min,midval);
    int newmax = Math.min(max,midval);

    // now recursively search left and right

    search(lo,mid-1,min,newmax);
    search(mid+1,hi,newmin,max);
  }
}
