import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final long MINN = 1;
	public static final long MAXN = 1000000;
	public static final long MINMAC = 1;
	public static final long MAXMAC = 2147483647;        // 2^31 - 1
	public static final long MINX = 0;
	public static final long MAXX = 2147483647;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		System.exit(-1);
	}

    public static void checkLongBounds(long x, long min, long max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		long n, m, a, c, x;
		String line;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 5)
            printError(nLines, "number of values on line incorrect");
        n = Long.parseLong(st.nextToken());
        m = Long.parseLong(st.nextToken());
        a = Long.parseLong(st.nextToken());
        c = Long.parseLong(st.nextToken());
        x = Long.parseLong(st.nextToken());
        checkLongBounds(n, MINN, MAXN, "n", nLines);
        checkLongBounds(m, MINMAC, MAXMAC, "m", nLines);
        checkLongBounds(a, MINMAC, MAXMAC, "a", nLines);
        checkLongBounds(c, MINMAC, MAXMAC, "c", nLines);
        checkLongBounds(x, MINX, MAXX, "x", nLines);

        ArrayList<Long> arr = new ArrayList<>();
        for(int i=0; i<n; i++) {
            x = (a*x + c)%m;
            arr.add(x);
        }
        Collections.sort(arr);

        long l0 = arr.get(0);
        for(int i=1; i<n; i++) {
            long l1 = arr.get(i);
            if (l0 == l1)
                System.out.println("ERROR: repeated value in generated series: " + l0);
            l0 = l1;
        }
		if (in.hasNextLine())
			printError(nLines, "incorrect number of lines");
        System.exit(42);
	}
}
