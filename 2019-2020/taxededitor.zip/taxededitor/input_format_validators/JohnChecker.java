import java.util.*;

// abstract checker

public class JohnChecker
{
	public static final int MINN = 1;
	public static final int MAXN = 1000000;
	public static final int MINM = 0;
	public static final int MINL = 1;
	public static final int MAXL = 1000000000;
	public static final int MIND = 1;
	public static final int MAXD = 100000;

    public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		System.exit(-1);
	}

    public static void checkIntBounds(int x, int min, int max, String name, int nLines)
    {
        if (x < min || x > max)
            printError(nLines, "invalid " + name + " value: " + x);
    }

    public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int n, m;
		String line;
		int nLines=0;

        line = in.nextLine();
        nLines++;
        StringTokenizer st = new StringTokenizer(line);
        if (st.countTokens() != 2)
            printError(nLines, "number of values on line incorrect");
        n = Integer.parseInt(st.nextToken());
        checkIntBounds(n, MINN, MAXN, "n", nLines);
        m = Integer.parseInt(st.nextToken());
        checkIntBounds(m, MINM, n-1, "m", nLines);

        for(int i=1; i<=n; i++) {
            line = in.nextLine();
            nLines++;
            st = new StringTokenizer(line);
            if (st.countTokens() != 2)
                printError(nLines, "number of values on line incorrect");
            int l = Integer.parseInt(st.nextToken());
            checkIntBounds(l, MINL, MAXL, "l", nLines);
            int d = Integer.parseInt(st.nextToken());
            checkIntBounds(d, MIND, MAXD, "d", nLines);
        }
		if (in.hasNextLine())
			printError(nLines, "too many lines");
        System.exit(42);
	}
}
