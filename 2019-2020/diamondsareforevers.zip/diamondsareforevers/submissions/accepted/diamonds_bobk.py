#!/usr/bin/pypy

line = raw_input()

for i in xrange(1,33,2):
    if i*i == len(line):
        s = i

msg = []

b = 0
while b < s // 2:
    row = s // 2
    col = b
    while col < s // 2:
        msg.append(line[row*s+col])
        col += 1
        row -= 1
    while row < s // 2:
        msg.append(line[row*s+col])
        col += 1
        row += 1
    while col > s // 2:
        msg.append(line[row*s+col])
        col -= 1
        row += 1
    while row > s // 2:
        msg.append(line[row*s+col])
        col -= 1
        row -= 1
    b += 1

msg.append(line[b*s+b])

print "".join(msg)
