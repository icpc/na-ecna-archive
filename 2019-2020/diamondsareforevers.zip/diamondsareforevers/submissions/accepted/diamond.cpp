#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    char grid[31][31];
    int icase = 0;
    string s;

    cin >> s;
    int n = (int)sqrt(s.length());
    int k = 0;
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            grid[i][j] = s[k++];
    int r = n/2;
    int c = 0;
    int len = n/2;
    string decoded = "";
    while (len != 0) {
        for(int i=0; i<len; i++) {  // get chararcters on upward diagonal to the right...
            decoded += grid[r][c];
            r--;
            c++;
        }
        for(int i=0; i<len; i++) {  // ... downward diagonal to the right...
            decoded += grid[r][c];
            r++;
            c++;
        }
        for(int i=0; i<len; i++) {  // ... downward diagonal to the left...
            decoded += grid[r][c];
            r++;
            c--;
        }
        for(int i=0; i<len; i++) {  // ... and upward diagonal to the right.
            decoded += grid[r][c];
            r--;
            c--;
        }
        c++;                        // prepare for next diamond
        len--;
    }
    decoded += grid[r][c];

    cout << decoded << endl;
}
