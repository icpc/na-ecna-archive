// Solution to "Diamonds Are for Evers"

import java.util.*;

public class BobDiamonds {
  public static String cipher, clear;
  public static Scanner in;
  public static int casenum;

  public static void main(String[] args) {
    in = new Scanner(System.in);

    casenum = 0;
      cipher = in.nextLine();

      casenum++;
      int n = (int)(.5+Math.sqrt(cipher.length()));

      // input ciphertext, place inside grid:
      char grid[][] = new char[n][n];
      for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
          grid[i][j] = cipher.charAt(i*n+j);
        }
      }

      // decode cleartext:
      clear = "";
      int d[] = {-1,1,1,-1}; // increments/decrements for row, col
      int dir = 3; // one of four directions
      int ring = 0;
      int r = n/2, c = 0;

      while (true) {
        // Are we at a boundary? If so, change direction:
        if (r==ring||r==n-1-ring||c==ring||c==n-1-ring) {
          dir = (dir+1)%4; // BUT WE ALSO NEED TO "MOVE IN" TOWARDS CENTER
          if (dir == 0 && grid[r][c] == ' ') {
            ring += 1;
            c += 1;
          }
        }
        clear += grid[r][c];
        grid[r][c] = ' ';
        if (r==n/2 && c==n/2) break;
        r += d[dir];
        c += d[(dir+1)%4];
      }
      // Final central letter:
//      clear += grid[r][c];
      System.out.println(clear);

//      casenum++;
  }
}
