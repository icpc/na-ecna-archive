# the "ctd" file checks for spaces, leading zeros, etc. This checks for
# no more than four decimal places, but at least one decimal place after a
# period

import sys
import re

(m,n,k,s) = map(int,sys.stdin.readline().split())
if m < 1 or m > 1000 or n < 1 or n > 1000: sys.exit(43)
if k < 1 or k > 100 or s < 1 or s > 50: sys.exit(44)
if k > m+n: sys.exit(45)

line = sys.stdin.readline()
nums = line.split()
if len(nums) != m: sys.exit(46)
spaceafterdot = re.compile(r'\.\s')
toomanydec = re.compile(r'\.[0-9]{5}')
if spaceafterdot.search(line) != None:
  sys.exit(47)
if toomanydec.search(line) != None:
  sys.exit(48)

line = sys.stdin.readline()
nums = line.split()
if len(nums) != n: sys.exit(49)
if spaceafterdot.search(line) != None:
  sys.exit(50)
if toomanydec.search(line) != None:
  sys.exit(51)

sys.exit(42)
