#include <bits/stdc++.h>
using namespace std;

bool notequal(string P, const string &S, const string &T) {
  string Z = P + P;
  int total = 0;
  for (int i = 0; i < P.size(); i++) {
    if (Z.substr(i, S.size()) == S) ++total;
    if (Z.substr(i, T.size()) == T) --total;
  }
  // if (total != 0) printf("P=%s\n", P.c_str());
  return total > 0;
}

void solve() {
  string A, S, T;
  cin >> A >> S >> T;
  if (S.size() < T.size()) swap(S, T);
  if (A.size() > 2) {
    puts("0");
    return;
  }
  queue<string> q;
  q.push(S);
  int attempt = 1000;
  while (!q.empty() && attempt-- > 0) {
    string P = q.front(); q.pop();
    if (notequal(P, S, T)) {
      puts("0");
      return;
    }
    for (char x : A) q.push(P + x);
  }
  puts("1");
  return;
}

int main() {
  int T;
  cin >> T;
  while(T--) solve();
  return 0;
}
