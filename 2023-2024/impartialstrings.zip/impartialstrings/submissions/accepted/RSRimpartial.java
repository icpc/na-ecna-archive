import java.util.*;

public class RSRimpartial {
  public static boolean debug;
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    String sigma,u,v;
    int k = in.nextInt();

    debug = (args.length > 0);
    for (int i = 0; i < k; i++) {
      sigma = in.next();
      u = in.next();
      v = in.next();
      if (debug) System.out.println("sigma,u,v="+sigma+" "+u+" "+v);

      if (u.contains(v) || v.contains(u)) {
        System.out.println(1);
        continue;
      }
      if (sigma.length() > 2) {
        System.out.println(0);
        continue;
      }
      if (u.length() < v.length()) {
        String temp = u;
        u = v;
        v = temp;
      }
      boolean ok = check(sigma,u,v);
      if (ok) System.out.println(1);
      else System.out.println(0);
    }
  }

  public static boolean check(String sigma, String u, String v) {
    boolean ok = overlap(u,v);
    if (ok) {
      if (v.charAt(0) == v.charAt(v.length()-1)) {
        if (debug) System.out.println("v[0] = v[last] = "+v.charAt(0));
        return false;
      }
      int m,n;
      if (v.charAt(0)==sigma.charAt(0)){
        m = pref(v,sigma.charAt(0));
        n = suff(v,sigma.charAt(1));
      }
      else {
        m = suff(v,sigma.charAt(0));
        n = pref(v,sigma.charAt(1));
      }
      if (m!=1 && n!= 1) {
        if (debug) System.out.println("m,n = "+m+" "+n);
        return false;
      }
      ok = (u+u).contains(v);
      if (debug) System.out.println("ok="+ok);
    }
    return ok;
  }

  public static int pref(String s, char c) {
    int i = 0;
    while (s.charAt(i)==c) i++;
    return i;
  }

  public static int suff(String s, char c) {
    if (debug) System.out.println("suff with s,c ="+s+" "+c);
    int i = 0;
    while (s.charAt(s.length()-i-1)==c) {
      i++;
      if (debug) System.out.println("i="+i);
    }
    return i;
  }

  public static boolean overlap(String u, String v) {
    boolean ok = true;
    int ul = u.length();
    for (int i = 1; i < ul-1; i++) {
      if (u.substring(0,i).equals(u.substring(ul-i))) {
        if (debug) System.out.println("prefix="+u.substring(0,i));
        String t = u+u.substring(i);
        if (t.length() < v.length() || ! t.contains(v)) {
          if (debug) System.out.println(v+" is not in "+t);
          return false;
        }
      }
    }
    return true;
  }


}
