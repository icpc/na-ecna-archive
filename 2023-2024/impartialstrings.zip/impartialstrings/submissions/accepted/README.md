This directory contains submissions that should receive the Accepted judge verdict.
