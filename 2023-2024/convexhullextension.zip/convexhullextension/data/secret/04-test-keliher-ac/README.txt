The test cases in the 04-test-keliher-ac folder are designed to hit
various lines of code in Liam's solution.
