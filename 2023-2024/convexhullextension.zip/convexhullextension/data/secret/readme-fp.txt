convex hull extension problems:
1000,1001 triangle on two sides (resp top&bottom) are very large
	results barely fit in a 32 bit int
1002 has non integer third vertices and the triangle is very long but contains no lattic points
1003 is a modification of ce3.in with non integer outer triangle vertices
1004, 1005 triangle up-right & down-left (resp up-left and down right)
	are very long but narrow

3001 very large hexagon, barely exceed 32 bit signed int
3002-3006 random convex polygons by randomly sampling some points and compute its convex hull

3007 is a smallest octogon (answer = 0); suggested by @bonomojp
