#!/usr/bin/python3

import random

coord_max = 100000
coord_min = -coord_max
trees_max = 5000
data_points_max = 1000
r_max = 1000

rx = 600
ry = 400
trees = [(0, 0), (1000, 1000), (1000, 999)]
while len(trees) < trees_max:
    x = random.randint(coord_min, coord_max)
    y = random.randint(coord_min, coord_max)
    while abs(x-rx) + abs(y-ry) <= r_max:
        x = random.randint(coord_min, coord_max)
        y = random.randint(coord_min, coord_max)
    trees.append((x, y))
print(f'{len(trees)} 3 {r_max}')
for tx, ty in trees:
    print(f'{tx} {ty}')
print('-600 -400')
print('400 600')
print('400 599')
