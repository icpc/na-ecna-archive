01, 05-35: first and last values with answers 2, 3, ..., 18 and first value to give 1
02,03,04: check for correct handling of internal 0's