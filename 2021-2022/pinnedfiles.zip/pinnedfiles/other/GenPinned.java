import java.util.Random;

public class GenPinned {
	public static final int MAXVALS = 100;

	public static int[] initOrder = new int[MAXVALS];
	public static int[] finalOrder = new int[MAXVALS];

	public static void main(String[] args) {

		Random rnd = new Random();
		int size = 20;//rnd.nextInt(51) + 50;
		for(int i=0; i<size; i++)
			initOrder[i] = finalOrder[i] = i+1;
		for(int i=1; i<size; i++) {
			int j = rnd.nextInt(i+1);
			int tmp = initOrder[i];
			initOrder[i] = initOrder[j];
			initOrder[j] = tmp;
		}
		for(int i=1; i<size; i++) {
			int j = rnd.nextInt(i+1);
			int tmp = finalOrder[i];
			finalOrder[i] = finalOrder[j];
			finalOrder[j] = tmp;
		}
		int p = rnd.nextInt(size+1);
//		int p = size;
		System.out.println(p + " " + (size-p));
		System.out.print(initOrder[0]);
		for(int i=1; i<size; i++)
			System.out.print(" " + initOrder[i]);
		System.out.println();
		//p = rnd.nextInt(size+1);
		p = size;
		System.out.println(p + " " + (size-p));
		System.out.print(finalOrder[0]);
		for(int i=1; i<size; i++)
			System.out.print(" " + finalOrder[i]);
		System.out.println();
	}

}
