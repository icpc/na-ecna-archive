01,02: 01 input that lead to largest long value calculated by my code; 02 has p value one less than 01
03,04: 03 another input that lead to a large long value in my code; 04 has p value one less that 03
05,06: largest values for m, n and p
07-12: smallest values for m, n and p
13-33: random cases