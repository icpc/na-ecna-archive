#include <iostream>
#include <random>

using namespace std;

int main() {
    random_device
        rd;
    mt19937
        mt(rd());
    uniform_int_distribution<>
        wDis(1,100000),
        rDis(0,1000);

    int32_t
        nWeeks = wDis(mt);

    cout << nWeeks << endl;

    for (int32_t i=0;i<nWeeks;i++) {
        int32_t
            val = rDis(mt);

        cout << val;

        if (i % 10 == 9)
            cout << '\n';
        else if (i < nWeeks - 1)
            cout << ' ';
    }

    if (nWeeks % 10 != 0)
        cout << '\n';

    return 0;
}
