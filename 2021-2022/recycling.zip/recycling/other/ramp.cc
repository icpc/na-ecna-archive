#include <iostream>

using namespace std;

int main() {

  cout << "100000" << endl;
  for (int i=1;i<=100000;i++) {
    cout << i;
    if (i % 15 == 14 || i == 100000)
      cout << endl;
    else
      cout << ' ';
  }
  
  cout << endl;
  
  return 0;
}

