import java.util.Scanner;

public class Recycling_WA_John {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		
		int [] heights = new int[n];
		int maxHeight = 0, minHeight = Integer.MAX_VALUE;
		for(int i=0; i<n; i++) {
			heights[i] = in.nextInt();
			if (heights[i] < minHeight)
				minHeight = heights[i];
			if (heights[i] > maxHeight)
				maxHeight = heights[i];
		}
		long areaWithMinHeight = minHeight*(long)n;
												// find largest rectangle with max height
		int maxWidth = 0;
		int maxStart=-1, maxEnd=-1;
		for(int i=0; i<n; i++) {
			if (heights[i] != maxHeight)
				continue;
			int start = i, end = i;
			while (start >= 0 && heights[start] >= heights[i])
				start--;
			start++;
			while (end < n && heights[end] >= heights[i])
				end++;
			end--;
			if (end-start+1 > maxWidth) {
				maxWidth = end-start+1;
				maxStart = start;
				maxEnd = end;
			}
		}
		long areaWithMaxHeight = maxWidth*(long)maxHeight;
		if (areaWithMaxHeight > areaWithMinHeight)
			System.out.println((maxStart+1) + " " + (maxEnd+1) + " " + areaWithMaxHeight);
		else
			System.out.println("1 " + n + " " + areaWithMinHeight);
	}

}
