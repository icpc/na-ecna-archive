# Make sure points are counterclockwise!
# Assume convex.
# Assume points are ordered either clockwise or counterclockwise.
# Pick three points, find centroid, make sure it lies to the left of an edge

import sys

def left(x,y):
  return x[0]*y[1]+x[1]*y[2]+x[2]*y[0] - x[1]*y[0]-x[2]*y[1]-x[0]*y[2] > 0

[xc,yc,r] = list(map(int,sys.stdin.readline().split()))
bound = 10**4
if (r > bound - xc) or (r > xc + bound) or (r > bound - yc) or (r > yc + bound):
  sys.exit(43)
line = list(map(int,sys.stdin.readline().split()))
n = line[0]
x = [0,0,0]
y = [0,0,0]
for i in range(3): # assume n >= 3
  x[i] = line[2*i+1]
  y[i] = line[2*i+2]
xm = sum(x)/3
ym = sum(y)/3
if left(x,y):
  sys.exit(42)
else:
  sys.exit(43)
