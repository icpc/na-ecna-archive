//
// Created by Robert Kramer on 11/30/21.
//

#ifndef _DISJOINTSET_H
#define _DISJOINTSET_H

#include <cstdint>

class DisjointSet {
public:
    explicit DisjointSet(uint32_t);
    ~DisjointSet();

    uint32_t dsFind(uint32_t);
    void dsUnion(uint32_t,uint32_t);

private:
    uint32_t
        *elements;
    uint8_t
        *rank;
};


#endif //_DISJOINTSET_H
