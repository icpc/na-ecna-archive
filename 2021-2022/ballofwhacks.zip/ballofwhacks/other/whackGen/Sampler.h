//
// Created by Robert Kramer on 11/30/21.
//

#ifndef WHACKGEN_SAMPLER_H
#define WHACKGEN_SAMPLER_H

#include <cstdint>
#include <stdexcept>
#include <random>

class Sampler {
public:
    explicit Sampler(uint32_t);
    ~Sampler();

    uint32_t getSample();
private:
    uint32_t
        *elements,
        nElements;
    std::random_device
        *rd;
    std::mt19937
        *mt;
};


#endif //WHACKGEN_SAMPLER_H
