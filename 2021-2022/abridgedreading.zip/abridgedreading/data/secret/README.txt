01,02: smallest cases
03-06: 1000 nodes, single tree
07: 1000 nodes, 1000 trees
08-10: 1000 nodes, random number of trees
11,12: full tree, left paths mostly 1's except for large leaves, right paths from root 10's
13: full tree, random sizes <= 100, second tree with very large single node
14,15: two spindly trees, second requiring going to the very bottom
16-19: constant branching trees, branch factors = 999, 30, 9 and 5
20: small change to sample input resulting in two branches from root
21: 1000 nodes, 500 trees
22-30: 10 more largish random cases