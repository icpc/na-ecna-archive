01-04: 50x50, 0% prob of water, answers use each of 4 corners
05-08: 50x50, 33% prob of water, answers use each of 4 corners
09-12: 50x50, 67% prob of water, answers use each of 4 corners
13-16: 50x50, 99% prob of water, answers use each of 4 corners
17,18: 1x1, one without water, one with
19-21: modifications of sample 2 with answer 0 for each of the other 3 corners
22,23: 1x50, one without water, one with
24,25: 50x1, one without water, one with
26-35: random cases
