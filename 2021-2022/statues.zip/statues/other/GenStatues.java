import java.util.Random;

public class GenStatues {

	public static void main(String [] args)
	{
		Random rnd = new Random();
		double probWater = 0.9;
		int rows = 10;
		int cols = 10;
		int n = rows*cols;
		int [] a = new int[n];
		for(int i=0; i<n; i++) {
			a[i] = i+1;
		}
		for(int i=1; i<n; i++) {
			int j = rnd.nextInt(i+1);
			int tmp = a[i];
			a[i] = a[j];
			a[j] = tmp;
		}
		System.out.println(rows + " " + cols);
		int i=0;
		for(int r=0; r<rows; r++) {
			if (rnd.nextDouble() < probWater)
				System.out.print("-1");
			else
				System.out.print(a[i++]);
			for(int c=1; c<cols; c++) {
				if (rnd.nextDouble() < probWater)
					System.out.print(" -1");
				else
					System.out.print(" " + a[i++]);
			}
			System.out.println();
		}
	}
}
