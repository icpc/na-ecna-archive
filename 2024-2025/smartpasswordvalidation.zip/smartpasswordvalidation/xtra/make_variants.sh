#!/bin/bash

#set -x

BASE_FILE="../submissions/accepted/smart_password_finn.py"
TOTAL_LINES=$(cat ${BASE_FILE} | wc -l | awk ' { print $1 }')

for ((i = 71 ; i < 121 ; i++ ));
do
    FILENAME="../submissions/wrong_answer/missing_shift_${i}.py"
    TAIL_LINES=$((TOTAL_LINES - $i))
    head -n $((i - 1)) ${BASE_FILE}  > $FILENAME
    LINE=$(head -n $i ${BASE_FILE} | tail -n 1)
    echo "# ${LINE}" >> $FILENAME
    tail -n "${TAIL_LINES}" "${BASE_FILE}" >> "${FILENAME}"
done
