import java.util.*;

public class RSRpw {
  public static String leftlet = "qwertasdfgzxcvbQWERTASDFGZXCVB";
  public static String llshift = "wertysdfghxcvbnWERTYSDFGHXCVBN";
  public static String rightlet = "yuiophjklnmYUIOPHJKLNM";
  public static String rlshift =  "tyuioghjkbnTYUIOGHJKBN";
  public static String leftsym = "~`!1@2#3$4%5^6";
  public static String lsshift = "!1@2#3$4%5^6&7";
  public static String rightsym = "&7*8(9)0_-+={[}]|\\:;\"'<,>.?/";
  public static String rsshift =  "^6&7*8(9)0_-Pp{[}]Ll:;Mm<,>.";
  public static String chartype[] = {leftlet,rightlet,leftsym,rightsym};
  public static String shift[] = {llshift,rlshift,lsshift,rsshift};

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    String pw = in.next();
    int n = in.nextInt();
    for (int i = 0; i < n; i++) {
      String p = in.next();
      if (pw.length() != p.length()) {
        mcec(pw,p);
      } else {
        samelength(pw,p);
      }
    }
  }

  // Equality test, but letters must be of opposite case. Symbols must
  // match exactly.
  public static boolean swapcase(char pw, char p) {
    char pw1 = Character.toLowerCase(pw); // symbols are unaffected
    char p1 = Character.toLowerCase(p);
    if (pw1 != p1) return false;
    if ((Character.isUpperCase(pw) && Character.isUpperCase(p)) ||
        (Character.isLowerCase(pw) && Character.isLowerCase(p))) {
      return false;
    }
    return true;
  }

  // Missing or extra character. pw = password, p = user input
  public static void mcec(String pw, String p) {
    boolean mc = true; // initially, assume there's a missing character
    if (pw.length() < p.length()) { // oops--extra character
      String temp = pw; // swap p and pw, treat as if missing char ...
      pw = p; p = temp; mc = false; // ... but remember the swap!
    }
    int n = pw.length();
    for (int miss = 0; miss < n; miss++) {
      String pwt = pw.substring(0,miss) + pw.substring(miss+1); // drop one char
      int clstate = -1 ; // no assumption about caps lock
      boolean ok = true;
      for (int i = 0; i < n-1; i++) { // char-by-char comparison of pwt and p
        char pwc = pwt.charAt(i);
        char pc = p.charAt(i);
        // alphabetic characters have to match exactly apart from case
        if (Character.isLetter(pwc)) {
          if (pwc == pc) {
            if (clstate == 1) { // caps lock is on, so they shouldn't match
              ok = false; break;
            } else {
              clstate = 0;
            }
          } else if (swapcase(pwc,pc)) { 
            if (clstate == 0) { // caps lock is off, so they should match
              ok = false; break;
            } else {
              clstate = 1;
            }
          } else {
            ok = false; break;
          }
        } else if (pwc != pc) {
          ok = false; break;
        }
      }
      if (ok) { // success
        System.out.println("YES");
        return;
      }
    }
    System.out.println("NO");
  }

  public static void samelength(String pw, String p) {


    int state[] = {-1,-1,-1}; // {CL,LS,RS}; -1 = ?, 0 = off, 1 = on
    int n = pw.length();

    for (int i = 0; i < n; i++) {
      char pwc = pw.charAt(i);
      char pc = p.charAt(i);
      int code = -1, loc = -1;
      for (int j = 0; j < 4; j++) {
        int l = chartype[j].indexOf(pwc);
        if (l >= 0) {
          code = j; loc = l;
          break;
        }
      }
      if (!match(pwc,pc,code,chartype[code],shift[code],loc,state)) {
        System.out.println("NO");
        return;
      }
    }
    // Tricky case: don't allow BOTH shifts to occur!
    if (state[1] == 1 && state[2] == 1) {
      System.out.println("NO");
    } else {
      System.out.println("YES");
    }
  }

  public static boolean match(char pwc, char pc, int code, String ctype,
                              String shift, int loc, int[] state) {
    // Is pwc a letter or a symbol?
    boolean islet = (code < 2);
    // Is pwc on left or right?
    int side = 1+code%2;
    // If characters agree and no caps lock or shift in effect, success:
    if (islet) {
      // CASE 1: letter, no CL, no shift
      if (pwc == pc && state[0] != 1 && state[side] != 1) {
        state[0] = 0; state[side] = 0; return true;
      }
      // CASE 2: letter, CL, no shift
      if (swapcase(pwc,pc) && state[0] != 0 && state[side] != 1) {
        state[0] = 1; state[side] = 0; return true;
      }
      char sh = shift.charAt(loc); 
      // CASE 3: letter, no CL, shift
      if (sh == pc && state[0] != 1 && state[side] != 0) {
        state[0] = 0; state[side] = 1; return true;
      }
      // CASE 4: letter, CL, shift
      if (swapcase(sh,pc) && state[0] != 0 && state[side] != 0) {
        state[0] = 1; state[side] = 1; return true;
      }
      return false;
    } else { // must be a symbol
      //CASE 1: symbol, no shift
      if (pwc == pc && state[side] != 1) {
        state[side] = 0; return true;
      }
      //CASE 2: symbol, no CL, shift
      char sh = shift.charAt(loc);
      if (sh == pc && state[0] != 1 && state[side] != 0) {
        if (Character.isLetter(sh)) state[0] = 0;
        state[side] = 1; return true;
      }
      // CASE 3: symbol, CL, shift
      if (Character.isUpperCase(sh)) sh = Character.toLowerCase(sh);
      else sh = Character.toUpperCase(sh);
      if (sh == pc && state[0] != 0 && state[side] != 0) {
        state[0] = 1; state[side] = 1; return true;
      }
      return false;
    }
  }
}
