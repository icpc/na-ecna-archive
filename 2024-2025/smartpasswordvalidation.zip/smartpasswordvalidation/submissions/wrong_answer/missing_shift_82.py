#!/usr/bin/python3

"""
Read the target password and precompute all possible valid inputs.
First get all possible inputs without applying CAPS-LOCK. Then
Apply CAPS-LOCK to all of them.
Use a hashset to check membership of each candidate password in the
precomputed set.

Time complexity:
94 characters, len(P).
Number of candidate passwords is 2*(94*(len(P)+1) + len(P) + 1 + 1)
Each comparison has cost O(len(P))
So:
 O(N * len(P) * len(P) * 190)

author: Finn Lidbetter
"""

from sys import stdin


left_shift_map = {
    '`': '1', 
    '1': '2', 
    '2': '3', 
    '3': '4', 
    '4': '5', 
    '5': '6', 
    '6': '7',
    '~': '!', 
    '!': '@', 
    '@': '#', 
    '#': '$', 
    '$': '%', 
    '%': '^', 
    '^': '&',
    'q': 'w', 
    'w': 'e', 
    'e': 'r', 
    'r': 't', 
    't': 'y',
    'Q': 'W', 
    'W': 'E', 
    'E': 'R', 
    'R': 'T', 
    'T': 'Y',
    'a': 's', 
    's': 'd', 
    'd': 'f', 
    'f': 'g', 
    'g': 'h',
    'A': 'S', 
    'S': 'D', 
    'D': 'F', 
    'F': 'G', 
    'G': 'H',
    'z': 'x', 
    'x': 'c', 
    'c': 'v', 
    'v': 'b', 
    'b': 'n',
    'Z': 'X', 
    'X': 'C', 
    'C': 'V', 
    'V': 'B', 
    'B': 'N',
}

right_shift_map = {
    '=': '-', 
    '-': '0', 
    '0': '9', 
    '9': '8', 
    '8': '7', 
    '7': '6',
    '+': '_', 
    '_': ')', 
    ')': '(', 
    '(': '*', 
    '*': '&', 
#     '&': '^',
    '\\': ']', 
    ']': '[', 
    '[': 'p', 
    'p': 'o', 
    'o': 'i', 
    'i': 'u', 
    'u': 'y', 
    'y': 't',
    '|': '}', 
    '}': '{', 
    '{': 'P', 
    'P': 'O', 
    'O': 'I', 
    'I': 'U', 
    'U': 'Y', 
    'Y': 'T',
    "'": ';', 
    ';': 'l', 
    'l': 'k', 
    'k': 'j', 
    'j': 'h', 
    'h': 'g',
    '"': ':', 
    ':': 'L', 
    'L': 'K', 
    'K': 'J', 
    'J': 'H', 
    'H': 'G',
    '/': '.', 
    '.': ',', 
    ',': 'm', 
    'm': 'n', 
    'n': 'b',
    '?': '>', 
    '>': '<', 
    '<': 'M', 
    'M': 'N', 
    'N': 'B',
}


def left_shift(target):
    return ''.join(left_shift_map.get(ch, ch) for ch in target)


def right_shift(target):
    return ''.join(right_shift_map.get(ch, ch) for ch in target)


def extra_character(target):
    words = []
    all_characters = list(left_shift_map.keys()) + list(right_shift_map.keys())
    for index in range(len(target) + 1):
        for extra_ch in all_characters:
            words.append(target[:index] + extra_ch + target[index:])
    return words


def missing_character(target):
    words = []
    for index in range(len(target)):
        words.append(target[:index] + target[index+1:])
    return words


def _toggle_case(ch):
    if ch.isupper():
        return ch.lower()
    if ch.islower():
        return ch.upper()
    raise ValueError


def caps_locked(words):
    results = []
    for word in words:
        results.append(''.join(_toggle_case(ch) if ch.isalpha() else ch for ch in word))
    return results


def main():
    target = stdin.readline().strip()
    valid_passwords = {target}
    valid_passwords.add(left_shift(target))
    valid_passwords.add(right_shift(target))
    valid_passwords.update(extra_character(target))
    valid_passwords.update(missing_character(target))
    valid_passwords.update(caps_locked(valid_passwords))
    num_passwords = int(stdin.readline())
    for _ in range(num_passwords):
        word = stdin.readline().strip()
        if word in valid_passwords:
            print("YES")
        else:
            print("NO")


if __name__ == '__main__':
    main()
