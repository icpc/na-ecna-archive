import java.util.Scanner;

public class PascalBoole_Bon {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		long ncases = in.nextInt();
		for(int i=1; i<=ncases; i++) {
			String funccode = in.next();
			String type = in.next();
			long ans = -2;
			if (type.equals("B")) {
				int r = in.nextInt();
				int c = in.nextInt();
				switch (funccode) {
				case "0000" : ans = b0000(r,c); break;
				case "0001" :
				case "0011" :
				case "0101" :
				case "0111" :
				case "1001" :
				case "1011" :
				case "1101" :
				case "1111" : ans = b0001(r,c); break;
				case "0010" :
				case "1010" : ans = b0010(r,c); break;
				case "0100" :
				case "1100" : ans = b0100(r,c); break;
				case "0110" : ans = b0110(r,c); break;
				case "1000" : ans = b1000(r,c); break;
				case "1110" : ans = b1110(r,c);
				}
			}
			else {	// "N"
				int r = in.nextInt();
				switch (funccode) {
				case "0000" : ans = n0000(r); break;
				case "0001" :
				case "0011" :
				case "0101" :
				case "0111" :
				case "1001" :
				case "1011" :
				case "1101" :
				case "1111" : ans = n0001(r); break;
				case "0010" :
				case "1010" : 
				case "0100" :
				case "1100" : ans = n0010(r); break;
				case "0110" : ans = n0110(r); break;
				case "1000" : ans = n1000(r); break;
				case "1110" : ans = n1110(r);
				}
			}
			System.out.println(ans);
		}
	}
	
	public static long b0000(int r, int c)
	{
		if (c == 1 || c == r)
			return 1;
		else
			return 0;
	}

	public static long b0001(int r, int c)
	{
		return 1;
	}

	public static long b0010(int r, int c)
	{
		if (c == 1 || (r+1-c)%2 == 1)
			return 1;
		else
			return 0;
	}

	public static long b0100(int r, int c)
	{
		if (c%2 == 1 || c == r)
			return 1;
		else
			return 0;
	}

	public static long b0110(int r, int c)
	{
		if (r <= 4) {
			if (r != 3 || c != 2)
				return 1;
			else return 0;
		}
		else {
			long n = (int)(Math.log(r-1)/Math.log(2) + 1.000001);
			int cutoff = (int) Math.pow(2, n-1);
			r -= cutoff;
			if (c > cutoff)
				c -= cutoff;
			if (c > r)
				return 0;
			else
				return b0110(r,c);
		}
	}

	public static long b1000(int r, int c)
	{
		if (c == 1 || c == r)
			return 1;
		else if (r%2 == 0 || c ==2 || c == r-1)
			return 0;
		else
			return 1;
	}

	public static long b1110(int r, int c)
	{
		if (c == 1 || c == r || r%2 == 0)
			return 1;
		else
			return 0;
	}

	public static long n0000(long r)
	{
		return 1+(r-1)*2;
	}

	public static long n0001(long r)
	{
		return r*(r+1)/2;
	}

	public static long n0010(long r)
	{
		long r2 = r/2;
		if (r%2 == 1)
			return (r2+1)*(r2+2)-1;
		else
			return (r2+1)*(r2+2)-r2-2;
	}

	public static long n0110(long r)
	{
		if (r <= 2) {
			return 2*r-1;
		}
		else {
			long n = (long)(Math.log(r-1)/Math.log(2) + 1.000001);
			if (r == (long)Math.pow(2, n))
				return (long)Math.pow(3, n);
			else
				return (long)Math.pow(3, n-1) + 2*n0110(r - (int)Math.pow(2, n-1));
		}

	}

	public static long n1000(long r)
	{
		switch ((int)r) {
		case 1:	return 1;
		case 2: return 3;
		case 3: return 5;
		default: 
			long r2 = r/2;
			if (r%2 == 1)
				return 2 + r2*(r2+2);   // 5 + r2*r2-1 + 2*(r2-1);
			else
				return 3 + r2*r2;		// 5 + (r2-1)*(r2-1)-1 + 2*(r2-1)			
		}
	}

	public static long n1110(long r)
	{
		switch ((int)r) {
		case 1:	return 1;
		case 2: return 3;
		default: 
			long r2 = r/2;
			if (r%2 == 0)
				return r2*(r2+3) - 1;   	// 1 + r2*(r2+1) + 2*(r2-1);
			else
				return r2*(r2+3) + 1;		// 1 + (r2+1)*r2 + 2*r2			
		}
	}
}
