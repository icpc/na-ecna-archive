import math

s = [int(x) for x in input()]
n = len(s)
num = 0
den = n * (n + 1) // 2
nxt = [n for _ in range(10)]

for i in range(n - 1, -1, -1):

    x = s[i]
    bigs = []
    nxt[x] = i
    for d in range(x + 1, 10):
        if nxt[d] != n:
            bigs.append((nxt[d], d))

    bigs.sort()

    l = i
    m = x
    for r, d in bigs:
        if d <= m:
            continue
        num += m * (r - l)
        m = d
        l = r

    num += m * (n - l)

g = math.gcd(num, den)
num //= g
den //= g

if den == 1:
    print(num)
elif num > den:
    w = num // den
    num %= den
    print(f"{w} {num}/{den}")
else:
    print(f"{num}/{den}")
