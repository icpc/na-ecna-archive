import math

s = [int(x) for x in input()]
n = len(s)
num = 0
den = n * (n + 1) // 2
last = [None for _ in range(11)]

for i, x in enumerate(s):
    last[x] = i

    src = i
    d = x
    for y in range(x + 1, 10):
        if last[y] is None:
            continue

        dist = src - last[y]
        num += dist * d

        src = last[y]
        d = y

    num += (src + 1) * d

g = math.gcd(num, den)
num //= g
den //= g

if den == 1:
    print(num)
elif num > den:
    w = num // den
    num %= den
    print(f"{w} {num}/{den}")
else:
    print(f"{num}/{den}")
