import java.util.Scanner;

public class ASV_WA_Bon {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		String s = in.next();
		int n = s.length();
		int [] digitLoc = new int[10];
		int [] index = new int[10];		// sorted index of digitLoc

		for(int i=0; i<10; i++) {
			digitLoc[i] = -1;
			index[i] = i;
		}
		long sum = 0;
		for(int i=0; i<n; i++) {
			int d = s.charAt(i) - '0';
			digitLoc[d] = i;
			int j=0;						// resort digit locations
			while (index[j] != d)
				j++;
			while (j > 0) {
				index[j] = index[j-1];
				j--;
			}
			index[0] = d;
			/*
			for(j=0; j<10; j++) {
				System.out.print(index[j] + " " + digitLoc[index[j]] + " ");
			}
			System.out.println();
			 /**/
			int stop = i;
			j=0;
			while (stop > 0 && d != 9) {		// find how long d is largest digit going backwards from stop
				while (index[j] <= d)
					j++;
				sum += d*(stop-digitLoc[index[j]]);
				d = index[j];
				stop = digitLoc[index[j]];
			}
			sum += d*(stop+1);
		}
		long den = n*(n+1)/2;
		long i = sum/den;
		long num = sum-i*den;
		long g = gcd(den, num);
		if (num == 0)
			System.out.println(i);
		else if (i == 0)
			System.out.println(num/g + "/" + den/g);
		else
			System.out.println(i + " " + num/g + "/" + den/g);
	}
	
	public static long gcd(long a, long b)
	{
		while (b != 0)  {
			long tmp = b;
			b = a%b;
			a = tmp;
		}
		return a;
	}
}
