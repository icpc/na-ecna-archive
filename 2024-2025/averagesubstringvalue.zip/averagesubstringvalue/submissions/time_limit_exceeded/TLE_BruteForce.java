// Liam Keliher, 2024
//
// TLE submission for problem "Average Substring Value" (averagesubstringvalue)
//
// Straightforward brute-force solution.
//
// Complexity: O(n^3)


import java.io.*;

public class TLE_BruteForce {
    //---------------------------------------------------------------
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        int n = s.length();
        int[] arr = new int[n];
        for (int index = 0; index < n; index++) {
            arr[index] = s.charAt(index) - '0';
        } // for index

        long valueSum = 0;
        long numIntervals = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {   // start at i
                int max = 0;
                for (int k = i; k <= j; k++) {
                    int digit = arr[k];
                    if (digit > max) {
                        max = digit;
                    } // if
                } // for k
                valueSum += max;
                numIntervals++;
            } // for j
        } // for i

        // Print answer
        if (valueSum % numIntervals == 0) {
            System.out.println(valueSum/numIntervals);
        } // if
        else {
            long g = gcd(valueSum, numIntervals);
            valueSum /= g;
            numIntervals /= g;
            if (valueSum < numIntervals) {
                System.out.println(valueSum + "/" + numIntervals);
            } // if
            else {
                long q = valueSum/numIntervals;
                long r = valueSum %= numIntervals;
                System.out.println(q + " " + r + "/" + numIntervals);
            } // if
        } // else
    } // main(String[])
    //---------------------------------------------------------------
    static long gcd(long a, long b) {
        while (b != 0) {
            long r = a % b;
            a = b;
            b = r;
        } // while
        return a;
    } // gcd(long,long)
    //---------------------------------------------------------------
} // class TLE_BruteForce
