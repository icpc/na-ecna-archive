#!/bin/bash

searched=0
diff_cases=0
while true
do
    python3 xtra/data_gen.py 8 8 --beads-min 0 --beads-max 2 > tmp.in
    python3 ../submissions/accepted/balancingart_arknave.py < tmp.in > arknave.out
    python3 ../submissions/wrong_answer/greedy.py < tmp.in > greedy.out
    diff arknave.out greedy.out
    if [[ $? -ne 0 ]]
    then
        diff_cases=$((diff_cases + 1))
        echo "Found difference ${diff_cases}!"
        cp tmp.in "greedy-breaker-${diff_cases}.in"
        cp arknave.out "greedy-breaker-${diff_cases}.ans"
    fi
    searched=$((searched + 1))
    echo "Searched ${searched}. Differences found: ${diff_cases}"
done
