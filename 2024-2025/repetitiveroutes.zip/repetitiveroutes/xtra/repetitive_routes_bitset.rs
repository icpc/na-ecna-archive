/// TLE submission.
/// For each passenger, iterate over all locations between their pickup and
/// dropoff and track locations visited in the bits of a u64 vector.

use std::io::{stdin, stdout, BufWriter, Write};

#[derive(Default)]
struct Scanner {
    buffer: Vec<String>,
}
impl Scanner {
    fn next<T: std::str::FromStr>(&mut self) -> T {
        loop {
            if let Some(token) = self.buffer.pop() {
                return token.parse().ok().expect("Failed parse");
            }
            let mut input = String::new();
            stdin().read_line(&mut input).expect("Failed read");
            self.buffer = input.split_whitespace().rev().map(String::from).collect();
        }
    }
}

fn main() {
    let mut scan = Scanner::default();
    let out = &mut BufWriter::new(stdout());

    let n = scan.next::<usize>();
    let mut location_seq = vec![];
    let mut passenger_seq = vec![];
    let mut pickup_index = vec![n+1; n];
    let mut dropoff_index = vec![n+1; n];
    for index in 0..2*n {
        let passenger = scan.next::<usize>() - 1;
        let location = scan.next::<usize>() - 1;
        passenger_seq.push(passenger);
        location_seq.push(location);
        if pickup_index[passenger] == n+1 {
            pickup_index[passenger] = index;
        } else {
            dropoff_index[passenger] = index;
        }
    }
    let mut visited_size = (2*n) / 64;
    if visited_size * 64 < 2*n {
        visited_size += 1;
    }
    let visited_size = visited_size;
    let mut complaints = 0u64;
    for passenger in 0..n {
        let mut locations_visited: Vec<u64> = vec![0; visited_size];
        for index in pickup_index[passenger]..=dropoff_index[passenger] {
            let location = location_seq[index];
            let locations_visited_index = location / 64;
            let location_bit = location % 64;
            if (locations_visited[locations_visited_index] & (1u64 << location_bit)) == 0 {
                locations_visited[locations_visited_index] |= 1u64 << location_bit;
            } else {
                complaints += 1;
            }
        }
    }

    writeln!(out, "{}", complaints);
}
