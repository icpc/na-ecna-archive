#include <cstdint>
#include <iostream>
#include <vector>

struct BIT {
    using T = int32_t;
    static constexpr T UNIT = 0;

    static constexpr T f(T a, T b) {
        return a + b;
    }

    int32_t n;
    std::vector<T> f_tree;
    BIT(int32_t n): n(n) {
        f_tree.assign(n + 1, UNIT);
    }

    // data[x] = f(data[x], v)
    void update(int32_t x, T v) {
        for (++x; x <= n; x += (x & -x)) {
            f_tree[x] = f(f_tree[x], v);
        }
    }

    // f applied to range [0..x]
    T query(int32_t x) const {
        T res = UNIT;
        for (++x; x > 0; x -= (x & -x)) {
            res = f(res, f_tree[x]);
        }

        return res;
    }
};

int main() {
    int32_t n;
    std::cin >> n;
    int32_t t = n + n;

    std::vector<int32_t> entryTime(n, -1);
    std::vector<int32_t> lastSeen(t, -1);

    BIT bit(t);
    int64_t ans = 0;
    for (int32_t i = 0; i < t; ++i) {
        int32_t c, l;
        std::cin >> c >> l;
        --c; --l;

        if (lastSeen[l] != -1) {
            ans += bit.query(lastSeen[l]);
        }
        lastSeen[l] = i;

        if (entryTime[c] == -1) {
            entryTime[c] = i;
            bit.update(i, +1);
        } else {
            bit.update(entryTime[c], -1);
            entryTime[c] = -1;
        }
    }

    std::cout << ans << '\n';

    return 0;
}
