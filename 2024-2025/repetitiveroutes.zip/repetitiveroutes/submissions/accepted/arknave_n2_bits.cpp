#include <bit>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

struct BitPrefixSum {
    std::vector<uint64_t> bits;

    BitPrefixSum(size_t n) {
        bits.resize((n + 63) / 64, 0);
    }

    void set(uint32_t x) {
        bits[x / 64] |= (1ULL << (x % 64));
    }

    void unset(uint32_t x) {
        bits[x / 64] &= ~(1ULL << (x % 64));
    }

    int32_t sum(uint32_t x) const {
        int32_t result = 0;
        uint32_t full = x / 64;
        uint32_t rem = x % 64;

        for (uint32_t i = 0; i < full; ++i) {
            result += std::popcount(bits[i]);
        }

        if (rem) {
            result += std::popcount(bits[full] & ((1ULL << rem) - 1));
        }

        return result;
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie();


    int32_t n;
    std::cin >> n;
    int32_t t = n + n;

    std::vector<int32_t> entryTime(n, -1);
    std::vector<int32_t> lastSeen(t, -1);

    BitPrefixSum bit(t);
    int64_t ans = 0;
    for (int32_t i = 0; i < t; ++i) {
        int32_t c, l;
        std::cin >> c >> l;
        --c; --l;

        if (lastSeen[l] != -1) {
            ans += bit.sum(lastSeen[l] + 1);
        }
        lastSeen[l] = i;

        if (entryTime[c] == -1) {
            entryTime[c] = i;
            bit.set(i);
        } else {
            bit.unset(entryTime[c]);
            entryTime[c] = -1;
        }
    }

    std::cout << ans << '\n';

    return 0;
}
