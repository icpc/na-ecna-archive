/**
 * TLE submission approach that maintains a set of visited locations
 * for each customer.
 *
 * @author Finn Lidbetter
 * Time complexity: O(n^2)
 */

fun main() {
    var numPassengers = readln().toInt()
    var steps = numPassengers * 2
    var locationSequence = IntArray(steps)
    var pickupIndex = IntArray(numPassengers) { -1 }
    var dropoffIndex = IntArray(numPassengers)
    for (index in 0..numPassengers * 2 - 1) {
        val (passenger, location) = readln().split(" ").map { it.toInt() }
        locationSequence[index] = location
        if (pickupIndex[passenger - 1] == -1) {
            pickupIndex[passenger - 1] = index
        } else {
            dropoffIndex[passenger - 1] = index
        }
    }
    var complaints = 0L
    for (passenger in 0..numPassengers - 1) {
        var locationsVisited = HashSet<Int>()
        for (locationIndex in pickupIndex[passenger]..dropoffIndex[passenger]) {
            var location = locationSequence[locationIndex]
            if (locationsVisited.contains(location)) {
                complaints++
            } else {
                locationsVisited.add(location)
            }
        }
    }
    println(complaints)
}