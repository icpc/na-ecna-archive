import java.util.Scanner;

//
// Brute-force approach: sorts intervals of repetitive stop values and then does a linear search through
//	for each passenger interval
//

public class RepetitiveRoutesTLE_Bon {

	public static final int MAX = 100000;
	
	public static class Interval
	{
		int start, stop;

		public Interval(int start, int stop)
		{
			this.start = start;
			this.stop = stop;
		}

		public String toString()
		{
			return "("+start+","+stop+")";
		}
	}

	public static int[] ends;
	public static int[] locations;
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		Interval [] passengers = new Interval[n+1];
		ends = new int[2*n+1];
		locations = new int[2*n+1];

		for(int i=1; i<=2*n; i++) {
			int p = in.nextInt();
			int l = in.nextInt();
			// create interval for each passenger
			if (passengers[p] == null)
				passengers[p] = new Interval(i, -1);
			else
				passengers[p].stop = i;
											// find previous occurrence of this location (if any)
			if (locations[l] != 0) {
				ends[locations[l]] = i;
			}
			locations[l] = i;
		}
		long sum = 0;
		for(int i=1; i<=n; i++) {
			int stop = passengers[i].stop;
			for(int j=passengers[i].start; j<stop; j++)
				if (ends[j] != 0 && ends[j] <= stop)
					sum++;
		}
		System.out.println(sum);

	}

}
