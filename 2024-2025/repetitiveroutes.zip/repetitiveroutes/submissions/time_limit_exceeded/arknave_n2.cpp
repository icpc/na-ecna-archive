#include <cstdint>
#include <iomanip>
#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie();

    int32_t n;
    std::cin >> n;
    int32_t t = n + n;

    std::vector<int32_t> entryTime(n, -1);
    std::vector<int32_t> lastSeen(t, -1);

    std::vector<int8_t> ps(t, 0);
    int64_t ans = 0;
    for (int32_t i = 0; i < t; ++i) {
        int32_t c, l;
        std::cin >> c >> l;
        --c; --l;

        if (lastSeen[l] != -1) {
            for (int32_t j = 0; j <= lastSeen[l]; ++j) {
                ans += ps[j];
            }
        }
        lastSeen[l] = i;

        if (entryTime[c] == -1) {
            entryTime[c] = i;
            ps[i]++;
        } else {
            ps[entryTime[c]]--;
            entryTime[c] = -1;
        }
    }

    std::cout << ans << '\n';

    return 0;
}
