import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

//
// Uses Mo's algorithm but without grouping intervals in blocks (i.e, does not divide start times of intervals by sqrt(n))
//

public class RepetitiveRoutesTLE2_Bon {
	public static final int MAX = 100000;
	
	public static class Interval
	{
		int start, stop;

		public Interval(int start, int stop)
		{
			this.start = start;
			this.stop = stop;
		}

		public String toString()
		{
			return "("+start+","+stop+")";
		}
	}
	
	public static class IntervalComparator implements Comparator<Interval>
	{
		public int compare(Interval iv1, Interval iv2)
		{
			int s1 = iv1.start;
			int s2 = iv2.start;
			if (s1 < s2)
				return -1;
			else if (s1 > s2)
				return 1;
			else
				return iv1.stop - iv2.stop;
		}
	}

	public static int[] locations;
	public static int[] passengers;
	public static int[] counts;
	public static int n, sqrtn;
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		sqrtn = (int)Math.sqrt(n);
		passengers = new int[n+1];
		locations = new int[2*n+1];
		ArrayList<Interval> intervals = new ArrayList<>();

		for(int i=1; i<=2*n; i++) {
			int p = in.nextInt();
			locations[i] = in.nextInt();
			// create interval for each passenger
			if (passengers[p] == 0)
				passengers[p] = i;
			else
				intervals.add(new Interval(passengers[p], i));
		}
		Collections.sort(intervals, new IntervalComparator());
		
		long total = 0;
		long sum = 0;
		int numUnique = 0;
		int left = 1, right = 0;
		counts = new int[2*n+1];
		for(Interval invl : intervals) {
			while(right < invl.stop) {
				right++;
				if (++counts[locations[right]] == 1)
					numUnique++;
				sum++;
			}
			while(right > invl.stop) {
				if (--counts[locations[right]] == 0)
					numUnique--;
				sum--;
				right--;
			}
			while(left < invl.start) {
				if (--counts[locations[left]] == 0)
					numUnique--;
				sum--;
				left++;
			}
			while(left > invl.start) {
				left--;
				if (++counts[locations[left]] == 1)
					numUnique++;
				sum++;
			}
//			System.out.print(invl + ":");
//			for(int i=1; i<=n; i++) {
//				System.out.print(" " + counts[i]);
//			}
//			System.out.println(" sum = " + sum + ", numUnique = " + numUnique);
			total += sum-numUnique;
		}
		System.out.println(total);
	}

}
