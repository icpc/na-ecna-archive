
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


#define MAX_PROFS	20

char baseString[MAX_PROFS + 1];
char outstr[MAX_PROFS + 1];

int nprofs, generator;

void shift(char *p, int n)
{
	int i;
	char *pp = p+1;
	for(i = 0; i < n ; i++)
		*p++ = *pp++;
}

int main(int argc, char **argv)
{
	int i, j, k;
	if(argc < 3) {
		fprintf(stderr, "USAGE: %s num_profs generator_int\n", argv[0]);
		return -1;
	}
	nprofs = atoi(argv[1]);
	if((nprofs < 5) || (nprofs > MAX_PROFS)) {
		fprintf(stderr, "nprofs %d not in range 5 ... %d\n", nprofs, MAX_PROFS);
		return -2;
	}
	generator = atoi(argv[2]);
	if(generator < 0) {
		fprintf(stderr, "generator must be non-negative\n");
		return -3;
	}
	for(i = 0; i < nprofs; i++) {
		baseString[i] = 'A' + i;
	}
	baseString[nprofs] = 0;
	for(i = 0, j = nprofs ; i < nprofs ; i++, j--) {
		k = generator % j;
		outstr[i] = baseString[k];
		shift(&(baseString[k]), j - k);
	}
	outstr[nprofs] = 0;
	printf("%d\n", nprofs);
	printf("%s\n", &(outstr[0]));
	return 0;
}

