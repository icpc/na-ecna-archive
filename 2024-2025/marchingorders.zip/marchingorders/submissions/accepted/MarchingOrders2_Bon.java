import java.util.Scanner;

public class MarchingOrders2_Bon {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		String s = in.next();
		
		int [] a = new int[n-1];
		int [] m = new int[n-1];	// system of equations a[i] = n mod n[i]
		
		for(int i=0; i<n-1; i++)
			m[i] = n-i;
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		for(int i=0; i<n-1; i++) {
			int index = alphabet.indexOf(s.charAt(i));
			a[i] = index;
			alphabet = alphabet.substring(0,index) + alphabet.substring(index+1);
//			System.out.println(a[i] + " = n mod " + (n-i));
		}
		
		long ans = solve(a);
		if (ans == -1)
			System.out.println("NO");
		else {
			System.out.println("YES");
			System.out.println(ans);
		}
	}

	public static long solve(int [] q)
	//
	//	find values ax + b such that (ax+b) mod i = q[n-i] i = 2, 3, ..., n  where n = q.length+1
	//
	//  start with 2x + q[n-2].  The for each i = 3, 4, ... b -> b + y*a such that (b+y*a) mod i = q[n-i]
	//														a -> a*i/gcd(a,i)
	//                                                      
	{
		int n = q.length+1;
		long a = 2;
		long b = q[n-2];
//		System.out.println(a + " " + b);
		for(int i=3; i<=n; i++) {
			if (a % i == 0) {
				if (b%i != q[n-i])
					return -1;			// else keep b the same value
			}
			else {
				b = getNextB(a, b, i, q[n-i]);
				if (b == -1)
					return -1;
			}
			a *= i/gcd(a,i);
//			System.out.println(a + " " + b);
		}
		return b;
	}
	
	public static long getNextB(long a, long b, int r, int q)
	{
		long target = (q - b%r + r)%r;
		long newa = a % r;
		for(int i=0; i<r; i++)
			if (newa*i%r == target)
				return b + a*i;
		return -1;
	}
	
	public static long gcd(long a, long b) {
	    while (b != 0) {
	    	long tmp = a;
	    	a = b;
	    	b = tmp % b;
	    }
	    return a;
	  }
}

