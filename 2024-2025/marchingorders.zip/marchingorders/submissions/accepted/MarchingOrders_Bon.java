import java.util.Scanner;

public class MarchingOrders_Bon {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		String s = in.next();
		
		int [] a = new int[n-1];
		int [] m = new int[n-1];	// system of equations a[i] = n mod n[i]
		
		for(int i=0; i<n-1; i++)
			m[i] = n-i;
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		for(int i=0; i<n-1; i++) {
			int index = alphabet.indexOf(s.charAt(i));
			a[i] = index;
			alphabet = alphabet.substring(0,index) + alphabet.substring(index+1);
		}
		
		int [] newa = new int[n-1];
		int [] newm = new int[n-1];
		for(int i=0; i<n-1; i++) {
			newa[i] = a[n-2-i];
			newm[i] = m[n-2-i];
		}
		
		long [] ans = chinese_remainder_theorem(newa, newm);
		if (ans[0] == -1)
			System.out.println("NO");
		else {
			System.out.println("YES");
			System.out.println(ans[0]);
		}
	}

	//
	// Source: https://forthright48.com/chinese-remainder-theorem-part-2-non-coprime-moduli/
	//
	public static long[] chinese_remainder_theorem( int [] a, int [] m ) {
 
		long [] result = {-1,-1};
	    int n = a.length;
	 
	    long a1 = a[0];
	    long m1 = m[0];
	    /** Initially x = a_0 (mod m_0)*/
	 
	    /** Merge the solution with remaining equations */
	    for ( int i = 1; i < n; i++ ) {
	        long a2 = a[i];
	        long m2 = m[i];
	 
	        long g = ext_gcd(m1, m2)[0];
	        if ( a1 % g != a2 % g ) return result; /** No solution exists*/
	 
	        /** Merge the two equations*/
	        long [] ans = ext_gcd(m1/g, m2/g);
	        long p = ans[1], q = ans[2];
	        long mod = m1 / g * m2; /** LCM of m1 and m2*/
	 
	        /** We need to be careful about overflow, but I did not bother about overflow here to keep the code simple.*/
	        long x = (a1*(m2/g)*q + a2*(m1/g)*p) % mod;
	 
	        /** Merged equation*/
	        a1 = x;
	        if (a1 < 0) a1 += mod; /** Result is not suppose to be negative*/
	        m1 = mod;
	    }
	    result[0] = a1;
	    result[1] = m1;
	    return result;
	}
	
	public static long[] ext_gcd(long a, long b) {	// ans[0] = gcd, a*ans[1] + b*ans[2] = gcd
	    if (b == 0) return new long[] {a, 1, 0};
	    else {
	      long[] ret = ext_gcd(b, a % b);
	      long tmp = ret[1] - ret[2] * (a / b);
	      ret[1] = ret[2];
	      ret[2] = tmp;
	      return ret;
	    }
	  }
}
