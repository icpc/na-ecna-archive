import math

def euclid(a, b):
    if b == 0:
        return a, 1, 0
    d, y, x = euclid(b, a % b)

    return d, x, y - (a // b) * x

def crt(p1, p2):
    a, m = p1
    b, n = p2
    if a < 0 or b < 0:
        return None

    d, x, y = euclid(m, n)
    if (a - b) % d != 0:
        return None

    l = (a - b) // d
    ret_mod = m // d * n
    l %= ret_mod
    ret = b + n * l * y

    return (ret % ret_mod, ret_mod)


n = int(input())
s = input()
pre = "".join(chr(ord('A') + i) for i in range(n))
ans = (0, 1)
for c in s:
    x = pre.index(c)
    m = len(pre)
    pre = pre[:x] + pre[x + 1:]
    ans = crt(ans, (x, m))
    if ans is None:
        break

# LCM(1..20) < 10^9
if ans is None:
    print("NO")
else:
    print("YES")
    print(ans[0])
