#include <iostream>
#include <cstring>
#include <numeric>
#include <cstdint>

using namespace std;

#define REPI(ctr,start,limit) for (uint32_t ctr=(start);(ctr)<(limit);(ctr)++)

const uint32_t
    MAX_NAMES = 1000,
    MAX_NAME_LEN = 256,
    MAX_M = 999999999;		// per problem spex

char
    names[MAX_NAMES][MAX_NAME_LEN];

uint32_t
    mods[MAX_NAMES];

int main() {
    uint64_t
        m,n,
        mult;
    bool
        multTooLarge = false;

    cin >> n;

    REPI(i,0,n)
//        cin >> names[i];		// if names are separate strings
        {
        cin >> names[i][0];
        names[i][1] = 0;
        }

    REPI(i,0,n) {
        mods[i] = 0;
        REPI(j,i+1,n)
            if (strcmp(names[i],names[j]) > 0)
                mods[i]++;
    }

    mult = n;
    m = mods[0];

    REPI(i,1,n) {
        REPI(j,0,n-i) {
            if (m % (n-i) == mods[i])
                break;
            if (multTooLarge) {
                cout << "NO" << endl;
                return 1;
            }
            m += mult;
        }

        if (m % (n-i) != mods[i] || m > MAX_M) {
            cout << "NO" << endl;
            return 0;
        }

        mult *= (n-i) / gcd(mult,n-i);
        if (mult > MAX_M)
            multTooLarge = true;
    }

    cout << "YES\n" << m << endl;

    return 0;
}
