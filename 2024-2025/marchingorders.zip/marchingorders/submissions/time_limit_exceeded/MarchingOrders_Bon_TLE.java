import java.util.Scanner;

public class MarchingOrders_Bon_TLE {
	public static String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		String s = in.next();
	
		for(int m=0; m<1000000000; m++) {
			if (found(n, s, m)) {
				System.out.println("YES");
				System.out.println(m);
				System.exit(0);
			}
		}
		System.out.println("NO");
	}
	
	public static boolean found(int n, String s, int m)
	{
		String list = alphabet.substring(0,n);
		String order = "";
		for(int i=n; i>0; i--) {
			int index = m%i;
			order += list.charAt(index);
			list = list.substring(0,index) + list.substring(index+1);
		}
		return order.equals(s);
	}

}
