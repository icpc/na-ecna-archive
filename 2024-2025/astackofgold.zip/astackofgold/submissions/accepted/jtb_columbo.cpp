// East Division Regional A problem
// Columbo's gold stack solution
// John Buck
// Greater NY Region
// July 2024
//


#include <iostream>
using namespace std;

#define	TUNG_COIN	29260
#define	GOLD_COIN	29370
#define	WEIGHT_DIFF	(GOLD_COIN-TUNG_COIN)

int main()
{
	int w, s, c;

	cin >> w >> s;

	c = (s * (s + 1)) / 2;

	cout << ((w - TUNG_COIN*c)/WEIGHT_DIFF) << "\n";
	return(0);
}

