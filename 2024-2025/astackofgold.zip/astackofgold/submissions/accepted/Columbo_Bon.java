import java.util.Scanner;

public class Columbo_Bon {

	public static final int GOLDWEIGHT = 29370;
	public static final int TUNGSTENWEIGHT = 29260;
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int weight = in.nextInt();
		int stacks = in.nextInt();
		int numCoins = stacks*(stacks+1)/2;
		int allT = numCoins*TUNGSTENWEIGHT;
		int diff = weight - allT;
		int goldCoins = diff/(GOLDWEIGHT-TUNGSTENWEIGHT);
		System.out.println(goldCoins);
		
	}

}
