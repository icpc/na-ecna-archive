#include <iostream>

using namespace std;

int main(){
  long long w;
  int s;

  cin >> w >> s;

  int tungsten_weight = s*(s+1)*14630;
  int diff = w-tungsten_weight;
  int num_gold = diff/110;
  cout << num_gold << endl;
  return 0;
}
