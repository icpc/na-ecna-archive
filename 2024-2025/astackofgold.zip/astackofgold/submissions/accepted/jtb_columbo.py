#!/usr/bin/python3
# East Division Regional A problem
# Columbo's gold stack solution
# John Buck
# Greater NY Region
# July 2024

TUNG_COIN = 29260
GOLD_COIN = 29370
WEIGHT_DIFF = (GOLD_COIN-TUNG_COIN)

vals = list(map(int, input().split()))
c = (vals[1] * (vals[1] + 1)) / 2
print(int((vals[0] - TUNG_COIN*c)/WEIGHT_DIFF))
