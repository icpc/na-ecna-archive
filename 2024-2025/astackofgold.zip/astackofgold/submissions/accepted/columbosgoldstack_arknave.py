TUNGSTEN = 29260
GOLD = 29370

w, s = map(int, input().split())

for i in range(1, s + 1):
    cur_weight = 0
    for j in range(1, s + 1):
        if i == j:
            cur_weight += j * GOLD
        else:
            cur_weight += j * TUNGSTEN

    if w == cur_weight:
        print(i)
        break
