/**
 * Try each stack as the stack with the gold coins and calculate what
 * the weight would be. Compare against the provided weight.
 *
 * @author Finn Lidbetter
 */

fun main() {
    val tungstenWeight = 29260
    val goldWeight = 29370
    val (totalWeight, stacks) = readln().split(" ").map { it.toInt() }
    val allTungstenWeight = (tungstenWeight * stacks * (stacks + 1)) / 2
    var goodStack = 0
    for (stackNumber in 1..stacks) {
        val weight = allTungstenWeight + stackNumber * (goldWeight - tungstenWeight)
        if (weight == totalWeight) {
            goodStack = stackNumber
            break
        }
    }
    println(goodStack)
}