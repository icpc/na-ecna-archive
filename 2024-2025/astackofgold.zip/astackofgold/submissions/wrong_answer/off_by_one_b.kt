/**
 * Off by one error that misses considering the first stack.
 *
 * @author Finn Lidbetter
 */

fun main() {
    val tungstenWeight = 29260
    val goldWeight = 29370
    val (totalWeight, stacks) = readln().split(" ").map { it.toInt() }
    val allTungstenWeight = (tungstenWeight * stacks * (stacks + 1)) / 2
    var goodStack = 0
    for (stackNumber in 2..stacks) {
        val weight = allTungstenWeight + stackNumber * (goldWeight - tungstenWeight)
        if (weight == totalWeight) {
            goodStack = stackNumber
            break
        }
    }
    println(goodStack)
}