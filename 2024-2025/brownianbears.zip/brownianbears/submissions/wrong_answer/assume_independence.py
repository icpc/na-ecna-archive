#!/usr/bin/python3

"""
This submission gets WA because it incorrectly assumes independence.

author: Finn Lidbetter
"""

from sys import stdin


class Frac:
    def __init__(self, n, d):
        self.n = n
        self.d = d

    def __add__(self, other):
        return Frac(self.d * other.n + other.d * self.n, other.d * self.d)

    def __mul__(self, other):
        return Frac(self.n * other.n, self.d * other.d)

    def __sub__(self, other):
        return Frac(self.n * other.d - self.d * other.n, self.d * other.d)

    def __str__(self):
        gcf = gcd(self.n, self.d)
        return f"{self.n//gcf}/{self.d//gcf}"

    def __repr__(self):
        return str(self)

def gcd(a, b):
    if a == 0:
        return b
    return a if b == 0 else gcd(b, a % b)


ZERO = Frac(0, 1)
ONE = Frac(1, 1)
HALF = Frac(1, 2)


def main():
    line = stdin.readline()
    n, x, y, d = map(int, line.split(' '))
    x -= 1
    y -= 1
    px = [[ZERO for _ in range(n)]]
    py = [[ZERO for _ in range(n)]]
    px[0][x] = ONE
    py[0][y] = ONE
    for _ in range(d):
        x_day = [ZERO for _ in range(n)]
        y_day = [ZERO for _ in range(n)]
        for location in range(n):
            x_day[location] = HALF * px[-1][max(0, location - 1)] + HALF * px[-1][min(location + 1, n-1)]
            y_day[location] = HALF * py[-1][max(0, location - 1)] + HALF * py[-1][min(location + 1, n-1)]
        px.append(x_day)
        py.append(y_day)
    # pd[i] is the probability of X and Y being at different locations on day[i]
    pd = []
    for day in range(d):
        p_same = ZERO
        for location in range(n):
            p_same += px[day+1][location] * py[day+1][location]
        p_different = ONE - p_same
        pd.append(p_different)
    p_all_different = ONE
    for p in pd:
        p_all_different = p_all_different * p
    p_same_at_least_once = ONE - p_all_different
    ans_n = p_same_at_least_once.n
    ans_d = p_same_at_least_once.d
    gcf = gcd(ans_n, ans_d)
    ans_n_reduced = ans_n // gcf
    ans_d_reduced = ans_d // gcf
    print(f"{ans_n_reduced}/{ans_d_reduced}")


if __name__ == "__main__":
    main()
