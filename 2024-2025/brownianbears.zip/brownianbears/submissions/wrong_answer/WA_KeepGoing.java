// Liam Keliher, 2024
//
// WA submission for problem "Brownian Bears" (brownianbears)
//
// Same as BrownianBearsKeliher.java, but "keeps going" after the bears meet,
// potentially increasing the final probability (possibly to a value > 1).


import java.io.*;

public class WA_KeepGoing {
    //---------------------------------------------------------------
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        int n = Integer.parseInt(tokens[0]);
        int x = Integer.parseInt(tokens[1]);
        int y = Integer.parseInt(tokens[2]);
        int numDays = Integer.parseInt(tokens[3]);

        long[][] prev = new long[n + 1][n + 1];   // 1-based indexing
        int leftPos = Math.min(x, y);
        int rightPos = Math.max(x, y);
        prev[leftPos][rightPos] = 1;

        long diagonalTotal = 0;
        for (int d = 1; d <= numDays; d++) {
            long[][] curr = new long[n + 1][n + 1];   // 1-based indexing
            for (int i = 1; i <= n; i++) {
                for (int j = i; j <= n; j++) {   // ERROR: should not include j == i
                    long prevEntry = prev[i][j];
                    if (prevEntry > 0) {
                        // both move left
                        int iNew = Math.max(i - 1, 1);
                        int jNew = Math.max(j - 1, 1);
                        curr[iNew][jNew] += prevEntry;

                        // both move right
                        iNew = Math.min(i + 1, n);
                        jNew = Math.min(j + 1, n);
                        curr[iNew][jNew] += prevEntry;

                        // both move outward
                        iNew = Math.max(i - 1, 1);
                        jNew = Math.min(j + 1, n);
                        curr[iNew][jNew] += prevEntry;

                        // both move inward (might swap positions)
                        iNew = Math.min(i + 1, n);
                        jNew = Math.max(j - 1, 1);
                        if (iNew < jNew) {
                            curr[iNew][jNew] += prevEntry;
                        } // if
                        else {
                            curr[jNew][iNew] += prevEntry;
                        } // else
                    } // if
                } // for j
            } // for i

            prev = curr;

            // Add up the values on the diagonal
            long numOnDiagonal = 0;
            for (int i = 1; i <= n; i++) {
                numOnDiagonal += curr[i][i];
            } // for i
            diagonalTotal = 4*diagonalTotal + numOnDiagonal;
        } // for d

        long denom = (1L << numDays)*(1L << numDays);
        long g = gcd(diagonalTotal, denom);
        System.out.println(diagonalTotal/g + "/" + denom/g);
    } // main(String[])
    //---------------------------------------------------------------
    static long gcd(long a, long b) {
        while (b != 0) {
            long r = a % b;
            a = b;
            b = r;
        } // while
        return a;
    } // gcd(long,long)
    //---------------------------------------------------------------
} // class WA_KeepGoing

