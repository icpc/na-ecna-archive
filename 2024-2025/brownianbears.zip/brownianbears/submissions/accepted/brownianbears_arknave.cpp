#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <utility>
#include <vector>

int main() {
    int32_t n, d;
    std::cin >> n;
    std::vector<uint64_t> ways(n * n, 0);

    {
        int32_t x, y;
        std::cin >> x >> y >> d;
        --x; --y;
        if (x > y)
            std::swap(x, y);

        ways[n * x + y] = 1;
    }

    static constexpr std::array<int32_t, 2> MOVES = {-1, 1};

    for (int32_t day = 0; day < d; ++day) {
        std::vector<uint64_t> newWays(n * n, 0);

        for (int32_t x = 0; x < n; ++x) {
            for (int32_t y = x + 1; y < n; ++y) {
                uint64_t w = ways[n * x + y];
                if (w == 0) continue;

                for (int32_t dx : MOVES) {
                    for (int32_t dy : MOVES) {
                        int32_t nx = std::clamp(x + dx, 0, n - 1);
                        int32_t ny = std::clamp(y + dy, 0, n - 1);

                        if (nx != ny) {
                            if (nx > ny)
                                std::swap(nx, ny);
                            newWays[n * nx + ny] += w;
                        }
                    }
                }
            }
        }

        ways = std::move(newWays);
    }

    uint64_t neverMeet = std::accumulate(ways.begin(), ways.end(), uint64_t{});

    uint64_t den = 1ULL << (2ULL * d);
    uint64_t meet = den - neverMeet;

    uint64_t g = std::gcd(meet, den);
    meet /= g;
    den /= g;

    std::cout << meet << "/" << den << '\n';

    return 0;
}
