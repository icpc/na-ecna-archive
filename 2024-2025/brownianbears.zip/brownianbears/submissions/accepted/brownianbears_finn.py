#!/usr/bin/python3

"""
Keep track of the probability that bear X is at location x and bear Y
is at location y on day i and X and Y have not met yet.
Sum up the probabilities of all location pairs on the last day. This
will be the probability, P, that the bears do not meet after d days. The
answer is then 1 - P.

Time complexity: O(D*N*N)

author: Finn Lidbetter
"""

from collections import defaultdict
from sys import stdin


def gcd(a, b):
    if a == 0:
        return b
    return a if b == 0 else gcd(b, a % b)


class Frac:
    def __init__(self, n, d):
        gcf = gcd(n,d)
        self.n = n // gcf
        self.d = d // gcf

    def __add__(self, other):
        return Frac(self.d * other.n + other.d * self.n, other.d * self.d)

    def __mul__(self, other):
        return Frac(self.n * other.n, self.d * other.d)

    def __sub__(self, other):
        return Frac(self.n * other.d - self.d * other.n, self.d * other.d)

    def __str__(self):
        gcf = gcd(self.n, self.d)
        return f"{self.n//gcf}/{self.d//gcf}"

    def __repr__(self):
        return str(self)


ZERO = Frac(0, 1)
ONE = Frac(1, 1)
HALF = Frac(1, 2)
QUARTER = Frac(1, 4)


def main():
    n, x, y, d = map(int, stdin.readline().split(' '))
    x -= 1
    y -= 1
    p = defaultdict(lambda: ZERO)
    p[(x, y, 0)] = ONE
    for day in range(d):
        for x_position in range(n):
            xl = max(x_position - 1, 0)
            xr = min(x_position + 1, n - 1)
            for y_position in range(n):
                yl = max(y_position - 1, 0)
                yr = min(y_position + 1, n - 1)
                if x_position == y_position:
                    p[(x_position, y_position, day+1)] = ZERO
                else:
                    p[(x_position, y_position, day+1)] = (
                        QUARTER * (
                            p[(xl, yl, day)] +
                            p[(xl, yr, day)] +
                            p[(xr, yl, day)] +
                            p[(xr, yr, day)]
                        )
                    )
    p_never_meet = ZERO
    for x_position in range(n):
        for y_position in range(n):
            p_never_meet += p[(x_position, y_position, d)]
    p_meet_at_least_once = ONE - p_never_meet
    print(p_meet_at_least_once)


if __name__ == "__main__":
    main()
