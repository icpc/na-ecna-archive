import java.util.Scanner;

public class BB_Bon {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n, b1, b2, d;
		n = in.nextInt();
		b1 = in.nextInt();
		b2 = in.nextInt();
		d = in.nextInt();
		long [][][] table = new long[d+1][n][n];
		for(int i=0; i<n; i++) {
			for(int j=0; j<n; j++)
				table[0][i][j] = 1;
			table[0][i][i] = 0;
		}
		for(int day = 1; day<=d; day++) {
			for(int i=0; i<n; i++) {
				for(int j=0; j<n; j++) {
					if (i == j)
						table[day][i][j] = 0;
					else {
						int ia = (i > 0) ? i-1 : 0;
						int ib = (i < n-1) ? i+1 : n-1;
						int ja = (j > 0) ? j-1 : 0;
						int jb = (j < n-1) ? j+1 : n-1;
						table[day][i][j] = table[day-1][ia][ja] +
								   table[day-1][ia][jb] +
								   table[day-1][ib][ja] +
								   table[day-1][ib][jb];
					}
				}
			}
		}
		long den = (long)Math.pow(4, d);
		long count = den - table[d][b1-1][b2-1];
		while(count%2 == 0 && den > 1) {
			count /= 2;
			den /= 2;
		}
		System.out.println(count + "/" + den);
		
	}


}
