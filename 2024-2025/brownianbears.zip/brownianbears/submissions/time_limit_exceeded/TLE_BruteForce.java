// Liam Keliher, 2024
//
// TLE submission for problem "Brownian Bears" (brownianbears)
//
// Iterates though all random sequences of moves for the two bears.


import java.io.*;

public class TLE_BruteForce {
    static final int LEFT = 0;
    static final int RIGHT = 1;
    //---------------------------------------------------------------
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        int n = Integer.parseInt(tokens[0]);
        int xStart = Integer.parseInt(tokens[1]);
        int yStart = Integer.parseInt(tokens[2]);
        int numDays = Integer.parseInt(tokens[3]);
        long max = 1L << numDays;
        long count = 0;
        for (int patternX = 0; patternX < max; patternX++) {
            for (int patternY = 0; patternY < max; patternY++) {
                int x = xStart;
                int y = yStart;
                for (int d = 0; d < numDays; d++) {
                    int moveX = (patternX >> d) & 1;
                    int moveY = (patternY >> d) & 1;
                    if (moveX == LEFT) {
                        x = Math.max(x - 1, 1);
                    } // if
                    else {   // moveA == RIGHT
                        x = Math.min(x + 1, n);
                    } // else
                    if (moveY == LEFT) {
                        y = Math.max(y - 1, 1);
                    } // if
                    else {   // moveB == RIGHT
                        y = Math.min(y + 1, n);
                    } // else
                    if (x == y) {
                        count++;
                        break;
                    } // if
                } // for d
            } // for patternB
        } // for patternA
        long g = gcd(count, max*max);
        System.out.println(count/g + "/" + max*max/g);
    } // main(String[])
    //---------------------------------------------------------------
    static long gcd(long a, long b) {
        while (b != 0) {
            long r = a % b;
            a = b;
            b = r;
        } // while
        return a;
    } // gcd(long,long)
    //---------------------------------------------------------------
} // class TLE_BruteForce
