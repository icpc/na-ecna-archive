import java.util.Scanner;

public class TreeSolution_Bon {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n, b1, b2, d;
		n = in.nextInt();
		b1 = in.nextInt();
		b2 = in.nextInt();
		d = in.nextInt();
		long den = (long)Math.pow(4, d);
		long count = den - countNoMeet(d, d, n, b1, b2);
		while(count%2 == 0 && den > 1) {
			count /= 2;
			den /= 2;
		}
		System.out.println(count + "/" + den);
		
	}

	public static long countNoMeet(int remaining, int d, int n, int b1, int b2)
	{
		if (b1 == b2) {
//			System.out.println(remaining + " " + b1 + " " + b2 + " 0");
			return 0;
		}
		if (Math.abs(b1-b2) > 2*remaining) {
//			System.out.println(remaining + " " + b1 + " " + b2 + " " + (long)Math.pow(4,  remaining));
			return (long)Math.pow(4,  remaining);
		}
		if (remaining == 0) {
//			System.out.println(remaining + " " + b1 + " " + b2 + " 1");
			return 1;
		}
		int b1a = (b1 > 1) ? b1-1 : 1;
		int b1b = (b1 < n) ? b1+1 : n;
		int b2a = (b2 > 1) ? b2-1 : 1;
		int b2b = (b2 < n) ? b2+1 : n;
		return countNoMeet(remaining-1, d, n, b1a, b2a) +
				   countNoMeet(remaining-1, d, n, b1a, b2b) +
				   countNoMeet(remaining-1, d, n, b1b, b2a) +
				   countNoMeet(remaining-1, d, n, b1b, b2b);
	}
}
