import sys
import re

# Encrypt, scan right
def eright(s,e,k,j):
  count = 0
  for i in range(len(s)):
    if e[i] != ' ': continue
    count += 1
    if count%k == 0:
      e[i] = s[j]
      j += 1
  return j

# Encrypt, scan left
def eleft(s,e,k,j):
  count = 0
  for i in reversed(range(len(s))):
    if e[i] != ' ': continue
    count += 1
    if count%k == 0:
      e[i] = s[j]
      j += 1
  return j
  
# Decrypt, scan right
def dright(s,d,k,j):
  count = 0
  for i in range(len(s)):
    if s[i] == ' ': continue
    count += 1
    if count%k == 0:
      d[j] = s[i]
      s[i] = ' '
      j += 1
  return j

# Decrypt, scan left
def dleft(s,d,k,j):
  count = 0
  for i in reversed(range(len(s))):
    if s[i] == ' ': continue
    count += 1
    if count%k == 0:
      d[j] = s[i]
      s[i] = ' '
      j += 1
  return j
  
def encrypt(s,e,key):
  dir = 1 # 1 = left to right, -1 = right to left
  j = 0 # first letter is s[0]
  for k in key:  
    if dir==1:
      j = eright(s,e,k,j)
    else:
      j = eleft(s,e,k,j)
    dir = -dir
  
def decrypt(s,d,key):
  dir = 1 # 1 = left to right, -1 = right to left
  j = 0 # first blank is s[0]
  for k in key:
    if dir==1:
      j = dright(s,d,k,j)
    else:
      j = dleft(s,d,k,j)
    dir = -dir


(t,k) = sys.stdin.readline().split() # task, key

key = [ord(x)-ord('a')+2 for x in k]+[1] # extra '1' at end for final pass
s = sys.stdin.readline().lower() # string to be processed
nonletter = re.compile('[^a-zA-Z]')
s = list(nonletter.sub('', s)) # strip out non-letters

if t == 'E':
  e = [' ']*len(s)
  encrypt(s,e,key)
  print(''.join(e))
else:
  d = [' ']*len(s)
  decrypt(s,d,key)
  print(''.join(d))
