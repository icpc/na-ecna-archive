// leapfrog.cpp : ICPC East division leapfrog problem
// John Buck, Greater NY
//

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <memory.h>

#include <iostream>
#include <string>
using namespace std;

int main()
{
	char *szAns, c;
	int nlen = 0, keylen, i, idxstr = 0, idxans = 0, idxkey = 0, dir = 0, keycnt, ik;
	int *offsets;

	string operation, key, str;
    cin >> operation >> key;

	// get cleaned up string to dec/enc
	while(cin.get(c)){
		if(isupper(c)){
			c = tolower(c);
		} else if(!islower(c)){
			continue;
		}
		str += c;
		nlen++;
	}
	keylen =(int)key.length();
	// offsets holds the converted key values
	offsets = (int *)::calloc(keylen, sizeof(int));
	for(i = 0; i < keylen; i++){
		offsets[i] = key.at(i) - 'a' + 2;
	}
	// zero out answer buffer
	szAns = (char *)::calloc(nlen+1, sizeof(char));

	// encrypt is somewhat different than decrypt, so make separate case for readability
	if(operation.at(0) == 'E'){
		while(idxstr < nlen){
			// did we run out of key?
			if(idxkey >= keylen){
				keycnt = 1;
			} else {
				keycnt = offsets[idxkey];
				idxkey++;
			}
			// left to right
			if(dir == 0){
				for(;;){
					// Look for next place to put an answer char
					for(ik = keycnt; idxans < nlen; idxans++){
						if(szAns[idxans]){
							continue;
						}
						ik--;
						if(ik == 0){
							break;
						}
					}
					if(idxans >= nlen){
						// no more fit, advance to next key char
						dir = 1;
						idxans = nlen-1;
						break;
					}
					szAns[idxans] = str[idxstr++];
				}
			} else {
				// right to left
				for(;;){
					// Look for next place to put an answer char
					for(ik = keycnt; idxans >= 0; idxans--){
						if(szAns[idxans]){
							continue;
						}
						ik--;
						if(ik == 0){
							break;
						}
					}
					if(idxans < 0){
						dir = 0;
						idxans = 0;
						break;
					}
					szAns[idxans] = str[idxstr++];
				}
			}
		}
	} else {
		// Decrypt case
		while(idxstr < nlen){
			// did we run out of key?
			if(idxkey >= keylen){
				keycnt = 1;
			} else {
				keycnt = offsets[idxkey];
				idxkey++;
			}
			if(dir == 0){
				for(;;){
					for(ik = keycnt; idxans < nlen; idxans++){
						if(str[idxans] == '!'){
							// already used this char
							continue;
						}
						ik--;
						if(ik == 0){
							break;
						}
					}
					if(idxans >= nlen){
						dir = 1;
						idxans = nlen - 1;
						break;
					}
					szAns[idxstr++] = str[idxans];
					// replace used char with ! so we can skip it above
					str[idxans] = '!';
				}
			} else {
				for(;;){
					for(ik = keycnt; idxans >= 0; idxans--){
						if(str[idxans] == '!'){
							// already used this char
							continue;
						}
						ik--;
						if(ik == 0){
							break;
						}
					}
					if(idxans < 0){
						dir = 0;
						idxans = 0;
						break;
					}
					szAns[idxstr++] = str[idxans];
					// replace used char with ! so we can skip it above
					str[idxans] = '!';
				}
			}
		}
	}
	printf("%s\n", szAns);
	return(0);
}
