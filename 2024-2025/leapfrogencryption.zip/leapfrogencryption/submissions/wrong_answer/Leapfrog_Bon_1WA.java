import java.util.Scanner;

/*
 *  wrong answer solution: always goes left-to-right on last pass
 */
public class Leapfrog_Bon_1WA {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		String ed, key, s;
		ed = in.next();
		key = in.next();
		in.nextLine();
		s = in.nextLine();
		if (ed.equals("E")) {
			s = clean(s);
			char [] cipher = new char[s.length()];
			for(int i=0; i<cipher.length; i++)
				cipher[i] = ' ';
			boolean goLeft = true;
			int k=0;					// index of plaintext
			for(int i=0; i<=key.length(); i++) {
				int skip = 1;
				if (i < key.length())
					skip = key.charAt(i) - 'a' + 2;
				int count = 0;
				if (goLeft || skip == 1) {
					for(int j=0; j<cipher.length; j++) {
						if (cipher[j] == ' ') {
							if ((++count)%skip == 0)
								cipher[j] = s.charAt(k++);
						}
					}
				}
				else {
					for(int j=cipher.length-1; j >= 0; j--) {
						if (cipher[j] == ' ') {
							if ((++count)%skip == 0)
								cipher[j] = s.charAt(k++);
						}
					}
				}
				goLeft = !goLeft;
			}
			for(int i=0; i<cipher.length; i++)
				System.out.print(cipher[i]);
			System.out.println();
		}
		else {
			char [] cipher = s.toCharArray();
			char [] plain = new char[s.length()];
			for(int i=0; i<plain.length; i++)
				plain[i] = ' ';
			boolean goLeft = true;
			int k=0;					// index of plaintext
			for(int i=0; i<=key.length(); i++) {
				int skip = 1;
				if (i < key.length())
					skip = key.charAt(i) - 'a' + 2;
				int count = 0;
				if (goLeft || skip == 1) {
					for(int j=0; j<cipher.length; j++) {
						if (cipher[j] != ' ') {
							if ((++count)%skip == 0) {
								plain[k++] = cipher[j];
								cipher[j] = ' ';
							}
						}
					}
				}
				else {
					for(int j=cipher.length-1; j >= 0; j--) {
						if (cipher[j] != ' ') {
							if ((++count)%skip == 0) {
								plain[k++] = cipher[j];
								cipher[j] = ' ';
							}
						}
					}
				}
				goLeft = !goLeft;
			}
			for(int i=0; i<plain.length; i++)
				System.out.print(plain[i]);
			System.out.println();
		}
	}

	public static String clean(String s)
	{
		s = s.toLowerCase();
		String ans = "";
		for(int i=0; i<s.length(); i++) {
			char ch = s.charAt(i);
			if (Character.isAlphabetic(ch))
				ans += ch;
		}
		return ans;
	}
}
