This directory contains submissions that should receive the Time Limit Exceeded judge verdict.
