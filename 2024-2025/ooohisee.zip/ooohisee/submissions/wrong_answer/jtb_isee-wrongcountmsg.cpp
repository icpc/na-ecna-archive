// ooohisee.cpp : Solution to the ooohisee treasure map problem
// John Buck, GNY 2024 for East Division Regional
//
#define	MAXDIM	50
#define	ZERO	'0'
#define	OH		'O'

char map[MAXDIM][MAXDIM+1];

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int r, c, savr, savc;
	int i, j, cnt = 0;

	scanf("%d %d", &(r), &(c));
	for(i = 0; i < r; i++){
		scanf("%s", &(map[i][0]));
	}
	r--;
	c--;
	for(i = 1; i < r; i++){
		for(j = 1; j < c; j++){
			if(map[i][j] == ZERO){
				if(map[i-1][j-1] == OH && map[i-1][j] == OH && map[i-1][j+1] == OH &&
					map[i][j - 1] == OH && map[i][j+1] == OH &&
					map[i + 1][j - 1] == OH && map[i + 1][j] == OH && map[i + 1][j+1] == OH){
#ifdef SHOW_MATCHES
					fprintf(stderr, "match %d,%d\n", i+1, j+1);
#endif
					savr = i;
					savc = j;
					cnt++;
				}
			}
		}
	}
	if(cnt == 0){
		printf("Oh no!\n");
	} else if(cnt > 1){
		printf("Oh no there were %d!\n", cnt);
//		printf("Oh no!\n");
	} else {
		printf("%d %d\n", savr+1, savc+1);
	}
	return(0);
}
