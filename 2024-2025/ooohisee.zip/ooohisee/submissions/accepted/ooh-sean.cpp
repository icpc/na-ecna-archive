#include <iostream>
#include <vector>

using namespace std;

bool On_Grid(const vector<vector<char> >& Grid, int r, int c){
  if(r < 0 || c < 0 || r >= Grid.size() || c >= Grid[r].size())
    return false;
  return true;
}

bool Legal(const vector<vector<char> >& Grid, int r, int c){
  if(Grid[r][c] == 'O')
    return false;
  for(int dr = -1; dr <= 1; dr++)
    for(int dc = -1; dc <= 1; dc++)
      if(dr!= 0 || dc != 0){
	if(!On_Grid(Grid, r+dr, c+dc) || Grid[r+dr][c+dc] != 'O')
	  return false;
      }
  return true;
}

int main(){
  vector<vector<char> > Grid;
  int r, c;
  cin >> r >> c;
  Grid.resize(r);
  for(int i = 0; i < r; i++)
    Grid[i].resize(c);

  for(int i = 0; i < Grid.size(); i++)
    for(int j = 0; j < Grid[i].size(); j++)
      cin >> Grid[i][j];

  int num_places = 0;
  int found_r;
  int found_c;
  for(int i = 0; i < Grid.size(); i++){
    for(int j = 0; j < Grid[i].size(); j++){
      if(Legal(Grid, i, j)){
	num_places++;
	found_r = i;
	found_c = j;
      }
    }
  }

  if(num_places == 0)
    cout << "Oh no!" << endl;
  else if(num_places == 1)
    cout << found_r+1 << " " << found_c+1 << endl;
  else
    cout << "Oh no! " << num_places << " locations " << endl;
  return 0;
}
