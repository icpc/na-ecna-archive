// Liam Keliher, 2024
//
// Solution for NA East Division problem "Oooh I See" (ooohisee)


import java.io.*;

public class OoohISeeKeliher {
    static final char ZERO = '0';
    static final char OH = 'O';
    static final int NUM_NEIGHBORS = 8;
    static final int[] rowDelta = {-1, -1, -1,  0, 0,  1, 1, 1};
    static final int[] colDelta = {-1,  0,  1, -1, 1, -1, 0, 1};
	//---------------------------------------------------------------
	public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        int numRows = Integer.parseInt(tokens[0]);
        int numCols = Integer.parseInt(tokens[1]);
        char[][] grid = new char[numRows][];
        for (int r = 0; r < numRows; r++) {
            grid[r] = br.readLine().toCharArray();
        } // for r

        int count = 0;
        int rSpecial = -1;
        int cSpecial = -1;
        for (int r = 1; r < (numRows-1); r++) {       // 0 < r < (numRows-1)
            for (int c = 1; c < (numCols-1); c++) {   // 0 < c < (numCols-1)
                if (grid[r][c] == ZERO && isSurrounded(grid, r, c)) {
                    count++;
                    if (count == 1) {
                        rSpecial = r;
                        cSpecial = c;
                    } // if
                } // if
            } // for c
        } // for r
        if (count == 0) {
            System.out.println("Oh no!");
        } // if
        else if (count == 1) {
            System.out.println((rSpecial+1) + " " + (cSpecial+1));   // convert to 1-based indexing
        } // else if
        else {   // count >= 2
            System.out.println("Oh no! " + count + " locations");
        } // else
    } // main(String[])
    //---------------------------------------------------------------
    static boolean isSurrounded(char[][] grid, int row, int col) {
        for (int i = 0; i < NUM_NEIGHBORS; i++) {
            if (grid[row + rowDelta[i]][col + colDelta[i]] == ZERO) {
                return false;
            } // if
        } // for i
        return true;
    } // isSurrounded(char[][],int,int)
    //---------------------------------------------------------------
} // class OoohISeeKeliher
