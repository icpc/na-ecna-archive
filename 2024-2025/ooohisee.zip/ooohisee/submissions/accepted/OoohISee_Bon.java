import java.util.Scanner;

public class OoohISee_Bon {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int r = in.nextInt();
		int c = in.nextInt();
		
		char [][] grid = new char[r][c];
		for(int i=0; i<r; i++) {
			String s = in.next();
			for(int j=0; j<c; j++)
				grid[i][j] = s.charAt(j);
		}
		
		int count = 0, rloc = -1, cloc = -1;
		for(int i=1; i<r-1; i++) {
			for(int j=1; j<c-1; j++) {
				if (found(grid, i, j)) {
					count++;
					rloc = i;
					cloc = j;
				}
			}
		}
		switch (count) {
		case 0: System.out.println("Oh no!"); break;
		case 1: System.out.println((rloc+1) + " " + (cloc+1)); break;
		default: System.out.println("Oh no! " + count + " locations");
		}
	}
	
	public static boolean found(char [][] grid, int r, int c)
	{
		if (grid[r][c] != '0')
			return false;
		for(int i=r-1; i<=r+1; i++) {
			for(int j=c-1; j<=c+1; j++) {
				if (i == r && j == c)
					continue;
				if (grid[i][j] != 'O')
					return false;
			}
		}
		return true;
	}

}
