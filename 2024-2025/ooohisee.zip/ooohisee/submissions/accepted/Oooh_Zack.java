import java.util.Scanner;

public class Oooh_Zack {
    public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	int r = in.nextInt();
	int c = in.nextInt();
	char[][] grid = new char[r][c];
	for (int rr = 0; rr < r; rr++) {
	    String line = in.next();
	    for (int cc = 0; cc < c; cc++) {
		grid[rr][cc] = line.charAt(cc);
	    }
	}
	int numsols = 0;
	int foundr = -1;
	int foundc = -1;
	for (int chkr = 1; chkr < r-1; chkr++) {
	    for (int chkc = 1; chkc < c-1; chkc++) {
		if (grid[chkr][chkc] == '0')
		    if ((grid[chkr-1][chkc-1] == 'O') &&(grid[chkr][chkc-1] == 'O') &&(grid[chkr+1][chkc-1] == 'O') &&(grid[chkr-1][chkc] == 'O') &&(grid[chkr+1][chkc] == 'O') &&(grid[chkr-1][chkc+1] == 'O') &&(grid[chkr][chkc+1] == 'O') &&(grid[chkr+1][chkc+1] == 'O')) {
			numsols += 1;
			if (numsols == 1) {
			    foundr = chkr;
			    foundc = chkc;
			}
		    }
	    }
	}
	if (numsols == 0) {
	    System.out.println("Oh no!");
	}
	else if (numsols == 1) {
	    System.out.println((foundr+1) + " " + (foundc+1));
	}
	else {
	    System.out.println("Oh no! " + numsols + " locations");
	    
	}
    }
}
