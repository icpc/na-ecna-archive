MOVES = set((dx, dy) for dx in range(-1, 2) for dy in range(-1, 2)) - {(0, 0)}
r, c = map(int, input().split())
grid = [input() for _ in range(r)]
candidates = []
for i in range(1, r - 1):
    for j in range(1, c - 1):
        if grid[i][j] == '0' and all(grid[i + dx][j + dy] == 'O' for dx, dy in MOVES):
            candidates.append((i + 1, j + 1))

if not candidates:
    print("Oh no!")
elif len(candidates) > 1:
    print(f"Oh no! {len(candidates)} locations")
else:
    print(*candidates[0])
