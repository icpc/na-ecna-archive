#!/usr/bin/python3

"""
Iterate over the grid and check for occurrences of
 OOO
 O0O
 OOO
Maintain a count of how many times this pattern is seen.

author: Finn Lidbetter
"""

from sys import stdin


def is_match(row, col, grid):
    return grid[row-1][col-1:col+2] == 'OOO' and grid[row][col-1:col+2] == 'O0O' and grid[row+1][col-1:col+2] == 'OOO'

line = stdin.readline()
tokens = line.split(" ")
num_rows = int(tokens[0])
num_cols = int(tokens[1])

grid = []
for _ in range(num_rows):
    grid.append(stdin.readline().strip())

matching_locations = 0
row_match = None
col_match = None
for row in range(1, num_rows-1):
    for col in range(1, num_cols-1):
        if is_match(row, col, grid):
            if row_match is None:
                row_match = row
                col_match = col
            matching_locations += 1
if matching_locations == 0:
    print("Oh no!")
elif matching_locations == 1:
    print(f"{row_match+1} {col_match+1}")
else:
    print(f"Oh no! {matching_locations} locations")
