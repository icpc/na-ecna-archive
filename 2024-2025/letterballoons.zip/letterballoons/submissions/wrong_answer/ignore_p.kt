/**
 * This submission gets wrong answer because it ignores p and
 * assumes that there are balloons available for each letter of
 * the alphabet.
 */

fun main() {
    val (p, t) = readln().split(" ").map { it -> it.toInt() }
    val teams = Array<CharArray>(t) {
        readln().toCharArray()
    }
    var bestTeams = 0
    for (teamMask in 1..((1 shl t) - 1)) {
        val numTeams = teamMask.countOneBits()
        if (numTeams <= bestTeams) {
            continue
        }
        var valid = true
        var balloonUsed = BooleanArray(26) { false }
        for (team in 0..(t-1)) {
            if (((1 shl team) and teamMask) > 0) {
                for (ch in teams[team]) {
                    if (balloonUsed[ch - 'A']) {
                        valid = false
                        break
                    } else {
                        balloonUsed[ch - 'A'] = true
                    }
                }
            }
            if (!valid) {
                break
            }
        }
        if (valid) {
            bestTeams = numTeams
        }
    }
    println(bestTeams)
}