import sys
from itertools import *

def powerset(iterable):
    # from the Python docs, edited to start with the largest sets first
    # "powerset([1,2,3]) → () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1,0,-1))

prob,ntms = [int(x) for x in input().strip().split()]
tms = []
for t in range(ntms):
    tmch = input().strip()
    tm = []
    ok = True
    for c in tmch:
        cval = ord(c)-ord('A')
        if cval >= prob: # equal is bad since cval is 0-indexed
            ok = False
        else:
            tm.append(cval)
    if ok:
        tms.append(tm)

for tset in powerset(tms):
    used = [False for _ in range(prob)]
    failed = False
    for tm in tset:
        for c in tm:
            if used[c]:
                failed = True
                break
            used[c] = True
        if failed:
            break
    if not failed:
        print(len(tset))
        sys.exit(0)
print(0)
