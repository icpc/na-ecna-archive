/**
 * Letter Balloons
 * East Division Regional, 2024
 * John Buck, Greater NY Region
 * Talk about brute force...  unnecessarily recursive implementation
 */
import java.util.*;

public class BalloonsJTB {
	private static final boolean DEBUG = false;
	
	Vector<Character> probs = new Vector<Character>();
	List<Vector<Character>> teams = new ArrayList<Vector<Character>>();
	Scanner stdin = new Scanner(System.in);

	/**
	 * Populate problemset
	 */
	private void AddProblems(int nProb) {
		int i = 0;
		// Set up problem set
		for(char c = 'A'; i < nProb; c++, i++) {
			probs.add(Character.valueOf(c));
		}
		
	}

	/**
	 * Populate teams from input file, breaking into vectors of Characters
	 */	
	private void AddTeams(int nTeam) {
		String team;
		
		// Read teams from stdin
		for(int i = 0; i < nTeam; i++) {
			team = stdin.next();
			Vector<Character> ts = new Vector<Character>();
			for(int tc = 0; tc < team.length(); tc++) {
				ts.add(Character.valueOf(team.charAt(tc)));
			}
			teams.add(ts);
		}
	}

	/**
	 * Write our own removeAll that removes only one instance of each Character in toRemove
	 */	
	private boolean removeAll(Vector<Character> v, Vector<Character> toRemove) {
		for(Character c : toRemove) {
			if(v.remove(c) == false) {
				// item not found, so this team can't do it
				return(false);
			}
		}
		return(true);
	}
	
	private int CountTeams(int team, Vector<Character> left) {
		Vector<Character> diff = new Vector<Character>(left);
		int n, cnt, most = 0;
		
		if(DEBUG) {
			System.err.printf("%nCountTeams(%d,%s)%n", team, left.toString());
		}
		
		for(int t = team; t < teams.size(); t++) {
			Vector<Character> thisTeam = teams.get(t);
			if(DEBUG) {
				System.err.printf("CountTeams: Try starting with team %d: %s%n", t, thisTeam);
			}
			diff = new Vector<Character>(left);
			if(removeAll(diff, thisTeam) == false) {
				if(DEBUG) {
					System.err.printf("CountTeams: Team %s can't fit in %s%n", thisTeam.toString(), left.toString());
				}
				continue;
			}
			cnt = 1;
			n = CountTeams(t+1, diff);
			if(n > 0) {
				cnt += n;
				if(DEBUG) {
					System.err.printf("CountTeams: CountTeams(%d,%s) returned %d - total now %d%n", t, diff.toString(), n, cnt);
				}
			}
			if(cnt > most) {
				most = cnt;
				if(DEBUG) {
					System.err.printf("CountTeams: Setting most to %d%n", most);
				}
			}
		}
		return(most);
	}
	
	private void run() {
		AddProblems(stdin.nextInt());
		AddTeams(stdin.nextInt());
		System.out.println(CountTeams(0, probs));
	}

	public static void main(String[] args) {
		// Create a context
		BalloonsJTB b = new BalloonsJTB();
		b.run();
	}
}
