import java.util.Scanner;

public class LetterBalloons_Bon {

	public static int count = 0;
	public static boolean[] used;
	public static String[] names;
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int p = in.nextInt();
		used = new boolean[p];
		int t = in.nextInt();
		names = new String[t];
		for(int i=0; i<t; i++)
			names[i] = in.next();
		
		solve(0, t, p, 0);
		System.out.println(count);
	}
	
	public static void solve(int iteam, int nteam, int nballoons, int curr)
	{
		if (iteam == nteam) {
			if (curr > count)
				count = curr;
			return;
		}
		int i=0;
		String name = names[iteam];
		while (i < name.length()) {
			char ch = name.charAt(i);
			if ((ch-'A') < nballoons && !used[ch-'A']) {
				used[ch-'A'] = true;
				i++;
			}
			else
				break;
		}
		if (i == name.length()) {
			solve(iteam+1, nteam, nballoons, curr+1);
		}
		while (--i >= 0) {
			used[name.charAt(i)-'A'] = false;
		}
		solve(iteam+1, nteam, nballoons, curr);
	}

}
