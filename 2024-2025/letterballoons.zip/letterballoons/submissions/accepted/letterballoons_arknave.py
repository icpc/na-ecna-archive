p, t = map(int, input().split())
masks = []
for _ in range(t):
    s = input()
    mask = 0
    valid = True
    for c in s:
        x = ord(c) - ord('A')
        if x >= p or ((mask >> x) & 1) > 0:
            valid = False
        mask |= (1 << x)

    if valid:
        masks.append(mask)

# two solutions in one file? :)
if p < len(masks):
    dp = [0 for _ in range(1 << p)]
    for i, x in enumerate(dp):
        for mask in masks:
            if (i & mask) == 0:
                dp[i | mask] = max(dp[i | mask], dp[i] + 1)

    print(max(dp))
else:
    ans = 0
    for mask in range(1 << len(masks)):
        cur = 0
        valid = True
        for i in range(t):
            if (mask >> i) & 1:
                valid &= (cur & masks[i]) == 0
                cur |= masks[i]

        if valid:
            ans = max(ans, bin(mask).count('1'))

    print(ans)
