/**
 * Try each combination of teams as the teams that get the letter
 * balloons to spell their initials. For each combination we need
 * to make sure that all letters are distinct and that they only
 * use the first p letters of the alphabet.
 * There are 2^t possible combinations of teams to try. When trying
 * a combination, just iterate over the letters in those teams'
 * initials and make sure the same letter does not appear more than
 * once.
 *
 * Time complexity: O(t * 2^t * 26)
 *
 * @author Finn Lidbetter
 */

fun main() {
    val (p, t) = readln().split(" ").map { it -> it.toInt() }
    val teams = Array<CharArray>(t) {
        readln().toCharArray()
    }
    var bestTeams = 0
    for (teamMask in 1..((1 shl t) - 1)) {
        val numTeams = teamMask.countOneBits()
        if (numTeams <= bestTeams) {
            continue
        }
        var valid = true
        var balloonUsed = BooleanArray(p) { false }
        for (team in 0..(t-1)) {
            if (((1 shl team) and teamMask) > 0) {
                for (ch in teams[team]) {
                    if ((ch - 'A') >= p || balloonUsed[ch - 'A']) {
                        valid = false
                        break
                    } else {
                        balloonUsed[ch - 'A'] = true
                    }
                }
            }
            if (!valid) {
                break
            }
        }
        if (valid) {
            bestTeams = numTeams
        }
    }
    println(bestTeams)
}