import java.util.Scanner;

public class Fences {

	private static class Point {
		double x, y;

		public Point()
		{ this(0,0); }
		public Point(double x, double y)
		{
			this.x = x; this.y = y;
		}
		
		public String toString()
		{
			return "(" + x + "," + y + ")";
		}
	}

	public static Point [] points;
	public static int npoints;

	public static double[][] table;     // store C(i,s) values
	public static double[][] cost;      // store distance values

	public static double [][] triWithP1;				// d[i][j] optimal cost when using a triangle with base point[i]-point[j] containing p1
	public static double [][] triWithP2;				// same with p2

	public static double dist(int i, int j)
	{
		double dx = points[i].x - points[j].x;
		double dy = points[i].y - points[j].y;
		return Math.sqrt(dx*dx+dy*dy);
	}

	public static void fillTable(int n)
	{
		table = new double[n][n+1];
		for(int i=0; i<n; i++)                // initialize table with base cases
			table[i][2] = table[i][3] = 0.0;
		// fill in remaining using
		//   recurrence relation
		for(int s=4; s<=n; s++) {
			for(int i=0; i<n; i++) {
				double mincost = table[i][2]+table[(i+1)%n][s-1] + cost[i][(i+1)%n]
						+ cost[(i+1)%n][(i+s-1)%n];
				for(int k=2; k<=s-2; k++) {
					mincost = Math.min(mincost, table[i][k+1]+table[(i+k)%n][s-k]
							+ cost[i][(i+k)%n] + cost[(i+k)%n][(i+s-1)%n]);
				}
				table[i][s] = mincost;
			}
		}
	}

	public static boolean inside(Point p, Point a, Point b, Point c)
	{
		double vabx = b.x - a.x;
		double vaby = b.y - a.y;
		double vbcx = c.x - b.x;
		double vbcy = c.y - b.y;
		double vcax = a.x - c.x;
		double vcay = a.y - c.y;
		double check1 = vabx*(p.y-a.y) - vaby*(p.x-a.x);
		double check2 = vbcx*(p.y-b.y) - vbcy*(p.x-b.x);
//		System.out.println(check1 + " " + check2);
		if (check1*check2 <= 0)
			return false;
		double check3 = vcax*(p.y-c.y) - vcay*(p.x-c.x);
//		System.out.println("   " + check3);
		return (check1*check3 > 0);
	}

	public static double[][] minTriangleContainingP(Point p) 
	// for each segment s containing two exterior vertices, find min cost of triangulization
	// with p in a triangle with s as a side
	{
		double [][] ans = new double[npoints][npoints];
		for(int i=0; i<npoints; i++)
			for(int j=0; j<npoints; j++)
				ans[i][j] = Double.MAX_VALUE;
//		System.out.println("For point " + p);
		for(int i=0; i<npoints; i++)
			for(int j=i+1; j<npoints; j++)
				for(int k=j+1; k<npoints; k++) {
//					System.out.println("Checking triangle " + points[i] + " " + points[j] + " " + points[k]);
					if (inside(p, points[i], points[j], points[k])) {
						double costij = table[j][k-j+1] + table[k][i-k+1+npoints] + cost[j][k] + cost[k][i];
						double costjk = table[k][i-k+1+npoints] + table[i][j-i+1] + cost[k][i] + cost[i][j];
						double costki = table[i][j-i+1] + table[j][k-j+1] + cost[i][j] + cost[j][k];
//						System.out.println("  Inside, costs = " + costij + " " + costjk + " " + costki);
						if (j-i> 1 && costij < ans[i][j]) {
//							System.out.println("    setting " + i + "," + j + " to  " + costij);
							ans[i][j] = ans[j][i] = costij;
						}
						if (k-j > 1 && costjk < ans[j][k]) {
//							System.out.println("    setting " + j + "," + k + " to  " + costjk);
							ans[j][k] = ans[k][j] = costjk;
						}
						if (!(i==0 && k == npoints-1) && costki < ans[k][i]) {
//							System.out.println("    setting " + i + "," + k + " to  " + costki);
							ans[k][i] = ans[i][k] = costki;
						}
					}

				}
/*
		for(int i=0; i<npoints; i++) {
			for(int j=0; j<npoints; j++) {
				if (ans[i][j] == Double.MAX_VALUE)
					System.out.print(" -1.0000 ");
				else
					System.out.printf("%8.4f ", ans[i][j]);
			}
			System.out.println();
		}
/**/
		return ans;
	}
	
	public static double calcIntersect(Point a, Point b, Point c, Point d)
	{
		double den = (d.x - c.x)*(b.y-a.y)-(b.x-a.x)*(d.y-c.y);
		if (den == 0)
			return 2.0;				// artificial - just need number > 1;
		double t = ((d.x-c.x)*(c.y-a.y)-(c.x-a.x)*(d.y-c.y))/den;
		if (t < 0.0)
			return 2.0;
		return t;
	}
	public static double calcCost(Point p1, Point p2, int i, int j, int k)
	{
		int s;
		Point pi = points[i];
		Point pj = points[j];
		Point pk = points[k];
		double innerTriCost = cost[i][j] + cost[j][k] + cost[k][i];
		double tij = calcIntersect(p1, p2, pi, pj);
		double tjk = calcIntersect(p1, p2, pj, pk);
		double tki = calcIntersect(p1, p2, pk, pi);
//		System.out.println("Intersection of " + p1 + "-" + p2 + "," + points[i] + "-" + points[j] + ": " + tij);
//		System.out.println("Intersection of " + p1 + "-" + p2 + "," + points[j] + "-" + points[k] + ": " + tjk);
//		System.out.println("Intersection of " + p1 + "-" + p2 + "," + points[k] + "-" + points[i] + ": " + tki);
		if (tij < tjk && tjk < tki) {
			s = i - k + 1;
			if(s < 0) s += npoints;
			return triWithP1[i][j] + triWithP2[j][k] + innerTriCost + table[k][s]; 
		}
		else if (tij < tki && tki < tjk) {
			s = k - j + 1;
			if(s < 0) s += npoints;
			return triWithP1[i][j] + triWithP2[k][i] + innerTriCost + table[j][s]; 
		}
		else if (tjk < tki && tki < tij) {
			s = j - i + 1;
			if(s < 0) s += npoints;
			return triWithP1[j][k] + triWithP2[k][i] + innerTriCost + table[i][s]; 
		}
		else if (tjk < tij && tij < tki) {
			s = i - k + 1;
			if(s < 0) s += npoints;
			return triWithP1[j][k] + triWithP2[i][j] + innerTriCost + table[k][s]; 
		}
		else if (tki < tij && tij < tjk) {
			s = k - j + 1;
			if(s < 0) s += npoints;
			return triWithP1[k][i] + triWithP2[i][j] + innerTriCost + table[j][s]; 
		}
		else if (tki < tjk && tjk < tij) {
			s = j - i + 1;
			if(s < 0) s += npoints;
			return triWithP1[k][i] + triWithP2[j][k] + innerTriCost + table[i][s]; 
		}
		else {
			System.out.println("Should never get here");
			System.exit(-1);
		}
 		return 0.0;
	}

	public static double solve(Point p1, Point p2)
	{
		triWithP1 = minTriangleContainingP(p1);
		triWithP2 = minTriangleContainingP(p2);
		int [] indices = new int[npoints];
		double minCost = Double.MAX_VALUE;
		for(int i=0; i<npoints; i++) {
			double v1x = p1.x - points[i].x;					// vector from pi to p1
			double v1y = p1.y - points[i].y;
			int numInd=0;
			for(int j=(i+1)%npoints; j != i; j = (j+1)%npoints) {
				double vx = points[j].x - points[i].x;				// vector from pi to pj
				double vy = points[j].y - points[i].y;
				double z1 = vx*v1y - vy*v1x;
				if (z1 == 0.0)
					break;
				double v2x = p2.x - points[i].x;					// vector from pi to p2
				double v2y = p2.y - points[i].y;
				double z2 = vx*v2y - vy*v2x;
				if (z1*z2 < 0.0) {
					//System.out.println("For point " + points[i] + " adding point " + points[j]);
					//System.out.printf("%f,%f %f,%f %f,%f\n", vx, vy, v1x, v1y, v2x, v2y);
					indices[numInd++] = j;
					for(int k=0; k<numInd-1; k++) {
//						System.out.println("process triangle " + points[i] + "," + points[indices[k]] + "," + points[j]);
						double cost = calcCost(p1, p2, i, indices[k], j);
//						System.out.println("   cost = " + cost);
						if (cost < minCost){
							minCost = cost;
						}	
					}
				}
			}
		}
		return minCost;
	}

	public static void main(String [] args)
	{

		Scanner in = new Scanner(System.in);
		npoints = in.nextInt();
		points = new Point[npoints];
		cost = new double[npoints][npoints];
		for(int i=0; i<npoints; i++) {
			points[i] = new Point();
			points[i].x = in.nextInt();
			points[i].y = in.nextInt();
		}   
		for(int i=0; i<npoints; i++)                // fill distance array
			for(int j=0; j<npoints; j++) 
				cost[i][j] = dist(i,j);
		cost[0][npoints-1] = cost[npoints-1][0] = 0.0;    // set distance of adjacent
		for(int i=0; i<npoints-1; i++)              //    vertices to 0.0
			cost[i][i+1] = cost[i+1][i] = 0.0;
		fillTable(npoints);
/* output table
		for(int s=2; s<=npoints; s++) {
			System.out.printf("%9d",s);
		}
		System.out.println();
		for(int i=0; i<npoints; i++) {
			System.out.printf("%2d", i);
			for(int s=2; s<=npoints; s++) {
				System.out.printf("%9.4f",table[i][s]);
			}
			System.out.println();
		}
/**/
		int x, y;
		Point p1 = new Point();
		p1.x = in.nextInt();
		p1.y = in.nextInt();
		Point p2 = new Point();
		p2.x = in.nextInt();
		p2.y = in.nextInt();
		double ans = solve(p1,p2);
		if (ans == Double.MAX_VALUE)
			System.out.println("IMPOSSIBLE");
		else
			System.out.printf("%f",solve(p1, p2));
		System.out.println("");
	}
}
