/**
 * Find the allowed fences. Then use dynamic programming to find
 * a minimum cost triangulation.
 *
 * This submission gets WRONG ANSWER because it incorrectly assumes
 * that the region for the messenger needs to have at least one edge
 * on the boundary of the provided polygon.
 *
 * @author Finn Lidbetter
 */

fun main() {
    val n = readln().toInt()
    var pts = Array<Point>(n) {
        val (x, y) = readln().split(" ").map{ it.toLong() }
        Point(x, y)
    }
    val (bx1, by1) = readln().split(" ").map { it.toLong() }
    val (bx2, by2) = readln().split(" ").map { it.toLong() }
    val brother1 = Point(bx1, by1)
    val brother2 = Point(bx2, by2)
    val lines = Array(n) {
        i -> Array<Line>(n) {
            j -> Line(pts[i], pts[j])
        }
    }
    val fenceAllowed = Array(n) {
        i -> BooleanArray(n) {
            j -> (
                i != j &&
                lines[i][j].cross(brother1) != 0L &&
                lines[i][j].cross(brother2) != 0L
            )
        }
    }
    val cost = Array(n) {
        i -> DoubleArray(n) {
            j -> (
                if ((i+1) % n == j || ((j+1)% n ) == i) {
                    0.0
                } else {
                    lines[i][j].cost()
                }
            )
        }
    }
    // minCostTriangulation[i][j] is the minimum cost to triangulate the
    // sub-polygon from vertex i to vertex j, where the sub-polygon consists
    // of only the points not between i and j in clockwise order.
    var minCostTriangulation = Array(n) { Array<Double?>(n) { null } }
    for (i in 0..n-1) {
        for (j in 0..n-1) {
            solve(i, j, fenceAllowed, cost, minCostTriangulation)
        }
    }

    var best: Double? = null
    for (i in 0..n-1) {
        for (j in 0..n-1) {
            val j1 = (j+1)%n
            if (i == j || j1 == i) {
                continue
            }
            if (!fenceAllowed[i][j] || !fenceAllowed[i][j1]) {
                continue
            }
            if (inTriangle(i, j, j1, brother1, lines) || inTriangle(i,j,j1, brother2, lines)) {
                continue
            }
            if (sign(lines[i][j].cross(brother1)) == sign(lines[i][j].cross(brother2))) {
                continue
            }
            var best1: Double? = null
            for (k in i+1..i+1+n-1) {
                val k0 = k%n
                if (k0 == j) {
                    break
                }
                if (!fenceAllowed[i][k0] || !fenceAllowed[j][k0]) {
                    continue
                }
                if (!inTriangle(i,j,k0, brother1, lines) && !inTriangle(i,j,k0, brother2, lines)) {
                    continue
                }
                val t1 = minCostTriangulation[k0][i]
                val t2 = minCostTriangulation[j][k0]
                if (t1 == null || t2 == null) {
                    continue
                }
                val sum = t1!! + t2!! + cost[i][j] + cost[i][k0] + cost[j][k0]
                if (best1 == null || sum < best1) {
                    best1 = sum
                }
            }
            if (best1 == null) {
                continue
            }
            var best2: Double? = null
            for (k in j1+1..j1+1+n-1) {
                val k0 = k%n
                if (k0 == i) {
                    break
                }
                if (!fenceAllowed[j1][k0] || !fenceAllowed[k0][i]) {
                    continue
                }
                if (!inTriangle(i,j1,k0, brother1, lines) && !inTriangle(i,j1,k0,brother2, lines)) {
                    continue
                }
                val t1 = minCostTriangulation[i][k0]
                val t2 = minCostTriangulation[k0][j1]
                if (t1 == null || t2 == null) {
                    continue
                }
                val sum = t1!! + t2!! + cost[i][j1] + cost[i][k0] + cost[j1][k0]
                if (best2 == null || sum < best2) {
                    best2 = sum
                }
            }
            if (best2 == null) {
                continue
            }
            if (best == null || best1!! + best2!! < best) {
                best = best1!! + best2!!
            }
        }
    }
    if (best == null) {
        println("IMPOSSIBLE")
    } else {
        println(best!!)
    }
}

fun inTriangle(a: Int, b: Int, c: Int, p: Point, lines: Array<Array<Line>>): Boolean {
    val line1 = lines[a][b]
    val line2 = lines[b][c]
    val line3 = lines[c][a]
    val side1 = sign(line1.cross(p))
    var side2 = sign(line2.cross(p))
    var side3 = sign(line3.cross(p))
    return side1 * side2 > 0 && side1 * side3 > 0
}

/**
 * Return -1 if the input is negative, 1 if the input is positive, 0 otherwise.
 */
fun sign(a: Long): Long {
    if (a > 0) {
        return 1L
    }
    if (a < 0) {
        return -1L
    }
    return 0L
}

fun solve(
    i: Int,
    j: Int,
    fenceAllowed: Array<BooleanArray>,
    fenceCost: Array<DoubleArray>,
    minCostTriangulation: Array<Array<Double?>>
): Double? {
    if (i == j) {
        return null
    }
    val n = fenceAllowed.size
    if ((j+2) % n == i || (j+1) % n == i) {
        minCostTriangulation[i][j] = 0.0
        return 0.0
    }
    if (minCostTriangulation[i][j] != null) {
        return minCostTriangulation[i][j]
    }
    var best: Double? = null
    for (k in 1..n-1) {
        if ((j+k)%n == i) {
            break
        }
        val ptIndex = (j+k) % n
        if (fenceAllowed[j][ptIndex] && fenceAllowed[i][ptIndex]) {
            val t1 = solve(i, ptIndex, fenceAllowed, fenceCost, minCostTriangulation)
            val t2 = solve(ptIndex, j, fenceAllowed, fenceCost, minCostTriangulation)
            if (t1 == null || t2 == null) {
                continue
            }
            var sum = t1!! + t2!! + fenceCost[i][ptIndex] + fenceCost[j][ptIndex]
            if (best == null || sum < best) {
                best = sum
            }
        }
    }
    minCostTriangulation[i][j] = best
    return best
}

class Point(val x: Long, val y: Long)

class Line(val p1: Point, val p2: Point) {

    fun cost(): Double {
    //fun cost(): Long {
        val dx = p2.x - p1.x
        val dy = p2.y - p1.y
        val distSq = dx * dx + dy * dy
        var dist = kotlin.math.sqrt(distSq.toDouble())
        return dist
        /*
        var dist = kotlin.math.sqrt(distSq.toDouble()).toLong()
        while (dist > 0 && dist * dist >= distSq) {
            dist -= 1
        }
        while (dist * dist < distSq) {
            dist += 1
        }
        return dist
         */
    }

    fun cross(p: Point): Long {
        val x1 = p2.x - p1.x
        val y1 = p2.y - p1.y
        val x2 = p.x - p1.x
        val y2 = p.y - p1.y
        return x1 * y2 - y1 * x2
    }

    fun midIntersects(l2: Line): Boolean {
        val l2opposites = (cross(l2.p1) * cross(l2.p2)) < 0
        val thisOpposites = (l2.cross(p1) * l2.cross(p2)) < 0
        return l2opposites && thisOpposites
    }

    fun hasPoint(p: Point): Boolean {
        if (cross(p) != 0L) {
            return false
        }
        if (p1.x < p2.x) {
            return p1.x <= p.x && p.x <= p2.x
        } else if (p2.x < p1.x) {
            return p2.x <= p.x && p.x <= p1.x
        } else if (p1.y < p2.y) {
            return p1.y <= p.y && p.y <= p2.y
        }
        return p2.y <= p.y && p.y <= p1.y
    }
}