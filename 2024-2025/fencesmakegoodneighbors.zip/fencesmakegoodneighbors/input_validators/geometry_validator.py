import sys
from collections import namedtuple

Pt = namedtuple('Pt', ['x', 'y'])


def cross(p1, p2):
    return p1.x * p2.y - p1.y * p2.x


def main():
    n = int(sys.stdin.readline())
    pts = []
    for _ in range(n):
        x, y = map(int, sys.stdin.readline().split(" "))
        pts.append(Pt(x, y))
    assert len(set(pts)) == n, "Distinct points violation"
    bx, by = map(int, sys.stdin.readline().split(" "))
    brother_1 = Pt(bx, by)
    bx, by = map(int, sys.stdin.readline().split(" "))
    brother_2 = Pt(bx, by)
    assert brother_1 != brother_2, "Brothers distinct location violation"
    for i in range(n):
        p1 = pts[i]
        p2 = pts[(i + 1) % n]
        p3 = pts[(i + 2) % n]
        v1 = Pt(p2.x - p1.x, p2.y - p1.y)
        v2 = Pt(p3.x - p1.x, p3.y - p1.y)
        vb1 = Pt(brother_1.x - p1.x, brother_1.y - p1.y)
        vb2 = Pt(brother_2.x - p1.x, brother_2.y - p1.y)
        assert cross(v1, v2) < 0, f"Convexity or clockwise violation at pt {i}: {p1}"
        assert cross(v1, vb1) < 0, "Brother 1 polygon interior violation"
        assert cross(v1, vb2) < 0, "Brother 2 polygon interior violation"
    sys.exit(42)


if __name__ == "__main__":
    main()
