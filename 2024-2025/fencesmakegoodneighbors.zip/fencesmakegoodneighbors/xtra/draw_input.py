#!/usr/bin/python3

from sys import stdin
import matplotlib.pyplot as plt
from matplotlib import collections as mc

n = int(stdin.readline())

pts = []
for _ in range(n):
    x, y = map(int, stdin.readline().split(" "))
    pts.append((x,y))
bx1, by1 = map(int, stdin.readline().split(" "))
bx2, by2 = map(int, stdin.readline().split(" "))
lines = [(pts[i], pts[(i+1)%n]) for i in range(n)]
lc = mc.LineCollection(lines)
fig, ax = plt.subplots()
ax.add_collection(lc)
ax.scatter(bx1, by1)
ax.scatter(bx2, by2)
ax.autoscale()
plt.show()
