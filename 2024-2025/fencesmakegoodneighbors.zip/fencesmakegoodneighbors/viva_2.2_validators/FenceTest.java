import org.vanb.viva.VIVA;
import java.io.*;

public class FenceTest {
	public static final String VIVA_SCRIPT = "fence2.viva";

	public static void main(String [] args)
	{
		if(args.length <= 0){
			System.out.println("Supply the input file");
		} else {
			VIVA viva = new VIVA();
			FenceFunction fence = new FenceFunction();
			viva.addFunction(fence);
	
			try {	
				File inFile = new File(VIVA_SCRIPT);
				FileInputStream fs = new FileInputStream(inFile);
			
			
				if(viva.setPattern(fs)){
					if(!viva.testInputFile(args[0])){
						System.out.println("Bad input!");
					}
				} else {
					System.out.println("Bad viva script");
				}
			} catch(Exception e) {
				System.out.println("Exception: " + e);
			}
		}
	}
}
