import org.vanb.viva.VectorFunction;
import org.vanb.viva.utils.VIVAContext;
import org.vanb.viva.utils.Utilities;
import java.util.List;

public class FenceFunction implements VectorFunction
{
	private static final boolean DEBUG = false;

	public String getName()
	{
		return "fencetest";
	}

	public Class<?> getReturnType( Class<?>[] params )
	{
		return(Boolean.class);
	}

	public String getUsage()
	{
		return "fencetest(xv1,yv2)";
	}

	public Object run( VIVAContext context,
		List<List<Object>> parameters ) throws Exception
	{
		Number x, y;
		int i, nCount = parameters.size();
		// 5 minimum + 2 brothers
		if(nCount < 7){
			return(Boolean.valueOf(false));
		}
		double [] xv = new double[nCount];
		double [] yv = new double[nCount];

		if(DEBUG){
			System.out.println("List is " + nCount + " long.");	
		}

		Class<?> type = null;
		i = 0;
		for( List<Object> row : parameters )
		{

			// There's two params per row, x and y
			xv[i] = ((Number)row.get( 0 )).doubleValue();
			yv[i] = ((Number)row.get( 1 )).doubleValue();
			if(DEBUG){
				System.out.println("Vals: " + xv[i] + "," + yv[i]);
			}
			i++;
		}
		return(Boolean.valueOf(ProcessPoints(xv, yv)));
	}

	private boolean ProcessPoints(double [] vx, double [] vy){
		int nverts = vx.length;
		int i;
		double test;
		double dvx, dvy;
		double pdvx = 0, pdvy = 0;
		double p1dvx, p1dvy, p2dvx, p2dvy;
		double px1, py1, px2, py2, pvx, pvy;

		// brothers
		px1 = vx[nverts-2];
		py1 = vy[nverts-2];
		px2 = vx[nverts-1];
		py2 = vy[nverts-1];
		nverts -= 2;

		if(DEBUG){
			System.out.println("nvert=" + nverts + " px1 py1: " + px1 + " " + py1 + "  px2 py2: " + px2 + " " + py2);
		}

		pvx = px2 - px1;
		pvy = py2 - py1;

		/*
		 * Begin pickel code
		 */
		for(i = 1; i < nverts ; i++) {
			dvx = vx[i] - vx[i-1];
			dvy = vy[i] - vy[i-1];
			p1dvx = px1 - vx[i-1];
			p1dvy = py1 - vy[i-1];
			p2dvx = px2 - vx[i-1];
			p2dvy = py2 - vy[i-1];
			if(i > 1) {
				test = dvx*pdvy - dvy*pdvx;
				if(test < 0.0) {
					System.err.println("not convex at vertex " + i);
					return(false);
				}
			}
			test = p1dvx*dvy - p1dvy*dvx;
			if(test < 0.0) {
				System.err.println("p1 outside edge %d-%d " + (i-1) + " " + i);
				return(false);
			}
			test = p2dvx*dvy - p2dvy*dvx;
			if(test < 0.0) {
				System.err.println("p2 outside edge %d-%d " + (i-1) + " " + i);
				return(false);
			}
			pdvx = dvx; pdvy = dvy;
		}
		p1dvx = px1 - vx[nverts-1];
		p1dvy = py1 - vy[nverts-1];
		p2dvx = px2 - vx[nverts-1];
		p2dvy = py2 - vy[nverts-1];
		dvx = vx[0] - vx[nverts-1]; dvy = vy[0] - vy[nverts-1];
		test = dvx*pdvy - dvy*pdvx;
		if(test < 0.0) {
			System.err.println("not convex at vertex %d " + (nverts-1));
			return(false);
		}
		test = p1dvx*dvy - p1dvy*dvx;
		if(test < 0.0) {
			System.err.println("p1 outside edge %d-0 " + (nverts-1));
			return(false);
		}
		test = p2dvx*dvy - p2dvy*dvx;
		if(test < 0.0) {
			System.err.println("p2 outside edge %d-0 " + (nverts-1));
			return(false);
		}
		pdvx = dvx; pdvy = dvy;
		dvx = vx[1] - vx[0]; dvy = vy[1] - vy[0];
		test = dvx*pdvy - dvy*pdvx;
		if(test < 0.0) {
			System.err.println("not convex at vertex %d " + 0);
			return(false);
		}
		return true;
	}
}
