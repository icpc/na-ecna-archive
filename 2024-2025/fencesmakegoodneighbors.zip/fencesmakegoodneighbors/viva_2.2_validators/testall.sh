#!/bin/bash
for file in ../data/sample/*.in ../data/secret/*.in
do
	echo "**************" $file "*****************"
	java -cp .:./viva.jar FenceTest $file
done
