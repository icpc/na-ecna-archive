import java.util.ArrayList;
import java.util.Random;

public class GenPonyless {

	public static Random rnd = new Random();

	public static void main(String[] args) {

		int c, d, parent;

//		twoLevel(50, 5);
//		oneSubtree(500);
		random(10,20);
	}

	public static void twoLevel(int size, int n)	// n level 1 nodes, each with (size-n)/n children
	{
		int c, d, parent;

		System.out.println(size);
		for(int i=0; i<n; i++) {
			c = rnd.nextInt(20)+1;
			d = rnd.nextInt(size/2) + 1;
			parent = 0;
			System.out.println(c + " " + d + " " + parent);
		}
		int m = (size-n)/n;
		for(int p=1; p<=n; p++) {
			for(int i=0; i<m; i++) {
				c = rnd.nextInt(20)+1;
				d = rnd.nextInt(size/2) + 1;
				parent = p;
				System.out.println(c + " " + d + " " + parent);
			}

		}
	}

	public static void oneSubtree(int size)	// size/2 level 1 nodes, one with size/2 children
	{
		int c, d, parent;

		System.out.println(size);
		for(int i=0; i<size/2; i++) {
			c = rnd.nextInt(20)+1;
			d = rnd.nextInt(size/2) + 1;
			parent = 0;
			System.out.println(c + " " + d + " " + parent);
		}
		parent = rnd.nextInt(size/2)+1;
		for(int i=0; i<size/2; i++) {
			c = rnd.nextInt(20)+1;
			d = rnd.nextInt(size/2) + 1;
			//			parent = i/(size/2) + 2;
			System.out.println(c + " " + d + " " + parent);

		}
	}
	
	public static class Node
	{
		int c, d, parent;
		
		public Node(int c, int d, int parent)
		{
			this.c = c; this.d = d; this.parent = parent;
		}
	}
	
	public static void random(int low, int high)	// generate random tree with between low and high nodes
	{
		int c, d, parent;

		int size = rnd.nextInt(high-low+1) + low;
		System.out.println(size);
		Node [] nodes = new Node[size];
		for(int i=0; i<size; i++) {
			c = rnd.nextInt(20)+1;
			d = rnd.nextInt(size/2) + 1;
			parent = rnd.nextInt(i+1);
			nodes[i] = new Node(c, d, parent);
		}
		for(int i=0; i<size; i++) {
			Node nd = nodes[i];
			System.out.println(nd.c + " " + nd.d + " " + nd.parent);
		}
		
	}
}
