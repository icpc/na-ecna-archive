"""
Validate the tree constraint; there is a unique path between each pair of farms.

Validator author: Finn Lidbetter.
"""

import sys
from collections import deque


class Node:
    def __init__(self, idd):
        self.id = idd
        self.adj = []

def main():
    n = int(sys.stdin.readline())
    nodes = [Node(i) for i in range(n+1)]
    for i in range(n):
        node_id = i+1
        parent = int(sys.stdin.readline().strip().split(" ")[-1])
        nodes[node_id].adj.append(parent)
        nodes[parent].adj.append(node_id)
    # It is a tree if it is connected and we have n edges.
    vis = {0}
    q = deque([0])
    while q:
        curr = q.popleft()
        for nbr in nodes[curr].adj:
            if nbr not in vis:
                vis.add(nbr)
                q.append(nbr)
    assert len(vis) == n + 1, "Tree violation"

    sys.exit(42)

if __name__ == "__main__":
    main()

