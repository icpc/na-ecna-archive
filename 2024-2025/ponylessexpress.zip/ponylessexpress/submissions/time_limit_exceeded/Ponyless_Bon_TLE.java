import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*
 * TLE solution to Ponyless - tries all possible permutations of assigning times at each level of tree
 * 							  Noticeable delays for n >= 100
 */
public class Ponyless_Bon_TLE {

	public static class Node
	{
		public ArrayList<Node> children;
		public int c, d;					// used for penalty c*(d-t)^2
		public int t1, t2;
		public double avgAnger = 0.0;
		public boolean visited = false;
	}
	
	public static Node[] cities;
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();					// # of cities
		cities = new Node[n+1];
		for(int i=1; i<=n; i++) {
			int c, d, parent;
			c = in.nextInt();
			d = in.nextInt();
			parent = in.nextInt();
			if (cities[i] == null) {
				cities[i] = new Node();
				cities[i].visited = false;
				cities[i].children = new ArrayList<>();
			}
			cities[i].c = c;
			cities[i].d = d;
			if (cities[parent] == null) {
				cities[parent] = new Node();
				cities[parent].visited = false;
				cities[parent].children = new ArrayList<>();
			}
			cities[parent].children.add(cities[i]);
		}
		System.out.println(process(cities[0].children,1));
/*
		for(Node child : cities[0].children) {
			System.out.println(child.c + " " + child.d + " " + child.t1 + " " + child.t2 + " " + child.avgAnger);
		}
		for(Node child : cities[1].children) {
			System.out.println(child.c + " " + child.d + " " + child.t1 + " " + child.t2 + " " + child.avgAnger);
		}
/**/
	}
	
	public static long process(ArrayList<Node> children, int t)
	{
		if (children.size() == 0)
			return 0;
		long best = Long.MAX_VALUE;
		boolean lastchild = true;
		for(int i=0; i<children.size(); i++) {
			Node child = children.get(i);
			if (child.visited)
				continue;
			lastchild = false;
			child.visited = true;
			long diff = child.d-t;
			long childAnger = child.c*diff*diff;
			long val1 = process(child.children, t+1);
			long val2 = process(children, t+1);
			if (val1 + val2 + childAnger < best)
				best = val1 + val2 + childAnger;
			child.visited = false;
		}	
		if (lastchild)
			return 0;
		return best;
	}

}
