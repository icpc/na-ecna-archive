import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/*
 * greedy idea: for each node first determine range of possible times t1...t2 they can be visited
 *              determine the average anger value given these times
 *              sort nodes, visiting those with larger average anger values first
 */
public class Ponyless_Bon_WA {

	public static class Node implements Comparable<Node>
	{
		public ArrayList<Node> children;
		public int c, d;					// used for penalty c*(d-t)^2
		public int t1, t2;
		public double avgAnger = 0.0;
		
		public int compareTo(Node other)
		{
			if (avgAnger > other.avgAnger)
				return -1;
			else if (avgAnger < other.avgAnger)
				return 1;
			return 0;
		}
		
		public double getAvgAnger(int startt, int numt)
		{
			t1 = startt;
			t2 = startt + numt-1;
			double avg = c;
			int d1, d2;
			double sumsq = 0.0;
			if (d < t1) {
				d2 = t2-d;
				d1 = t1-d-1;
				sumsq = (d2*(d2+1)*(2*d2+1) - d1*(d1+1)*(2*d1+1))/6.0;
			}
			else if (d <= t2) {
				d2 = t2-d;
				d1 = d - t1;
				sumsq = (d2*(d2+1)*(2*d2+1) + d1*(d1+1)*(2*d1+1))/6.0;
			}
			else {
				d2 = d - t1;
				d1 = d - t2 -1;
				sumsq = (d2*(d2+1)*(2*d2+1) - d1*(d1+1)*(2*d1+1))/6.0;
			}
			avgAnger = avg*sumsq/(t2-t1+1);								// avg anger contribution for this node
			if (children.size() == 0) {				// leaf
				return avgAnger;
			}
			else {
				int n = children.size();
				for(Node child : children) {
					avgAnger += child.getAvgAnger(startt+1, numt+n-1);
				}
				Collections.sort(children);								// sort children from largest avg anger to least
				return avgAnger;
			}
		}
		
		public long process(int t)
		{
			if (children.size() == 0) {				// leaf
				long diff = d-t;
				return c*diff*diff;
			}
			else {
				long diff = d-t;
				long cost = c*diff*diff;
				for(Node child : children) {
					cost += child.process(++t);
				}
				return cost;
			}
		}
	}
	
	public static Node[] cities;
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();					// # of cities
		cities = new Node[n+1];
		for(int i=1; i<=n; i++) {
			int c, d, parent;
			c = in.nextInt();
			d = in.nextInt();
			parent = in.nextInt();
			if (cities[i] == null) {
				cities[i] = new Node();
				cities[i].children = new ArrayList<>();
			}
			cities[i].c = c;
			cities[i].d = d;
			if (cities[parent] == null) {
				cities[parent] = new Node();
				cities[parent].children = new ArrayList<>();
			}
			cities[parent].children.add(cities[i]);
		}
		cities[0].getAvgAnger(0, 1);
		System.out.println(cities[0].process(0));
/*
		for(Node child : cities[0].children) {
			System.out.println(child.c + " " + child.d + " " + child.t1 + " " + child.t2 + " " + child.avgAnger);
		}
		for(Node child : cities[1].children) {
			System.out.println(child.c + " " + child.d + " " + child.t1 + " " + child.t2 + " " + child.avgAnger);
		}
/**/
	}

}
