#!/usr/bin/python3

print('Will there be pizza after the contest?')

