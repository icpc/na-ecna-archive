#!/usr/bin/python3

import sys

def gcd(a,b):
    return a if b==0 else gcd(b,a%b)

p,q = map(int, sys.stdin.readline().strip().split())
assert p > 0
assert 2*p - 1 <= q
assert gcd(p,q) == 1

sys.exit(42)

