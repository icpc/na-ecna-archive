from collections import deque
from copy import deepcopy #ugh
import sys

def succ(conf):
    s = []
    cb = conf[0]
    moves = []
    sz = len(cb)
    for r in range(sz):
        for c in range(sz):
            if cb[r][c] == 'N':
                for dr,dc in ((-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)):
                    moves.append((r,c,r+dr,c+dc,'N'))
            if cb[r][c] == 'R' or cb[r][c] == 'Q':
                # row and column
                for newr in range(0,sz):
                    if newr == r: continue
                    moves.append((r,c,newr,c,cb[r][c]))
                for newc in range(0,sz):
                    if newc == c: continue
                    moves.append((r,c,r,newc,cb[r][c]))
            if cb[r][c] == 'B' or cb[r][c] == 'Q':
                for dr in range(-sz,sz+1): #I am so lazy
                    if dr == 0: continue
                    moves.append((r,c,r+dr,c+dr,cb[r][c]))
                    moves.append((r,c,r+dr,c-dr,cb[r][c]))
            if cb[r][c] == 'K':
                for dr,dc in ((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)):
                    moves.append((r,c,r+dr,c+dc,'K'))
            if cb[r][c] == 'P':
                moves.append((r,c,r+1,c-1,'P'))
                moves.append((r,c,r+1,c+1,'P'))
    # make sure loc1, then loc2 is in lexicographical order
    # cleverly organized tuple FTW
    moves.sort()
    for mv in moves:
        r, c, newr, newc, pc = mv
        if newr >= 0 and newc >= 0 and newr < sz and newc < sz:
            if cb[newr][newc] != '':
                newb = deepcopy(cb)
                newb[r][c] = ''
                newb[newr][newc] = pc
                newmv = deepcopy(conf[1])
                newmv.append(mv)
                s.append((newb,newmv))
    return s

def print_moves(mv):
    for r,c,newr,newc,pc in mv:
        print(pc + ": " + chr(ord('A')+r) + str(c+1) + " -> " + chr(ord('A')+newr) + str(newc+1))

def dfs(st):
    if len(st[1]) == m-1:
        # we did it!
        print_moves(st[1])
        sys.exit()
    ns = succ(st)
    for n in ns:
        dfs(n)

n,m = [int(x) for x in input().strip().split()]
cb = [['' for _ in range(n)] for _ in range(n)]
for _ in range(m):
    pc = input().strip().split()
    loc = (ord(pc[1][0])-ord('A'),int(pc[1][1])-1)
    cb[loc[0]][loc[1]] = pc[0]

dfs([cb,[]])
print('no solution')
