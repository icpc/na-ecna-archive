import random
pieces = 'KNQRB'

def randpuz():
    n = random.randint(5,8)
    m = random.randint(5,10)
    pcs = []
    for _ in range(m):
        pc = random.choice(pieces)
        r = chr(random.randint(ord('A'),ord('A')+n-1))
        c = random.randint(1,n)
        pcs.append(pc+' '+r+str(c))
    return n,m,pcs
