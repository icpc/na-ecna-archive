// Liam Keliher, 2025
//
// TLE submission for problem "AROD" (arod)
//
// Iterates over all vertex triples and categorizes each resulting triangle.
//
// Complexity:  O(n^6), where n = max(X,Y)


import java.io.*;

public class TLE_AllVertexTriples {
    static final int NUM_TYPES = 4;
    static final int ACUTE = 0;
    static final int RIGHT = 1;
    static final int OBTUSE = 2;
    static final int DEGENERATE = 3;
	//---------------------------------------------------------------
	public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        int xMax = Integer.parseInt(tokens[0]);
        int yMax = Integer.parseInt(tokens[1]);
        int numCols = (xMax + 1);
        int numRows = (yMax + 1);
        int numPoints = numRows*numCols;
        long[] counter = new long[NUM_TYPES];
        for (int index1 = 0; index1 < (numPoints - 2); index1++) {
            int x1 = index1 % numCols;
            int y1 = index1 / numCols;
            for (int index2 = index1 + 1; index2 < (numPoints - 1); index2++) {
                int x2 = index2 % numCols;
                int y2 = index2 / numCols;
                for (int index3 = index2 + 1; index3 < numPoints; index3++) {
                    int x3 = index3 % numCols;
                    int y3 = index3 / numCols;
                    int triangleType = categorize(x1, y1, x2, y2, x3, y3);
                    counter[triangleType]++;
                } // for index3
            } // for index2
        } // for index1

        StringBuilder sb = new StringBuilder(100);
        for (int t = 0; t < NUM_TYPES; t++) {
            sb.append(counter[t]).append('\n');
        } // for t
        System.out.print(sb);
    } // main(String[])
	//---------------------------------------------------------------
    // Returns the type of triangle with vertices (x1,y1), (x2,y2), (x3,y3)
    static int categorize(int x1, int y1, int x2, int y2, int x3, int y3) {
        // Handle the degenerate case first
        int[] slope12 = getSlope(x1, y1, x2, y2);
        int[] slope13 = getSlope(x1, y1, x3, y3);
        if (slope12[0] == slope13[0] && slope12[1] == slope13[1]) {
            return DEGENERATE;
        } // if

        // Calculate the square of each side
        int side12sq = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
        int side13sq = (x1 - x3)*(x1 - x3) + (y1 - y3)*(y1 - y3);
        int side23sq = (x2 - x3)*(x2 - x3) + (y2 - y3)*(y2 - y3);

        // Let c be a side that is at least as long as the other two sides (a and b)
        int a2, b2, c2;
        if (side12sq >= side13sq && side12sq >= side23sq) {
            c2 = side12sq;
            a2 = side13sq;
            b2 = side23sq;
        } // if
        else if (side13sq >= side12sq && side13sq >= side23sq) {
            c2 = side13sq;
            a2 = side12sq;
            b2 = side23sq;
        } // else if
        else {
            c2 = side23sq;
            a2 = side12sq;
            b2 = side13sq;
        } // else

        if (c2 == a2 + b2) {
            return RIGHT;
        } // if
        else if (c2 < a2 + b2) {
            return ACUTE;
        } // else if
        else {
            return OBTUSE;
        } // else
    } // categorize(int,int,int,int,int,int)
	//---------------------------------------------------------------
    // Returns a length-2 array containing the slope of the line through
    // (x1,y2) and (x2,y2) in the form [rise, run].  The slope is a fraction,
    // rise/run, in reduced form, with the convention that the denominator
    // is never negative.  A vertical line is assigned slope 1/0 (never -1/0).
    //
    // Assumption: (x1,y1) != (x2,y2) (in which case the slope is undefined)
    static int[] getSlope(int x1, int y1, int x2, int y2) {
        int rise = y2 - y1;
        int run = x2 - x1;
        if (run == 0) {   // vertical slope
            return new int[]{1, 0};
        } // if
        else {
            if (run < 0) {   // convention:  run should always be positive
                rise = -rise;
                run = -run;
            } // if
            int g = (int)gcd(Math.abs(rise), run);
            rise /= g;
            run /= g;
            return new int[]{rise, run};
        } // else
    } // getSlope(int,int,int,int)
    //--------------------------------------------------------------------
    // Euclidean algorithm. Uses long since this is required in main()
    // (getSlope() only needs an int version).
    static long gcd(long a, long b) {
        while (b != 0) {
            long rem = a % b;
            a = b;
            b = rem;
        } // while
        return a;
    } // gcd(long,long)
	//---------------------------------------------------------------
} // class TLE_AllVertexTriples

