// Arnav Sastry

#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <iomanip>
#include <numeric>

int32_t angleCategory(const std::array<int64_t, 6>& triangle) {
    int64_t dx1 = triangle[2] - triangle[0];
    int64_t dy1 = triangle[3] - triangle[1];
    int64_t dx2 = triangle[4] - triangle[0];
    int64_t dy2 = triangle[5] - triangle[1];

    if (dx1 * dy2 == dy1 * dx2) {
        return 3;
    }

    int64_t dot = dx1 * dx2 + dy1 * dy2;
    if (dot < 0) {
        return 2;
    } else if (dot == 0) {
        return 1;
    } else {
        return 0;
    }
}

int32_t category(const std::array<int64_t, 6>& triangle) {
    return std::max({
            angleCategory({triangle[0], triangle[1], triangle[2], triangle[3], triangle[4], triangle[5]}),
            angleCategory({triangle[2], triangle[3], triangle[4], triangle[5], triangle[0], triangle[1]}),
            angleCategory({triangle[4], triangle[5], triangle[0], triangle[1], triangle[2], triangle[3]})});
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int64_t x, y;
    std::cin >> x >> y;

    std::array<int64_t, 4> ans{};
    for (int64_t x1 = 0; x1 <= x; ++x1)
    for (int64_t y1 = 0; y1 <= y; ++y1)
    for (int64_t x2 = x1; x2 <= x; ++x2)
    for (int64_t y2 = (x1 == x2 ? y1 + 1 : 0); y2 <= y; ++y2)
    for (int64_t x3 = x2; x3 <= x; ++x3)
    for (int64_t y3 = (x2 == x3 ? y2 + 1 : 0); y3 <= y; ++y3)
        ans[category({x1, y1, x2, y2, x3, y3})]++;

    for (auto v : ans) {
        std::cout << v << '\n';
    }

    return 0;
}

