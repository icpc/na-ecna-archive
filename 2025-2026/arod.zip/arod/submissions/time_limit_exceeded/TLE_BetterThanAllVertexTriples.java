// Liam Keliher, 2025
//
// TLE submission for problem "AROD" (arod)
//
// Generates triples of points and categorizes the resulting triangles, but
// reduces complexity by considering two trianges to be equivalent if they are
// vertical and/or horizontal translations of each other, and only generates
// one representative for each equivalence class, specifically, the member of
// the class that is "jammed into" the bottom-left corner.  Then computes the
// number of translations of this representative.
//
// Complexity:  O(n^4), where n = max(X,Y)
//    (in contrast, a simple brute-force "try all vertex triples" approach is O(n^6))


import java.io.*;

public class TLE_BetterThanAllVertexTriples {
    static final int NUM_TYPES = 4;
    static final int ACUTE = 0;
    static final int RIGHT = 1;
    static final int OBTUSE = 2;
    static final int DEGENERATE = 3;
	//---------------------------------------------------------------
	public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        int xMax = Integer.parseInt(tokens[0]);
        int yMax = Integer.parseInt(tokens[1]);

        long[] counter = new long[NUM_TYPES];

        // NOTE: Cases 1, 2, 3 are in reverse order (simplest to most complex)

        //**********************************************************************
        // CASE 3: all three vertices are on the left edge, with yLeftBottom = 0
        //     - all triangles are degenerate (no need to call categorize())
        //     - complexity: O(n^2)
        //**********************************************************************
        for (int yLeftTop = 2; yLeftTop <= yMax; yLeftTop++) {   // start at 2
            for (int yLeftMiddle = 1; yLeftMiddle < yLeftTop; yLeftMiddle++) {   // start at 1, stop before yTop
                // (xMax + 1) is the number of horizontal translations
                // (yMax - yLeftTop + 1) is the number of vertical translations
                counter[DEGENERATE] += (xMax + 1)*(yMax - yLeftTop + 1);
            } // for yLeftMiddle
        } // for yLeftTop


        //*******************************************
        // CASE 2: two vertices are on the left edge
        //     - complexity over all subcases: O(n^3)
        //*******************************************
        // Subcase 2-A: yLeftBottom = 0, "free" point anywhere not on left edge
        //    - complexity: O(n^3)
        for (int yLeftTop = 1; yLeftTop <= yMax; yLeftTop++) {    // start at 1
            for (int xOther = 1; xOther <= xMax; xOther++) {   // start at 1
                for (int yOther = 0; yOther <= yMax; yOther++) {
                    int triangleType = categorize(0, 0, 0, yLeftTop, xOther, yOther);
                    int highestY = Math.max(yLeftTop, yOther);
                    // (xMax - xOther + 1) is the number of horizontal translations
                    // (yMax - highestY + 1) is the number of vertical translations
                    counter[triangleType] += (xMax - xOther + 1)*(yMax - highestY + 1);
                } // for yOther
            } // for xOther
        } // for yLeftTop

        // Subcase 2-B: yLeftBottom > 0, yOther = 0
        //    - complexity: O(n^3)
        for (int yLeftTop = 2; yLeftTop <= yMax; yLeftTop++) {    // start at 2
            for (int yLeftBottom = 1; yLeftBottom < yLeftTop; yLeftBottom++) {    // start at 1, end before yTop
                for (int xOther = 1; xOther <= xMax; xOther++) {    // start at 1
                    int triangleType = categorize(0, yLeftBottom, 0, yLeftTop, xOther, 0);
                    // (xMax - xOther + 1) is the number of horizontal translations
                    // (yMax - yLeftTop + 1) is the number of vertical translations
                    counter[triangleType] += (xMax - xOther + 1)*(yMax - yLeftTop + 1);
                } // for xOther
            } // for yLeftBottom
        } // for yLeftTop


        //*******************************************
        // CASE 1: one vertex is on the left edge
        //     - complexity over all subcases: O(n^4)
        //*******************************************
        // Subcase 1-A: yLeft = 0
        //    - complexity: O(n^4)
        int numOtherRows = yMax + 1;
        int numOtherCols = xMax;
        int numOtherPoints = numOtherRows*numOtherCols;
        for (int index1 = 0; index1 < (numOtherPoints - 1); index1++) {
            int x1 = 1 + index1 % numOtherCols;   // offset by 1
            int y1 = index1 / numOtherCols;
            for (int index2 = index1 + 1; index2 < numOtherPoints; index2++) {
                int x2 = 1 + index2 % numOtherCols;   // offset by 1
                int y2 = index2 / numOtherCols;
                int triangleType = categorize(0, 0, x1, y1, x2, y2);
                int highestX = Math.max(x1, x2);
                int highestY = Math.max(y1, y2);
                // (xMax - highestX + 1) is the number of horizontal translations
                // (yMax - highestY + 1) is the number of vertical translations
                counter[triangleType] += (xMax - highestX + 1)*(yMax - highestY + 1);
            } // for index2
        } // for index1

        // Subcase 1-B: yLeft > 0
        // Subsubcase 1-B-1: one other point is on the bottom edge
        //    - complexity: O(n^4)
        for (int yLeft = 1; yLeft <= yMax; yLeft++) {    // start at 1
            for (int xOther1 = 1; xOther1 <= xMax; xOther1++) {    // start at 1
                for (int xOther2 = 1; xOther2 <= xMax; xOther2++) {    // start at 1
                    for (int yOther2 = 1; yOther2 <= yMax; yOther2++) {    // start at 1
                        int triangleType = categorize(0, yLeft, xOther1, 0, xOther2, yOther2);
                        int highestX = Math.max(xOther1, xOther2);
                        int highestY = Math.max(yLeft, yOther2);
                        // (xMax - highestX + 1) is the number of horizontal translations
                        // (yMax - highestY + 1) is the number of vertical translations
                        counter[triangleType] += (xMax - highestX + 1)*(yMax - highestY + 1);
                    } // for yOther2
                } // for xOther2
            } // for xOther1
        } // for yLeft

        // Subsubcase 1-B-2: two other points are on the bottom edge
        //    - complexity: O(n^3)
        for (int yLeft = 1; yLeft <= yMax; yLeft++) {    // start at 1
            for (int xOtherRight = 2; xOtherRight <= xMax; xOtherRight++) {    // start at 2
                for (int xOtherLeft = 1; xOtherLeft < xOtherRight; xOtherLeft++) {    // start at 1, stop before xOtherRight
                    int triangleType = categorize(0, yLeft, xOtherLeft, 0, xOtherRight, 0);
                        // (xMax - xOtherRight + 1) is the number of horizontal translations
                        // (yMax - yLeft + 1) is the number of vertical translations
                        counter[triangleType] += (xMax - xOtherRight + 1)*(yMax - yLeft + 1);
                } // for xOtherLeft
            } // for xOtherRight
        } // for yLeft


        // Print the results
        StringBuilder sb = new StringBuilder(100);
        for (int t = 0; t < NUM_TYPES; t++) {
            sb.append(counter[t]).append('\n');
        } // for t
        System.out.print(sb);
    } // main(String[])
	//---------------------------------------------------------------
    // Returns the type of triangle with vertices (x1,y1), (x2,y2), (x3,y3)
    static int categorize(int x1, int y1, int x2, int y2, int x3, int y3) {
        // Handle the degenerate case first
        int[] slope12 = getSlope(x1, y1, x2, y2);
        int[] slope13 = getSlope(x1, y1, x3, y3);
        if (slope12[0] == slope13[0] && slope12[1] == slope13[1]) {
            return DEGENERATE;
        } // if

        // Calculate the square of each side
        int side12sq = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
        int side13sq = (x1 - x3)*(x1 - x3) + (y1 - y3)*(y1 - y3);
        int side23sq = (x2 - x3)*(x2 - x3) + (y2 - y3)*(y2 - y3);

        // Let c be a side that is at least as long as the other two sides (a and b)
        int a2, b2, c2;
        if (side12sq >= side13sq && side12sq >= side23sq) {
            c2 = side12sq;
            a2 = side13sq;
            b2 = side23sq;
        } // if
        else if (side13sq >= side12sq && side13sq >= side23sq) {
            c2 = side13sq;
            a2 = side12sq;
            b2 = side23sq;
        } // else if
        else {
            c2 = side23sq;
            a2 = side12sq;
            b2 = side13sq;
        } // else

        if (c2 == a2 + b2) {
            return RIGHT;
        } // if
        else if (c2 < a2 + b2) {
            return ACUTE;
        } // else if
        else {
            return OBTUSE;
        } // else
    } // categorize(int,int,int,int,int,int)
	//---------------------------------------------------------------
    // Returns a length-2 array containing the slope of the line through
    // (x1,y2) and (x2,y2) in the form [rise, run].  The slope is a fraction,
    // rise/run, in reduced form, with the convention that the denominator
    // is never negative.  A vertical line is assigned slope 1/0 (never -1/0).
    //
    // Assumption: (x1,y1) != (x2,y2) (in which case slope is undefined)
    static int[] getSlope(int x1, int y1, int x2, int y2) {
        int rise = y2 - y1;
        int run = x2 - x1;
        if (run == 0) {   // vertical slope
            return new int[]{1, 0};
        } // if
        else {
            if (run < 0) {   // convention:  run should always be positive
                rise = -rise;
                run = -run;
            } // if
            int g = (int)gcd(Math.abs(rise), run);
            rise /= g;
            run /= g;
            return new int[]{rise, run};
        } // else
    } // getSlope(int,int,int,int)
    //--------------------------------------------------------------------
    static long gcd(long a, long b) {
        while (b != 0) {
            long rem = a % b;
            a = b;
            b = rem;
        } // while
        return a;
    } // gcd(long,long)
	//---------------------------------------------------------------
} // class TLE_BetterThanAllVertexTriples

