// Arnav Sastry

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <iomanip>
#include <numeric>

int32_t angleCategory(const std::array<int64_t, 6>& triangle) {
    int64_t dx1 = triangle[2] - triangle[0];
    int64_t dy1 = triangle[3] - triangle[1];
    int64_t dx2 = triangle[4] - triangle[0];
    int64_t dy2 = triangle[5] - triangle[1];

    if (dx1 * dy2 == dy1 * dx2) {
        return 3;
    }

    int64_t dot = dx1 * dx2 + dy1 * dy2;
    if (dot < 0) {
        return 2;
    } else if (dot == 0) {
        return 1;
    } else {
        return 0;
    }
}

int32_t category(const std::array<int64_t, 6>& triangle) {
    return std::max({
            angleCategory({triangle[0], triangle[1], triangle[2], triangle[3], triangle[4], triangle[5]}),
            angleCategory({triangle[2], triangle[3], triangle[4], triangle[5], triangle[0], triangle[1]}),
            angleCategory({triangle[4], triangle[5], triangle[0], triangle[1], triangle[2], triangle[3]})});
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int64_t x, y;
    std::cin >> x >> y;

    std::array<int64_t, 4> ans{};
    for (int64_t dx1 = -x; dx1 <= x; ++dx1)
    for (int64_t dy1 = -y; dy1 <= y; ++dy1)
    for (int64_t dx2 = -x; dx2 <= x; ++dx2)
    for (int64_t dy2 = -y; dy2 <= y; ++dy2) {
        if (dx1 == 0 && dy1 == 0) continue;
        if (dx2 == 0 && dy2 == 0) continue;
        if (dx1 == dx2 && dy1 == dy2) continue;

        int64_t xLo = std::max({int64_t{}, -dx1, -dx2});
        int64_t yLo = std::max({int64_t{}, -dy1, -dy2});
        int64_t xHi = std::min({x, x - dx1, x - dx2});
        int64_t yHi = std::min({y, y - dy1, y - dy2});

        if (xLo > xHi || yLo > yHi) continue;

        int64_t placements = (xHi - xLo + 1) * (yHi - yLo + 1);
        ans[category({0, 0, dx1, dy1, dx2, dy2})] += placements;
    }

    for (auto v : ans) {
        std::cout << v / 6 << '\n';
    }

    return 0;
}
