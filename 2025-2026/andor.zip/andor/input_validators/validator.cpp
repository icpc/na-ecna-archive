// This assumes only single spaces used for separating values;
// more than one space messes up the token count

#include <bits/stdc++.h>
using namespace std;

int main() {
  // integer from 2 through 20, single space, 'A' or 'O'
  regex firstline("^([2-9]|(1[0-9])|(20)) (A|O)$");

  // 1 or more 'T', 'F', or integer from 1 to 10, separated by single spaces
  regex otherlines("^((T|F|[1-9]|10) *)*(T|F|[1-9]|10)$");

  string line;
  getline(cin,line);
  if (!regex_match(line,firstline)) {
      cerr << "bad first line: \"" << line << "\"\n";
  }
  stringstream first(line);
  int n;
  int lines = 0;
  first >> n;
  int retcode = 42;
  int prev = 1; // first line of tree description has just one entry
  while (getline(cin,line)) {
    lines ++;
    if (lines > n) {
      cerr << "Too many lines: " << lines << endl;
      retcode = 1;
    }
    if (!regex_match(line,otherlines)) {
      cerr << "error in line " << (lines+1) << ": \"" << line << "\"\n";
      retcode = 1;
    } else {
      int spaces = count(line.begin(),line.end(),' ');
      if (spaces+1 != prev) {
        cerr << "error in line " << (lines+1) << ": wrong number of tokens\n";
        retcode = 1;
      } else {
        regex pattern("(T|F)");
        string numbers = regex_replace(line,pattern,"");
        stringstream nums(numbers);
        int sum = 0,val;
        while (nums >> val) {
          sum += val;
        }
        prev = sum;
      }
    }
  }
  if (lines < n) {
    cerr << "Not enough lines: " << lines << endl;
    retcode = 1;
  }
  exit(retcode);
}
