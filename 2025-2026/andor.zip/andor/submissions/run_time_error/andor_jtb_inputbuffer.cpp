/*
 * AndOr - ICPC East Division Regional
 * Solution by John Buck
 * 
 * It's quite ugly.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <memory.h>

#define	MAX_CHILDREN	10

struct aonode {
	aonode(bool bAndNode, int nc) {
		nChildren = nc;
		bAnd = bAndNode;
		bvalue = false;
		ntrue = 0;
		nfalse = 0;
		nchange = 0;
		parent = NULL;
		::memset(&(c[0]), '\0', sizeof(c));
		nodenum = gnodenum++;
	}
	void setval(char c) {
		if(c == 'T'){
			ntrue++;
		} else {
			nfalse++;
		}
	}
	void addNode(int nc, aonode *pn) {
		c[nc] = pn;
		pn->parent = this;
	}
	aonode *parent;
	int nChildren;
	aonode *c[MAX_CHILDREN+1];
	bool bAnd;
	int ntrue;
	int nfalse;
	int nchange;
	bool bvalue;
	// debug stuff
	int nodenum;
	static int gnodenum;
};
int aonode::gnodenum = 1;

aonode *root;

void traverse(aonode *);

void showtree(aonode *pn, int nindent)
{
	int i;
	::fprintf(stdout, "%*sNode %d (%s):  %d children nTrue:%d nFalse:%d bValue:%s bChange:%d\n", nindent, "", pn->nodenum,
		pn->bAnd ? "AND" : "OR",
		pn->nChildren,
		pn->ntrue, pn->nfalse,
		pn->bvalue ? "TRUE" : "FALSE", pn->nchange);
	nindent += 4;
	for(i = 0; i < pn->nChildren && pn->c[i] != NULL; i++){
		showtree(pn->c[i], nindent);
	}
}

int main()
{
	int i, nLevels, nNodes, nTok;
	char szType[4];
	bool bType;
	char buf[256], *tok;
	aonode *pn, **ppn, *prow;

	if(::fscanf(stdin, "%d %c %d", &(nLevels), &(szType[0]), &(nNodes)) != 3 || (szType[0] != 'A' && szType[0] != 'O') ||
		nLevels < 2 || nLevels > 20 || nNodes < 1 || nNodes > 10){
		::fprintf(stdout, "bad input\n");
		return(0);
	}
	while((i = getc(stdin)) != EOF && i != '\n'){
	}
	if(i == EOF){
		::fprintf(stdout, "no rows\n");
		return(0);
	}
	bType = (szType[0] == 'A');
	root = new aonode(bType, nNodes);
	prow = root;
	ppn = &(prow->c[0]);
	pn = prow;
	for(i = 1; i < nLevels; i++){
		if(::fgets(&(buf[0]), sizeof(buf), stdin) == NULL){
			::fprintf(stdout, "premature eof %d\n", i);
			return(0);
		}
		bType = !bType;
		tok = ::strtok(&(buf[0]), " \t");
		nTok = 0;
		while(tok != NULL){
			if(isdigit(*tok)){
				// node
				pn->addNode(nTok, new aonode(bType, ::atoi(tok)));
			} else {
				pn->setval(*tok);
			}
			nTok++;
			if(nTok >= pn->nChildren){
				pn = *++ppn;
				nTok = 0;
			}
			tok = ::strtok(NULL, " \t");
		}
		pn = prow->c[0];
		ppn = &(prow->c[0]);
		prow = pn;
	}
#ifdef _DEBUG
	showtree(root, 0);
#endif
	traverse(root);
	::fprintf(stdout, "%d\n", root->nchange);
#ifdef _DEBUG
	showtree(root, 0);
#endif
	return(0);
}

void traverse(aonode *pn)
{
	int i, nt, nf;

	for(i = 0; pn->c[i] != NULL; i++){
		traverse(pn->c[i]);
	}
	if(i == 0){
		// no children, just leaves
		if(pn->bAnd){
			pn->bvalue = (pn->ntrue > 0 && pn->nfalse == 0);
			if(pn->bvalue == false){
				pn->nchange = pn->nfalse;
			} else {
				// If any one thing changes, the value changes
				pn->nchange = 1;
			}
		} else {
			if(pn->ntrue > 0){
				pn->bvalue = true;
				// All trues must change to false
				pn->nchange = pn->ntrue;
			} else {
				pn->bvalue = false;
				// Any false must change to true.
				pn->nchange = 1;
			}
		}
	} else if(pn->bAnd){
		nt = 0;
		nf = -1;
		// All child nodes are OR's
		for(i = 0, pn->bvalue = true; pn->c[i] != NULL; i++){
			if(pn->c[i]->bvalue){
				if(nf == -1 || pn->c[i]->nchange < nf){
					nf = pn->c[i]->nchange;
				}
			} else {
				// have to turn them all true since they're all false
				nt += pn->c[i]->nchange;
				pn->bvalue = false;
			}
		}
		// if node value is true, need number to change to make it false, and vice versa
		if(pn->bvalue){
			pn->nchange = nf;
		} else {
			pn->nchange = nt;
		}
	} else {
		// or
		nt = -1;
		nf = 0;
		// All child nodes are AND's
		for(i = 0, pn->bvalue = false; pn->c[i] != NULL; i++){
			if(pn->c[i]->bvalue){
				pn->bvalue = true;
				nf += pn->c[i]->nchange;
			} else {
				if(nt == -1 || pn->c[i]->nchange < nt){
					nt = pn->c[i]->nchange;
				}
			}
		}
		if(pn->bvalue){
			pn->nchange = nf;
		} else {
			pn->nchange = nt;
		}
	}
}

