c = int(input())
counts = list(map(int, input().split(maxsplit=c-1)))
counts.sort()
total = sum(counts)
votes = counts[-2]
i = 0
while i < len(counts)-2 and votes <= total//2:
    votes += counts[i]
    i += 1
if votes > total//2:
    print(i)
else:
    print('IMPOSSIBLE TO WIN')
