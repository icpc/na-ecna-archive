#include <vector>
#include <iostream>

using namespace std;

void Swap(int& x, int& y){
  int temp = x;
  x = y;
  y = temp;
}

void Bubble_Sort(vector<int>& v){
  for(int i = 0; i < v.size(); i++)
    for(int j = 0; j < v.size()-i-1; j++)
      if(v[j] > v[j+1])
	Swap(v[j], v[j+1]);
}

int main(){
  int c;
  cin >> c;
  vector<int> votes(c);
  int total = 0;
  int largest = -1;
  int second = -1;
  for(int i = 0; i < c; i++){
    cin >> votes[i];
    total = total + votes[i];
  }

  Bubble_Sort(votes);
  int needed = total/2+1;
  int num = 0;
  int cur = votes[votes.size()-2];
  bool done = false;
  int i = 0;
  while(i < votes.size()-2 && !done){
    cur = cur + votes[i];
    if(cur >= needed)
      done = true;
    else
      i++;
  }
  if(i < votes.size()-2)
    cout << i+1 << endl;
  else
    cout << "IMPOSSIBLE TO WIN" << endl;
  return 0;
}


  

  
