#!/usr/bin/python3

from sys import stdin

def main():
    n = int(stdin.readline())
    votes = list(map(int, stdin.readline().split(maxsplit=n-1)))
    votes.sort()
    total = sum(votes)
    threshold = total // 2
    while threshold * 2 <= total:
        threshold += 1
    curr_loser = 0
    rounds = 0
    while curr_loser < n - 2:
        votes[-2] += votes[curr_loser]
        votes[curr_loser] = 0
        rounds += 1
        if votes[-2] >= threshold:
            break
        curr_loser += 1
    if votes[-2] >= threshold:
        print(rounds)
    else:
        print("IMPOSSIBLE TO WIN")


if __name__ == "__main__":
    main()

