// Isaac Lee
// 2025 East Division
// But I Want to Win
// Accepted submission

// In order to find the least number of rounds necessary for the candidate with the initial second
// most votes to win, we assume that each voter who had another candidate as their first choice had
// that candidate as their next choice. So after each round, the candidate with the fewest votes is
// eliminated and their votes go to the target candidate. This stops when we arrive at 2 candidates
// or the target candidate gets more than half the votes.

import java.io.*;
import java.util.*;
public class RcvIsaac
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader buffy = new BufferedReader(new InputStreamReader(System.in));
		byte C = Byte.parseByte(buffy.readLine());
		int[] Vcs = new int[C];
		long half = 0L;
		String [] strVotes = buffy.readLine().split(" ");
		for(byte c = 0;c < C;c++)
		{
			int Vc = Integer.parseInt(strVotes[c]);
			Vcs[c] = Vc;
			half += (long)Vc;
		}
		Arrays.sort(Vcs);
		half >>= 1;
		C -= 2;
		long votes = Vcs[C];
		byte R = 0;
		while(R < C && votes <= half)
		{
			votes += (long)Vcs[R++];
		}
		if(votes > half)
		{
			System.out.println(R);
		}
		else
		{
			System.out.println("IMPOSSIBLE TO WIN");
		}
	}
}

