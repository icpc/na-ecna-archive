import sys

c = int(sys.stdin.readline())
v = list(map(int, sys.stdin.readline().split(maxsplit=c-1)))
v.sort(reverse=True)
s = sum(v)
half = s//2+1
count = 0
while len(v) > 2 and v[1] < half:
  v[1] += v[-1]
  v = v[0:-1]
  count += 1
if v[1] >= half:
  print(count)
else:
  print('IMPOSSIBLE TO WIN')
