import java.util.Scanner;

public class Triptych_BF_JPB {

	public static long count = 0, pCount = 0;
	public static int w, d, max, min;
	
	public static int[][][] table = new int[24][24][24];
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		w = in.nextInt();
		d = in.nextInt();
		max = Math.min(w, (w+2*d)/3);
		min = Math.max(0, (w-2*d+2)/3);
		count(1, "a", 1, 0, 0, 'a', ' ');
		count(1, "b", 0, 1, 0, 'b', ' ');
		count(1, "c", 0, 0, 1, 'c', ' ');
		System.out.println(count);
//		System.out.println(count + " " + (count+pCount));
		for(int i=min; i<=max; i++)
			for(int j=min; j<=max; j++) {
				int k = w-i-j;
//				if (k >=min && k < max)
//				System.out.println(i+","+j+","+k+": " + table[i][j][k]);
			}
	}

	public static void count(int n, String s, int na, int nb, int nc, char last, char last2) {
		if (n == w) {
			if (Math.abs(na-nb) <= d && Math.abs(nb-nc) <= d && Math.abs(nc-na) <= d) {
//				System.out.println(s);
				if (isPalin(s, n))
					pCount++;
				else
					count++;
				table[na][nb][nc]++;
			}
			return;
		}
		if (last != 'a' && na < max && na + (w-n)/2 >= min-1)
			count(n+1, s+"a", na+1, nb, nc, 'a', last);
		if (last != 'b' || last2 != 'b' && nb < max)
			count(n+1, s+"b", na, nb+1, nc, 'b', last);
		if (last != 'c' && nc < max && na + (w-n)/2 >= min-1)
			count(n+1, s+"c", na, nb, nc+1, 'c', last);
	}
	
	public static boolean isPalin(String s, int len)
	{
		for(int i=0; i<len/2; i++)
			if (s.charAt(i) != s.charAt(len-1-i))
				return false;
		return true;
	}
}
