// Liam Keliher, 2023
//
// WA submission for problem "Triptych" (triptych)
//
// Generates all sequences of length W in which no two consecutive letters
// are the same, except possibly BB, and then tests each one for balance and
// for non-palindromicity.


import java.io.*;

public class TLE_GenerateAllSequences {
    static final int A = 0;
    static final int B = 1;
    static final int C = 2;
    static int W;
    static int D;
    static long numSequences;
    static int[] sequence;
	//---------------------------------------------------------------
	public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] tokens = br.readLine().split(" ");
        W = Integer.parseInt(tokens[0]);
        D = Integer.parseInt(tokens[1]);

        numSequences = 0;
        sequence = new int[W];
        recurse(0);

        System.out.println(numSequences);
    } // main(String[])
	//---------------------------------------------------------------
    static void recurse(int index) {
        if (index == W) {
            if (isBalanced() && !isPalindrome()) {
                numSequences++;
            } // if
        } // if
        else {
            if (index == 0) {
                sequence[index] = A;
                recurse(index + 1);
                sequence[index] = B;
                recurse(index + 1);
                sequence[index] = C;
                recurse(index + 1);
            } // if
            else {   // index > 0
                int prev = sequence[index - 1];
                if (prev == A) {
                    sequence[index] = B;
                    recurse(index + 1);
                    sequence[index] = C;
                    recurse(index + 1);
                } // if
                else if (prev == C) {
                    sequence[index] = A;
                    recurse(index + 1);
                    sequence[index] = B;
                    recurse(index + 1);
                } // else if
                else {   // prev == B
                    sequence[index] = A;
                    recurse(index + 1);
                    sequence[index] = C;
                    recurse(index + 1);
                    if (index == 1 || sequence[index - 2] != B) {
                        sequence[index] = B;
                        recurse(index + 1);
                    } // if
                } // else
            } // else
        } // else
    } // recurse(int)
	//---------------------------------------------------------------
    static boolean isBalanced() {
        int numA = 0;
        int numB = 0;
        int numC = 0;
        for (int i = 0; i < sequence.length; i++) {
            int curr = sequence[i];
            if (curr == A) {
                numA++;
            } // if
            else if (curr == B) {
                numB++;
            } // else if
            else {   // curr == C
                numC++;
            } // else       
        } // for i
        int diffAB = Math.abs(numA - numB);
        int diffAC = Math.abs(numA - numC);
        int diffBC = Math.abs(numB - numC);
        return diffAB <= D && diffAC <= D && diffBC <= D;
    } // isBalanced()
	//---------------------------------------------------------------
    static boolean isPalindrome() {
        int len = sequence.length;
        for (int i = 0; i < len/2; i++) {
            if (sequence[i] != sequence[len - 1 - i]) {
                return false;
            } // if
        } // for i
        return true;
    } // isPalindrome()
	//---------------------------------------------------------------
} // class TLE_GenerateAllSequences

