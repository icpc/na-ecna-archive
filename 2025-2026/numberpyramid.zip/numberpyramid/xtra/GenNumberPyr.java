import java.util.Random;

public class GenNumberPyr {

	public static final int EMPTY = 100;
	public static int[][] grid, ans, tmp;
	public static String[] answers = {"solvable", "unsolvable", "contradiction"};
	
	public static void main(String[] args) {

		Random rnd = new Random();
		
		int n = 2*(rnd.nextInt(31)) + 40;
		ans = new int[n][n];
		grid = new int[n][n];
		tmp = new int[n][n];
		int val = n/2;
		ans[n-1][0] = -val+2;
		ans[n-1][1] = -val+1;
		for(int j=2; j<n-2; j+=2) {
			ans[n-1][j] = val;
			ans[n-1][j+1] = -val;
		}
		ans[n-1][n-2] = val-1;
		ans[n-1][n-1] = val-2;
		for(int i=n-2; i>=0; i--)
			for(int j=0; j<=i; j++)
				ans[i][j] = ans[i+1][j] + ans[i+1][j+1];
		for(int i=n-1; i>=0; i--)
			for(int j=0; j<=i; j++)
				grid[i][j] = ans[i][j];

		int ii, jj;
		do {
			ii = rnd.nextInt(n);
			jj = rnd.nextInt(n);
			while (ii < jj) {
				ii = rnd.nextInt(n);
				jj = rnd.nextInt(n);
			}
			grid[ii][jj] = 100;
			for(int i=n-1; i>=0; i--)
				for(int j=0; j<=i; j++)
					tmp[i][j] = grid[i][j];
		} while (process(tmp, n) == 0);
		int type = rnd.nextInt(3);
		switch (type) {
		case 0:	grid[ii][jj] = ans[ii][jj];		// solvable
				break;
		case 2:	grid[ii][jj] = ans[ii][jj]+1;	// contradiction
				break;
		}										// case 1: unsolvable

		
		System.out.println(n);
		for(int i=0; i<n; i++) {
			System.out.print(grid[i][0]);
			for(int j=1; j<=i; j++) {
				System.out.print(" " + grid[i][j]);
			}
			System.out.println();
		}
		System.out.println();
		for(int i=0; i<n; i++) {
			System.out.print(ans[i][0]);
			for(int j=1; j<=i; j++) {
				System.out.print(" " + ans[i][j]);
			}
			System.out.println();
		}
		System.out.println(answers[type]);
	}

	public static int process(int [][] card, int n)
	{
		boolean changesMade = true;
		while (changesMade) {
			changesMade = false;
			for(int i=0; i<n; i++) {
				for(int j=0; j<=i; j++) {
					if (card[i][j] == EMPTY){
						if (j > 0 && card[i-1][j-1] != EMPTY && card[i][j-1] != EMPTY) {
							card[i][j] = card[i-1][j-1] - card[i][j-1];
							changesMade = true;
						}
						else if (j < i && card[i-1][j] != EMPTY && card[i][j+1] != EMPTY) {
							card[i][j] = card[i-1][j] - card[i][j+1];
							changesMade = true;
						}
						else if (i < n-1 && card[i+1][j] != EMPTY && card[i+1][j+1] != EMPTY) {
							card[i][j] = card[i+1][j] + card[i+1][j+1];
							changesMade = true;
						}
					}
				}
			}
		}
		for(int i=0; i<n; i++) {
			for(int j=0; j<=i; j++) {
				if (card[i][j] == EMPTY)
					return 1;
			}
		}
		for(int i=0; i<n-1; i++) {
			for(int j=0; j<=i; j++) {
				if (card[i][j] != card[i+1][j] + card[i+1][j+1])
					return 2;
			}
		}
		return 0;
	}
}
