
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

double EPS = .000002;
FILE *fp1, *fp2;
char buf1[256], buf2[256];

int main( int argc, char **argv)
{
	double v1, v2;
	int seenerr, eof, row, notdone = 1;
	if(argc <= 2) {
		fprintf(stderr, "USAGE: %s infile1 infile2\n", argv[0]);
		return -1;
	}
	if((fp1 = fopen(argv[1], "r")) == (FILE *)NULL) {
		fprintf(stderr, "cannot open file1 %s\n", argv[1]);
		return -2;
	}
	if((fp2 = fopen(argv[2], "r")) == (FILE *)NULL) {
		fprintf(stderr, "cannot open file2 %s\n", argv[2]);
		return -3;
	}
	notdone = 1; row = 1; eof = 0; seenerr = 0;
	while(notdone){
		if(fgets(&(buf1[0]), 255, fp1) == NULL){
			eof = 1;
			notdone = 0;
		} else {
			if(sscanf(&(buf1[0]), "%lf", &v1) != 1) {
				notdone = 0;
			}
		}
		if(fgets(&(buf2[0]), 255, fp2) == NULL){
			if(notdone) {
				fprintf(stderr, "EOF on 2 but not 1 at row %d\n", row);
				return -4;
			}
		} else {
			if(sscanf(&(buf2[0]), "%lf", &v2) != 1) {
				if(notdone) {
					fprintf(stderr, "scan fail on 2 but not 1 at row %d\n", row);
					return -5;
				}
			} else if(notdone == 0) {
				if(eof) {
					fprintf(stderr, "EOF on 1 but not 2 at row %d\n", row);
					return -6;
				} else {
					fprintf(stderr, "scan fail on 1 but not 2 at row %d\n", row);
					return -5;
				}
			}
		}
		// got 2 vals compare
		if(fabs(v1 - v2) > EPS) {
			printf("%d: < %0.8lf > %0.8lf\n", row, v1, v2);
		}
		row++;
	}
	return 0;
}

