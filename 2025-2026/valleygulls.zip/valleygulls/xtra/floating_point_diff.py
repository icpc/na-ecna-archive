#!/usr/bin/python3

from decimal import Decimal
import argparse
import sys

def _setup_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("file1", type=str, help="Path to file 1.")
    parser.add_argument("file2", type=str, help="Path to file 2.")
    parser.add_argument(
        "precision", 
        type=int, 
        help="Absolute or relative error. A value of 6 will "
             "give absolute or relative error of 10^-6"
    )
    return parser.parse_args()

def main():
    args = _setup_args()
    precision = Decimal(f'1e-{args.precision}')
    lines_1 = []
    lines_2 = []
    with open(args.file1) as file1:
        lines_1 = file1.readlines()
    with open(args.file2) as file2:
        lines_2 = file2.readlines()

    for index, (file_1_line, file_2_line) in enumerate(zip(lines_1, lines_2)):
        val1 = Decimal(file_1_line)
        val2 = Decimal(file_2_line)
        abs_error = abs(val1 - val2)
        if abs_error <= precision:
            continue
        if val1 == 0:
            print(f"Difference on line {index}")
            sys.exit(1)
        rel_error = abs_error / val1
        if rel_error > precision:
            print(f"Difference on line {index}")
            sys.exit(1) 
    sys.exit(0)

if __name__ == "__main__":
    main()

