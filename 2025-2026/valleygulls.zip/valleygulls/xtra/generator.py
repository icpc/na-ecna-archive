#!/usr/bin/python3

import argparse
import random


def _setup_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("p", type=int, help="The number of elevation points")
    parser.add_argument("m", type=int, help="The number of nests")
    return parser.parse_args()

def main():
    x_min = 0
    x_max = 5000
    y_min = 0
    y_max = 1000
    args = _setup_args()
    print(f'{args.p} {random.random() + 1:.2f} {args.m}')
    
    x_space = [i for i in range(x_min, x_max + 1)]
    x_coords = random.sample(x_space, k=args.p)
    x_coords.sort()
    while x_coords[-1] - x_coords[0] - 1 < args.m:
        x_coords = random.sample(x_space, k=args.p)
        x_coords.sort()

    while True:
        pts = []
        for x in x_coords:
            pts.append((x, random.randint(y_min, y_max)))
        pts.sort()
        y_max = max(pt[1] for pt in pts)
        if pts[0][1] != y_max and pts[-1][1] != y_max:
            break
    nest_space = [i for i in range(pts[0][0] + 1, pts[-1][0])]
    nests = random.sample(nest_space, k=args.m)
    nests.sort()
    print(' '.join([f"{pt[0]} {pt[1]}" for pt in pts]))
    print(' '.join([str(nest_x) for nest_x in nests]))


if __name__ == "__main__":
    main()

