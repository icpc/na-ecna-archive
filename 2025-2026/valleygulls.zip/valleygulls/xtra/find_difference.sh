#!/bin/bash

counter=0
while true;
do
    if [[ ${counter} -gt 10000 ]]
    then
    	break
    fi
    counter=$((counter+1))
    echo "Trying case ${counter}"
    python3 generator.py $1 $2 > tmp.in
    /usr/lib/python3/dist-packages/problemtools/support/checktestdata --quiet ../input_validators/basic_validation.ctd tmp.in
    if [[ $? -ne 0 ]]
    then
        echo "    Failed basic validation"
	continue
    fi
    python3 ../input_validators/collinear_validator.py < tmp.in
    if [[ $? -ne 42 ]]
    then
        echo "    Failed collinear check"
        continue
    fi
    python3 ../input_validators/no_extremum_nest_validator.py < tmp.in
    if [[ $? -ne 42 ]]
    then
        echo "    Failed extremum nest validation"
        continue
    fi
    java -classpath ../submissions/accepted Valley_JPB < tmp.in > bonomo.out
    if [[ $? -ne 0 ]]
    then
        echo "    Valley_JPB had nonzero exit code"
        mv tmp.in "bad_case_${counter}.in"
        continue
    fi
    python3 ../submissions/accepted/valley_finn.py < tmp.in > finn.out
    if [[ $? -ne 0 ]]
    then
        echo "    bad_valley_finn.py had nonzero exit code"
        mv tmp.in "bad_case_${counter}.in"
        continue
    fi
    python3 floating_point_diff.py bonomo.out finn.out 6
    if [[ $? -ne 0 ]]
    then
        echo "    Bonomo and Finn gave different answers!"
        mv tmp.in "bad_case_${counter}.in"
    	continue
    fi
    echo "    Output matches!"
done
