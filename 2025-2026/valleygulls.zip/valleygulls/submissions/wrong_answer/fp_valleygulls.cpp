#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define MAX_PTS	50
#define MAX_NESTS	100
#define EPS (.0001)
#define OV_RT	1
#define OV_LFT	2

//#define DB_OUT

double geox[MAX_PTS], geoy[MAX_PTS], nestx[MAX_NESTS];
double peakx[MAX_PTS], peaky[MAX_PTS], maxx, maxy;

int npts, nnests, inmaxy, inmaxyloc;
double rainrate;

typedef struct _spline_seg_ {
	double A;
	double B;
	double C;
	double xl;
	double xr;
	double yl;
	double yr;
	double ymin;
	double critx;
	double crity;
} SPLINE_SEG,*PSPLINE_SEG;

SPLINE_SEG spsegs[2*MAX_PTS+2];
PSPLINE_SEG pLWallSeg, pRWallSeg;

typedef struct _peak_
{
	double x;
	double y;
	struct _peak_ *pLPar;
	struct _peak_ *pRPar;
	struct _peak_ *pLeft;
	struct _peak_ *pRt;
	PSPLINE_SEG pSegl;
	PSPLINE_SEG pSegr;
} PEAK, *PPEAK;

PEAK peaks[MAX_PTS];
int npeaks, maxpeak;
double maxpkx, maxpky;
PPEAK peakRoot, pLWall, pRWall;

typedef struct _gull_data_
{
	struct _gull_data_ *pNext;
	double x;
	double y;
	double baseVol;
	double baseTime;
	double remVol;
	double curTime;
	double floodTime;
} GULL, *PGULL;

GULL gulls[MAX_NESTS];
PGULL curGull;

typedef struct _valley_
{
	PGULL gullList;
	struct _valley_ *pOvFValley, *pPar, *pLChild, *pRChild;
	PSPLINE_SEG pLSeg, pRSeg;
	double xl;
	double yl;
	double xr;
	double yr;
	double vol;
	double xmin, ymin, ymax;
	double fillrate;
	double baseFillTime;
	double curTime;
	double curFill;
	int sortIndex;
	int overflowTo;
} VALLEY, *PVALLEY;

VALLEY valleys[2*MAX_PTS];
PVALLEY valleyList[2*MAX_PTS], pVRoot;
int nxtValley, nxtGull, sortCnt, remGulls;
double nxtGullY, nxtGullX;
double globTime;

double SplineX2Y(double x, PSPLINE_SEG ps)
{
	double ret;
	ret = ps->A*x*x + ps->B*x + ps->C;
	return ret;
}

int SplineY2XL(double y, double *pres, PSPLINE_SEG *pps)
{
	double disc, sqd, ov2A, prevy, x1, x2, xc;
	PSPLINE_SEG ps, pst;
	ps = *pps;
	prevy = ps->ymin;
	xc = *pres;
	if(ps == pLWallSeg) {
		pst = ps;
		pst++;
		if(y > pst->yl) {
			*pres = ps->xl;
			return 0;
		}
	}
	while (y < ps->ymin) {
		ps++;
		if(ps->ymin > prevy) {
			return -1;
		}
	}
	*pps = ps;
	if(fabs(ps->A) < EPS) {
		if(fabs(ps->B) < EPS) {
			if(ps->xl < xc) {
				*pres = xc;
			} else {
				*pres = ps->xl;
			}
			return 0;
		} else {
			*pres = (y - ps->C)/(ps->B);
			return 0;
		}
	}
	disc = (ps->B)*(ps->B) - 4.0*(ps->A)*(ps->C - y);
	if(disc < -EPS) {
		return -2;
	} else if (disc < EPS) {
		*pres = (-(ps->B)/(2.0*ps->A));
		return 0;
	}
	sqd = sqrt(disc);
	ov2A = 0.5/(ps->A);
	x1 = -ov2A*(ps->B + sqd);
	x2 = -ov2A*(ps->B - sqd);
	if(x1 < x2) {
		*pres = x1;
		if(x1 > ps->xr) {
			return -3;
		}
		if((x1 < ps->xl) || (x1 < xc)) {
			if((x2 >= ps->xl) && (x2 >= xc) && (x2 <= ps->xr)) {
				*pres = x2;
				return 0;
			}
			return -4;
		}
		return 0;
	} else {
		*pres = x2;
		if(x2 > ps->xr) {
			return -3;
		}
		if((x2 < ps->xl) || (x2 < xc)) {
			if((x1 >= ps->xl) && (x1 >= xc) && (x1 <= ps->xr)) {
				*pres = x1;
				return 0;
			}
			return -4;
		}
		return 0;
	}
}

int SplineY2XR(double y, double *pres, PSPLINE_SEG *pps)
{
	double disc, sqd, ov2A, prevy, x1, x2, xc;
	PSPLINE_SEG ps, pst;
	ps =*pps;
	prevy = ps->ymin;
	xc = *pres;
	if(ps == pRWallSeg) {
		pst = ps;
		pst--;
		if(y > pst->yr) {
			*pres = ps->xr;
			return 0;
		}
	}
	while (y < ps->ymin) {
		ps--;
		if(ps->ymin > prevy) {
			return -1;
		}
	}
	*pps = ps;
	if(fabs(ps->A) < EPS) {
		if(fabs(ps->B) < EPS) {
			if(ps->xl > xc) {
				return -17;
			}
			*pres = ps->xl;
			return 0;
		} else {
			*pres = (y - ps->C)/(ps->B);
			return 0;
		}
	}
	disc = (ps->B)*(ps->B) - 4.0*(ps->A)*(ps->C - y);
	if(disc < -EPS) {
		return -2;
	} else if (disc < EPS) {
		*pres = -((ps->B)/(2.0*ps->A));
		return 9;
	}
	sqd = sqrt(disc);
	ov2A = 0.5/(ps->A);
	x1 = -ov2A*(ps->B + sqd);
	x2 = -ov2A*(ps->B - sqd);
	if(x1 > x2) {
		*pres = x1;
		if(x1 < ps->xl) {
			return -3;
		}
		if((x1 > ps->xr) || (x1 > xc)) {
			if((x2 >= ps->xl) && (x2 <= xc) && (x2 <= ps->xr)) {
				*pres = x2;
				return 0;
			}
			return -4;
		}
		return 0;
	} else {
		*pres = x2;
		if(x2 < ps->xl) {
			return -3;
		}
		if((x2 > ps->xr) || (x2 > xc)) {
			if((x1 >= ps->xl) && (x1 <= xc) && (x1 <= ps->xr)) {
				*pres = x1;
				return 0;
			}
			return -4;
		}
		return 0;
	}
}

double SplineArea(double xl, double xr, double ytop, PSPLINE_SEG ps)
{
	double xl2, xl3, xr2, xr3, ret;
	if(xl < ps->xl) xl = ps->xl;
	if(xr > ps->xr) xr = ps->xr;
	if(xr <= xl) return 0.0;
	xl2 = xl*xl; xr2 = xr*xr; xl3 = xl2*xl; xr3 = xr2*xr;
	ret = (ytop - ps->C) * (xr - xl);
	ret -= ((ps->A)/3.0) * (xr3 - xl3);
	ret -= ((ps->B)/2.0) * (xr2 - xl2);
	return ret;
}

double ValleyArea(double xl, double xr, double ytop, PVALLEY pV)
{
	PSPLINE_SEG ps = pV->pLSeg;
	double ret = 0.0;
	while((ps != pRWallSeg) && (ps->xr <= xl)) {
		ps++;
	}
	if(ps == pRWallSeg) {
		fprintf(stderr, "Off the end in ValleyArea\n");
		return -1.0;
	}
	while((ps != pRWallSeg) && (ps->xr <= xr)) {
		ret += SplineArea(xl, ps->xr, ytop, ps);
		xl = ps->xr;
		ps++;
	}
	ret += SplineArea(xl, xr, ytop, ps);
	return ret;
}

int InitValley(PVALLEY pV, PPEAK pLeft, PPEAK pRt, PVALLEY pParent)
{
	PSPLINE_SEG ps;
	double vol, x;
	int ret;
	pV->gullList = NULL;
	pV->pPar = pParent;
	pV->yl = pLeft->y;
	pV->yr = pRt->y;
	pV->curFill = 0.0;
	pV->curTime = 0.0;
	pV->fillrate = rainrate * (pRt->x - pLeft->x);
	if(pV->fillrate < EPS) {
		fprintf(stderr, "b add fill rate %f in InitValley\n", pV->fillrate);
		return -6;
	}
	if(pLeft == pLWall) {
		pV->xl = pLeft->x;
		pV->xr = pRt->x;
		pV->ymax = pRt->y;
		pV->pRSeg = pRt->pSegl;
		pV->pLSeg = pLeft->pSegr;
		pV->overflowTo = OV_RT;
	} else if(pRt == pRWall) {
		pV->xl = pLeft->x;
		pV->xr = pRt->x;
		pV->ymax = pLeft->y;
		pV->pRSeg = pRt->pSegl;
		pV->pLSeg = pLeft->pSegr;
		pV->overflowTo = OV_LFT;
	} else if(pLeft ->y <= pRt->y) {
		pV->xl = pLeft->x;
		pV->ymax = pLeft->y;
		pV->pLSeg = pLeft->pSegr;
		pV->overflowTo = OV_LFT;
		ps = pRt->pSegl;
		x = pRt->x;
		ret = SplineY2XR(pV->ymax, &x, &ps);
		if(ret < 0) {
			fprintf(stderr, "find rt x ret %d\n", ret);
			return -1;
		}
		pV->xr = x;
		pV->pRSeg = ps;
	} else {
		pV->xr = pRt->x;
		pV->ymax = pRt->y;
		pV->pRSeg = pRt->pSegl;
		pV->overflowTo = OV_RT;
		ps = pLeft->pSegr;
		x = pLeft->x;
		ret = SplineY2XL(pV->ymax, &x, &ps);
		if(ret < 0) {
			fprintf(stderr, "find left x ret %d\n", ret);
			return -2;
		}
		pV->xl = x;
		pV->pLSeg = ps;
	}
	vol = ValleyArea(pV->xl, pV->xr, pV->ymax, pV);
	if(vol < 0.0) {
		fprintf(stderr, "Bad Vol in InitValley %f\n", vol);
		return -5;
	}
	pV->vol = vol;
	pV->baseFillTime = pV->vol/pV->fillrate;
	return 0;
}

int FindValleyMin(PVALLEY pV)
{
	PSPLINE_SEG pSeg;
	double x;
	if(pV->pLSeg == pLWallSeg) {
		pSeg = pV->pLSeg;
		x = pV->xl;
		pSeg++;
		if((2.0*(pSeg->A) *x + pSeg->B) > 0.0) {
			pV->xmin = geox[0];
			pV->ymin = geoy[0];
			return 0;
		}
	}
	if(pV->pRSeg == pRWallSeg) {
		pSeg = pV->pRSeg;
		x = pV->xr;
		pSeg--;
		if((2.0*(pSeg->A) *x + pSeg->B) < 0.0) {
			pV->xmin = geox[npts-1];
			pV->ymin = geoy[npts-1];
			return 0;
		}
	}
	pSeg = pV->pLSeg;
	if(pSeg == pLWallSeg) pSeg++;
	while (pSeg->A <= 0) {
		if(pSeg == pV->pRSeg) {
			fprintf(stderr, "out of segs in FindValleyMin\n");
			return -11;
		}
		pSeg++;
	}
	if(pSeg->critx < pSeg->xl) {
		pV->xmin = pSeg->xl;
		pV->ymin = pSeg->yl;
	} else if(pSeg->critx > pSeg->xr) {
		pV->xmin = pSeg->xr;
		pV->ymin = pSeg->yr;
	} else {
		pV->xmin = pSeg->critx;
		pV->ymin = pSeg->crity;
	}
	return 0;
}

int SetValleys(PVALLEY pV, PVALLEY pVPar, PPEAK pPkL, PPEAK pPkR)
{
	int ret;
	PPEAK pPk;
	PVALLEY pVL, pVR;
	if((ret = InitValley(pV, pPkL, pPkR, pVPar)) != 0) {
		return ret;
	}
	if(pPkL->y < pPkR->y) {
		pPk = pPkL->pRt;
	} else {
		pPk = pPkR->pLeft;
	}
	if(pPk != NULL) {
		pVL = &(valleys[nxtValley++]); 
		pVR = &(valleys[nxtValley++]); 
		pV->ymin = pPk->y;
		pV->pLChild = pVL;
		pV->pRChild = pVR;
		pVL->pOvFValley = pVR;
		pVR->pOvFValley = pVL;
		if((ret = SetValleys(pVL, pV, pPkL, pPk)) != 0) {
			return ret;
		}
		if((ret = SetValleys(pVR, pV, pPk, pPkR)) != 0) {
			return ret;
		}
		pV->xmin = 0.5*(pVL->xl + pVR->xr);
	} else {
		pV->pLChild = NULL;
		pV->pRChild = NULL;
		if((ret = FindValleyMin(pV)) != 0) {
			return ret;
		}
	}
	return 0;
}

int SetGulls(PVALLEY pV)
{
	PSPLINE_SEG ps;
	double xc, vol;
	int ret;
	if(nxtGullX < pV->xl) {
		fprintf(stderr, " nxt gull X %f < valley left %f\n", nxtGullX, pV->xl);
		return -21;
	}
	if(pV->pLChild == NULL) {
		while((nxtGull <= nnests) && (nxtGullX <= pV->xr)) {
			if(nxtGullX < pV->xmin) {
				//find rt x
				ps = pV->pRSeg;
				xc = ps->critx;
				if((ret = SplineY2XR(nxtGullY, &xc, &ps)) != 0) {
					fprintf(stderr, "find rt x failed for gullat %f\n", nxtGullX);
					return ret;
				}
				if((vol = ValleyArea(nxtGullX, xc, nxtGullY, pV)) < 0.0) {
					fprintf(stderr, "find gull vol failed for gullat %f\n", nxtGullX);
					return -6;
				}
				curGull->baseVol = curGull->remVol = vol;
				curGull->baseTime = vol/pV->fillrate;
			} else {
				// find left x
				ps = pV->pLSeg;
				xc = ps->critx;
				if((ret = SplineY2XL(nxtGullY, &xc, &ps)) != 0) {
					fprintf(stderr, "find left x failed for gullat %f\n", nxtGullX);
					return ret;
				}
				if((vol = ValleyArea(xc, nxtGullX, nxtGullY, pV)) < 0.0) {
					fprintf(stderr, "find gull vol failed for gullat %f\n", nxtGullX);
					return -6;
				}
				curGull->baseVol = curGull->remVol = vol;
				curGull->baseTime = vol/pV->fillrate;
			}
			curGull->pNext = pV->gullList;
			pV->gullList = curGull;
			curGull++;
			nxtGull++;
			nxtGullX = curGull->x;
			nxtGullY = curGull->y;
		}
	} else {
		while((nxtGull <= nnests) && (nxtGullY >= pV->ymin)) {
			ps = pV->pRSeg;
			xc = ps->critx;
			if((ret = SplineY2XR(nxtGullY, &xc, &ps)) != 0) {
				fprintf(stderr, "find rt x failed for gullat %f\n", nxtGullX);
				return ret;
			}
			if((vol = ValleyArea(nxtGullX, xc, nxtGullY, pV)) < 0.0) {
				fprintf(stderr, "find gull vol failed for gullat %f\n", nxtGullX);
				return -6;
			}
			curGull->pNext = pV->gullList;
			pV->gullList = curGull;
			curGull->baseVol = curGull->remVol = vol;
			curGull->baseTime = vol/pV->fillrate;
			curGull++;
			nxtGull++;
			nxtGullX = curGull->x;
			nxtGullY = curGull->y;
		}
		if((ret = SetGulls(pV->pLChild)) != 0) {
			return ret;
		}
		if((ret= SetGulls(pV->pRChild)) != 0) {
			return ret;
		}
		while((nxtGull <- nnests) && (nxtGullX <= pV->xr)) {
			ps = pV->pLSeg;
			xc = ps->critx;
			if((ret = SplineY2XL(nxtGullY, &xc, &ps)) != 0) {
				fprintf(stderr, "find left x failed for gullat %f\n", nxtGullX);
				return ret;
			}
			if((vol = ValleyArea(xc, nxtGullX, nxtGullY, pV)) < 0.0) {
				fprintf(stderr, "find gull vol failed for gullat %f\n", nxtGullX);
				return -6;
			}
			curGull->pNext = pV->gullList;
			pV->gullList = curGull;
			curGull->baseVol = curGull->remVol = vol;
			curGull->baseTime = vol/pV->fillrate;
			curGull++;
			nxtGull++;
			nxtGullX = curGull->x;
			nxtGullY = curGull->y;
		}
	}
			
	return 0;
}

int VSrtFun(const void *p1, const void *p2)
{
	double t1, t2;
	PVALLEY pv1, pv2;
	pv1 = *(PVALLEY *)p1;
	pv2 = *(PVALLEY *)p2;
	t1 = pv1->baseFillTime;
	t2 = pv2->baseFillTime;
	if(t1 < t2) {
		return 1;
	} else {
		return -1;
	}
}

int SortValleys()
{
	int i;
	for(i = 1; i < nxtValley ; i++) {
		valleyList[i-1] = &(valleys[i]);
	}
	sortCnt = nxtValley - 1;
	qsort(&(valleyList[0]), sortCnt, sizeof(PVALLEY), VSrtFun);
	for(i = 0; i < sortCnt ; i++) {
		valleyList[i]->sortIndex = i;
	}
	remGulls = nnests;
	return 0;
}

void dumpValleys()
{
	PVALLEY pV, pVbase;
	int i;
	pV = pVbase = &(valleys[0]);
	pV++;
	for(i = 1; i < nxtValley; i++, pV++) {
		printf("%d X %0.3f %0.3f Y %0.3f %0.3f V %0.3f Mn %0.3f %0.3f FT %0.3f LC %ld RC %ld\n",
			i, pV->xl, pV->xr, pV->yl, pV->yr, pV->vol, pV->xmin, pV->ymin, pV->baseFillTime, 
			pV->pLChild - pVbase, pV->pRChild - pVbase);
	}
}

int SetValleysGulls()
{
	PVALLEY pVL, pVR;
	int ret;
	curGull = &(gulls[0]);
	nxtGull = 1;
	nxtGullY = curGull->y;
	nxtGullX = curGull->x;
	pVRoot = &(valleys[0]);
	pVL = &(valleys[1]);
	pVR = &(valleys[2]);
	nxtValley = 3;
	pVRoot->pLChild = pVL;
	pVRoot->pRChild = pVR;
	pVL->pOvFValley = pVR;
	pVR->pOvFValley = pVL;
	if((ret = SetValleys(pVL, pVRoot, pLWall, peakRoot)) != 0) {
		return ret;
	}
	if((ret = SetValleys(pVR, pVRoot, peakRoot, pRWall)) != 0) {
		return ret;
	}
#ifdef DB_OUT
	dumpValleys();
#endif
	if((ret = SetGulls(pVL)) != 0) {
		return ret;
	}
	if((ret = SetGulls(pVR)) != 0) {
		return ret;
	}
	return 0;
}

int SetGullHeights()
{
	int i, j;
	double y;
	PGULL pg;
	PSPLINE_SEG ps;
	pg = &gulls[0];
	ps = &spsegs[0];
	for(i = 0, j = 0; i < nnests ; i++, pg++) {
		while((ps->xr < pg->x) && (j < npts)) {
			ps++;
			j++;
		}
		if(j >= npts) {
			fprintf(stderr, "of the end at gull %d in SetGullHeights()\n", i+1);
			return -1;
		}
		y = SplineX2Y(pg->x, ps);
		pg->y = y;
		pg->baseVol = 0.0;
		pg->curTime = 0.0;
		pg->remVol = 0.0;
		pg->floodTime = 0.0;
	}
	return 0;
}

void dumpGulls()
{
	int i;
	PGULL pg = &(gulls[0]);
	printf("\n");
	for(i = 0; i < nnests ; i++, pg++) {
		printf("%d, %f %f V %f T %f\n", i, pg->x, pg->y, pg->baseVol, pg->baseTime);
	}
}

int SetPeaks()
{
	int i;
	PSPLINE_SEG ps;
	PPEAK pp, pt, proot, pprev;
	npeaks = 2;
	maxpky = -1.0e30;
	proot = pprev = NULL;
	ps = pRWallSeg;
	pp = &(peaks[0]);
	pp->x = ps->xl;
	pp->y = ps->yl;
	pp->pSegl = pp->pSegr = ps;
	pRWall = pp;
	pp++;
	ps = &(spsegs[0]);
	pp->x = ps->xl;
	pp->y = ps->yl;
	pp->pSegl = pp->pSegr = ps;
	pLWall = pp;
	pp++; ps++;
	for(i = 1; i < (npts-1); i++, ps++) {
		if((ps->A < 0.0) && (fabs(ps->critx - ps->xr) < EPS)) {
			pp->x = ps->critx; pp->y = ps->crity;
			pp->pSegl = ps;
			ps++; i++;
			pp->pSegr = ps;
		}
		else if((ps->A < 0.00) && (ps->critx > ps->xl) && (ps->critx < ps->xr)) {
			pp->x = ps->critx; pp->y = ps->crity;
			pp->pSegl = pp->pSegr = ps;
		} else {
			continue;
		}
		if(proot == NULL) {
			pp->pLPar = pLWall;
			pp->pRPar = pRWall;
			proot = pp;
			pp->pLeft = NULL;
			pp->pRt = NULL;
		} else {
			if(pp->y <= pprev->y) {
				pp->pLPar = pprev;
				pp->pRPar = pRWall;
				pp->pLeft = NULL;
				pp->pRt = NULL;
				pprev->pRt = pp;
			} else {
				pp->pRPar = pRWall;
				pp->pLeft = pprev;
				pp->pRt = NULL;
				pt = pprev;
				while(pt->y <= pp->y) {
					pt->pRPar = pp;
				}
				pp->pLPar = pt;
			}
		}
		pprev = pp;
		if(pp->y > maxpky) {
			proot = pp;
			maxpky = pp->y;
			maxpkx = pp->x;
			maxpeak = npeaks;
		}
		pp++;
		npeaks++;
	}
	peakRoot = proot;
	return 0;
}

void dumpPeaks()
{
	int i;
	PPEAK pp, pbase;
	printf("\n");
	pp = pbase = &(peaks[0]);
	for(i = 0; i < npeaks; i++, pp++) {
		printf("%d xy %f %f LI %ld RI %ld\n",
			i, pp->x, pp->y, pp->pLeft - pbase, pp->pRt - pbase);
	}
}

double SetSplineSeg(double x1, double y1, double dy1,double x2, double y2, PSPLINE_SEG ps)
{
	double a, b, c, x, dx;
	dx = x2 - x1;
	if(fabs(dx) < EPS) {
		return -1.0e30;
	}
	c = y1; b = dy1; a = (y2 - c - b*dx)/(dx*dx);
	b = (dy1 - 2.0*a*x1);
	c = y1 - a*x1*x1 - b*x1;
	ps->A = a;
	ps->B = b;
	ps->C = c;
	if(x1 < x2) {
		ps->xl = x1; ps->xr = x2; ps->yl = y1; ps->yr = y2;
	} else {
		ps->xl = x2; ps->xr = x1; ps->yl = y2; ps->yr = y1;
	}
	ps->critx = x = -(b/(2.0*a));
	ps->crity = a*x*x + b*x + c;
	if(ps->yl < ps->yr) {
		ps->ymin = ps->yl;
	} else {
		ps->ymin = ps->yr;
	}
	if((ps->crity < ps->ymin) && (ps->critx >= ps->xl) && (ps->critx <= ps->xr)) {
		ps->ymin = ps->crity;
	}
	return (b + 2.0*a*x2);
}

int SetSplines()
{
	int i;
	double prevdy = 0.0;
	PSPLINE_SEG ps;
	pLWallSeg = ps = &(spsegs[0]);
	ps->A = ps->B = 0.0;
	ps->critx =ps->xl = ps->xr = geox[0];
	ps->C = ps->crity = ps->yl = ps->yr = ps->ymin = 1.0e30;
	pRWallSeg = ps = &(spsegs[npts]);
	ps->A = ps->B = 0.0;
	ps->critx =ps->xl = ps->xr = geox[npts-1];
	ps->C = ps->crity = ps->yl = ps->yr = ps->ymin = 1.0e30;
	for(i = inmaxyloc -1; i >= 0; i--) {
		prevdy = SetSplineSeg(geox[i+1], geoy[i+1], prevdy, geox[i], geoy[i], &(spsegs[i+1]));
	}
	prevdy = 0.0;
	for(i = inmaxyloc; i < (npts - 1); i++) {
		prevdy = SetSplineSeg(geox[i], geoy[i], prevdy, geox[i+1], geoy[i+1], &(spsegs[i+1]));
	}
	return 0;
}

void dumpSplines()
{
	int i;
	PSPLINE_SEG ps = &(spsegs[0]);
	for(i =0; i <= npts; i++, ps++) {
		printf("%d %0.3f %0.3f %0.3f %0.3f ABC %0.3f %0.3f %0.3f crit %0.3f %0.3f\n",
			i, ps->xl, ps->xr, ps->yl, ps->yr, ps->A, ps->B, ps->C, ps->critx, ps->crity);
	}
}

char *ScanInt(char *pb, int *pval)
{
	char c;
	int val, stat, sign;
	val = stat = 0; sign = 1;
	while((c = *pb++) != 0){
		if(c == '-') {
			if(stat == 1) {
				*pval = -1000000;
				return NULL;
			}
			sign = -1;
			stat = 1;
		}
		else if((c >= '0') && ( c <= '9')) {
			val = val*10 +  (c - '0');
			stat = 1;
		} else if(stat == 1){
			*pval = sign*val;
			return pb;
		}
	}
	if(stat == 1) {
		*pval = sign*val;
		return pb;
	}
	*pval = -1000001;
	return NULL;
}

int ParseNests(char *pbuf)
{
	int x, i;
	char *pb = pbuf;
	for(i = 0; i < nnests ; i++) {
		if((pb = ScanInt(pb, &x)) == NULL) {
			fprintf(stderr, "ParseError on nest x %d\n", i+1);
			return -23;
		}
		nestx[i] = gulls[i].x = (double)x;
		gulls[i].pNext = NULL;
	}
	return 0;
}

int ParseGeoPts(char *pbuf)
{
	int x, y, i;
	char *pb = pbuf;
	inmaxy= -1000000; inmaxyloc = -1;
	for(i = 0; i < npts ; i++) {
		if((pb = ScanInt(pb, &x)) == NULL) {
			fprintf(stderr, "ParseError on geo x %d\n", i+1);
			return -24;
		}
		if((pb = ScanInt(pb, &y)) == NULL) {
			fprintf(stderr, "ParseError on geo y %d\n", i+1);
			return -25;
		}
		if(y > inmaxy) {
			inmaxy = y;
			inmaxyloc = i;
		}
		geox[i] = (double)x;
		geoy[i] = (double)y;
	}
	return 0;
}

int flag = 0;

int ProcOverflow(PVALLEY pV, PVALLEY pOV, int type, double addRate)
{
	PGULL pG, pPrev;
	PVALLEY pTV;
	int i;
	if(pOV->curFill >= pOV->vol) {	//if ocerflow valley is full try its overflow
		pTV = pOV->pOvFValley;
		if(pTV->curFill >= pTV->vol) { // if other half full (already processed) return
			return 0;
		} else {	// work on complement
			pOV = pTV;
		}
	}
	//now pOV is a not full valley getting overflow from pV
	pOV->curFill += pOV->fillrate*(globTime - pOV->curTime);
	pPrev = NULL;
	pG = pOV->gullList;
	while(pG != NULL) {		//scan gulls
		if(pG->baseVol <= pOV->curFill) { // if gull now flooded figure out when
			pG->floodTime = pG->curTime + pG->remVol/pOV->fillrate;
			remGulls--;	// and remove it from the list
			if(pPrev == NULL) {
				pOV->gullList = pG->pNext;
			} else {
				pPrev->pNext = pG->pNext;
			}
			pG = pG->pNext;
		} else {	// get current fill (remvol) and time wait for next time
			pG->remVol -= pOV->fillrate*(globTime - pG->curTime);
			pG->curTime = globTime;
			pPrev = pG;
			pG = pG->pNext;
		}
	}
	pOV->curTime = globTime;
	pOV->fillrate += addRate;	// add rate from pV
	pOV->baseFillTime = globTime + (pOV->vol - pOV->curFill)/pOV->fillrate;
	// move pOV up in list if necessary
	for(i = pOV->sortIndex + 1; i < sortCnt ; i++) {
		if(valleyList[i]->baseFillTime > pOV->baseFillTime) {
			valleyList[i-1] = valleyList[i];
			valleyList[i-1]->sortIndex = i-1;
		} else break;
	}
	valleyList[i-1] = pOV;
	pOV->sortIndex = i-1;
	if(pOV->pLChild != NULL) { // pOV not full, children also get overflow from pV
		if(type == OV_RT) {
			return ProcOverflow(pOV, pOV->pLChild, type, addRate);
		} else {
			return ProcOverflow(pOV, pOV->pRChild, type, addRate);
		}
	}
	return 0;
}

int ProcNxtValley()
{
	PVALLEY pV, pOvV;
	PGULL pG;
	sortCnt--;
	pV = valleyList[sortCnt];
	pG = pV->gullList;
	globTime = pV->baseFillTime;
	while (pG != NULL) {
		pG->floodTime = pG->curTime + pG->remVol/pV->fillrate;
		remGulls--;
		pG = pG->pNext;
	}
	pV->gullList = NULL;
	pV->curFill = pV->vol;
	if(pV ==  &(valleys[2])) {
		flag++;
	}
	pOvV = pV->pOvFValley;
	if(pOvV == NULL) {
		return 0;
	}
	return ProcOverflow(pV, pOvV, pV->overflowTo, pV->fillrate);
	return 0;
}

char inbuf[1024];
int main()
{
	int ret, i;
	PGULL pG = &(gulls[0]);
	if(fgets(&(inbuf[0]), 1024, stdin) == NULL) {
		fprintf(stderr, "read failed on point count and rain rate\n");
		return -1;
	}
	if(sscanf(&(inbuf[0]), "%d %lf %d", &npts, &rainrate, &nnests) != 3) {
		fprintf(stderr, "scan failed on point count, rain rate and next cnt\n");
		return -2;
	}
	if((npts < 1) || (npts > MAX_PTS)) {
		fprintf(stderr, "point count %d not in range 1 ..%d\n", npts, MAX_PTS);
		return -3;
	}
	inmaxy= -1000000; inmaxyloc = -1;
	if(fgets(&(inbuf[0]), 1024, stdin) == NULL) {
		fprintf(stderr, "read failed on geo points\n");
		return -1;
	}
	if((ret = ParseGeoPts(&(inbuf[0]))) != 0) {
		return ret;
	}
	if(fgets(&(inbuf[0]), 1024, stdin) == NULL) {
		fprintf(stderr, "read failed on nest locations\n");
		return -1;
	}
	if((ret = ParseNests(&(inbuf[0]))) != 0) {
		return ret;
	}
	if((ret = SetSplines()) != 0) {
		return ret;
	}
#ifdef DB_OUT
	dumpSplines();
#endif
	if((ret = SetPeaks()) != 0) {
		return ret;
	}
#ifdef DB_OUT
	dumpPeaks();
#endif
	if((ret = SetGullHeights()) != 0) {
	
		return ret;
	}
#ifdef DB_OUT
	dumpGulls();
#endif
	if((ret = SetValleysGulls()) != 0) {
		return ret;
	}
#ifdef DB_OUT
	dumpGulls();
#endif
	SortValleys();
	globTime = 0.0;
	while((remGulls > 0) && (sortCnt > 0)) {
		if((ret = ProcNxtValley()) != 0) {
			fprintf(stderr, "procvalley ret %d gull %d sort %d\n", ret, remGulls, sortCnt);
			return ret;
		}
	}
	for(i = 0; i < nnests ; i++, pG++){
		printf("%lf\n", pG->floodTime);
	}
	return 0;
}

