import java.util.*;

public class JohnChecker
{
	public static final int MAX_SURVEY = 50;
	public static final int MAX_NESTS = 100;
	public static int exitCode = 42;

	public static void printError(int line, String msg)
	{
		System.out.println("ERROR Line " + line + ": " + msg);
		exitCode = -1;
	}

	public static void checkIntBounds(int x, int min, int max, String name, int nLines)
	{
		if (x < min || x > max)
			printError(nLines, "invalid " + name + " value: " + x);
	}

	public static void checkCharBounds(char x, char min, char max, String name, int nLines)
	{
		if (x < min || x > max)
			printError(nLines, "invalid " + name + " value: " + x);
	}

	public static void checkDoubleBounds(double x, double min, double max, String name, int nLines)
	{
		if (x < min || x > max)
			printError(nLines, "invalid " + name + " value: " + x);
	}

	public static int nextInt(StringTokenizer st)
	{
		return Integer.parseInt(st.nextToken());
	}

	public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		int p=0, m=0;
		double r=0.0;
		String line;
		int nLines=0;

		line = in.nextLine();
		nLines++;
		StringTokenizer st = new StringTokenizer(line);
		if (st.countTokens() != 3)
			printError(nLines, "number of values on line incorrect");

		try {
			p = nextInt(st);
			String rval = st.nextToken();
			r = Double.parseDouble(rval);
			m = nextInt(st);
			checkIntBounds(p, 2, MAX_SURVEY, "p", nLines);
			checkDoubleBounds(r, 0.0, 3.0, "r", nLines);
			int decloc = rval.indexOf(".");
			if (decloc != -1 && rval.length() - decloc > 3) {
				printError(nLines, "r has more than 2 digits after decimal place");
			}
			checkIntBounds(m, 1, MAX_NESTS, "m", nLines);
													// check survey points
			int numvals = 0;
			line = in.nextLine();
			nLines++;
			st = new StringTokenizer(line);
			numvals = st.countTokens();
			if (numvals != 2*p)
				printError(nLines, "number of survey points " + numvals + " is incorret");
			int [] x = new int[numvals/2];
			int [] y = new int[numvals/2];
			for(int i=0; i<numvals; i++) {
				int val = nextInt(st);
				if (i%2 == 0) {
					checkIntBounds(val, 0, 5000, "survey x", nLines);
					x[i/2] = val;

				}
				else {
					checkIntBounds(val, -1000, 1000, "survey y", nLines);
					y[i/2] = val;
				}
			}
			for (int i=1; i<x.length; i++) {
				if (x[i] <= x[i-1])
					printError(nLines, x[i] + " <= " + x[i+1] + " in survey points");
				for(int j=0; j<i; j++) {
					if (y[i] == y[j])
						printError(nLines, y[i] + " value duplicated in survey points");
				}
			}
			for (int i=2; i<x.length; i++) {
				if ((y[i]-y[i-1])*(x[i-1]-x[i-2]) == (y[i-1]-y[i-2])*(x[i]-x[i-1]))
					printError(nLines, "Points with x vals " +x[i-2] + " through " + x[i] + " are colinear");
			}
											// check nest points
			line = in.nextLine();
			nLines++;
			st = new StringTokenizer(line);
			numvals = st.countTokens();
			if (numvals != m)
				printError(nLines, "number of nest points " + numvals + " is incorret");
			int [] nestx = new int[numvals];
			for(int i=0; i<numvals; i++) {
				nestx[i] = nextInt(st);
				checkIntBounds(nestx[i], x[0]+1, x[p-1]-1, "nest x", nLines);
			}
			for (int i=1; i<nestx.length; i++) {
				if (nestx[i] <= nestx[i-1])
					printError(nLines, x[i] + " <= " + x[i+1] + " in survey points");
			}
			int index = 1;
			for (int i=0; i<nestx.length; i++) {
				while (x[index] < nestx[i])
					index++;
				double den = x[index]-x[index-1];
				double nesty = y[index-1] + (y[index]-y[index-1])*(nestx[i] - x[index-1])/den;
				for(int j=0; j<p; j++)
					if (Math.abs(y[j] - nesty) <= 1e-6)
						printError(nLines, i + "th nest point at x = " + nestx[i] + " has y = " + j + "th survey y " + y[j]);
			}
		} catch (Exception e) {
			printError(nLines, "illegal character on line  " + nLines);
		}
		System.exit(exitCode);
	}
}