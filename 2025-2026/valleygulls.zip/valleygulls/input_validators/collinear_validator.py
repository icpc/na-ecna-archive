#!/usr/bin/python3

import sys

"""
This validator only checks the collinearity condition. 

It must be used in conjunction with other validators to check the
other conditions.
Validator author: Finn Lidbetter
"""

def cross(p1, p2, p3):
    dx1 = p2[0] - p1[0]
    dy1 = p2[1] - p1[1]
    dx2 = p3[0] - p1[0]
    dy2 = p3[1] - p1[1]
    return dx1 * dy2 - dy1 * dx2


def main():
    tokens = sys.stdin.readline().split(' ')
    p = int(tokens[0])
    pts = []
    x = None
    y = None
    while len(pts) < p:
        tokens = sys.stdin.readline().split(' ')
        for token in tokens:
            if x is None:
                x = int(token)
            elif y is None:
                y = int(token)
                pts.append((x,y))
                x = None
                y = None
    for p1,p2,p3 in zip(pts[:p-2], pts[1:p-1], pts[2:p]):
        if cross(p1,p2,p3) == 0:
            sys.exit(2)
    sys.exit(42)

if __name__ == '__main__':
    main()

