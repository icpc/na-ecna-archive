// East Division Regional 2025
// Fractional Sequence Solution
// John Buck

import java.util.Scanner;

class FractSeqJTB_RTE {

	public static void main(String [] args) {
		Scanner stdin = new Scanner(System.in);
		double dblidx;
		int N, idx;

		N = Integer.parseInt(stdin.next());

		/*
		 * Normalize to 0 based index
		 */
		N--;

		/*
		 * We'll use the Quadratic formula: (-b + sqrt(b^2 - 4*a*c))/2*a
		 * to solve for the value at the start of the block for index "N"
		 * "N" group starts at 1 + (idx-1)*idx/2 = N
		 * 1 + (idx^2 - idx)/2 = N
		 * 2 + (idx^2 - idx) = 2 * N
		 * 2 + (idx^2 - idx) - 2 * N = 0
		 * (-1*(-1) + Math.sqrt(1 - 4*1*(-2*N))) / (2*1)
		 */
		dblidx = (1.0 + Math.sqrt(1.0 - 4.0*1.0*(-2.0*N))) / (2.0*1.0);
		/*
		 * integer version, which is index of first thing in N group
		 */
		idx = (int)dblidx;

		/*
		 * Subtract off the value at the start of the group.  This will
		 * give us the sub-index into the group
		 */
		N -= ((idx-1) * idx)/2;

		/*
		 * If no remainder, it's the first thing in the block, so no fraction
		 */
		if(N == 0){
			System.out.println("" + idx);
		} else {
			System.out.println("" + idx + " " + N + "/" + idx);
		}
	}
}
