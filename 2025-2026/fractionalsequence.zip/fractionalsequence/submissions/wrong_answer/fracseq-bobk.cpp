#include <cstdint>
#include <iostream>
#include <math.h>

using namespace std;

int main() {
    uint32_t
        n,d;
    double
        a,b,c,
        x1,x2;

    cin >> n;
    n--;

    a = 1.0;
    b = -1.0;
    c = -2.0 * n;

    d = (uint32_t)((-b + sqrt(b * b - 4.0 * a * c)) / (2.0 * a));
    n -= (uint64_t)d * (d - 1) / 2;

    if (n % d == 0)
        cout << d << endl;
    else
        cout << d << ' ' << (n % d) << '/' << d << endl;

    return 0;
}