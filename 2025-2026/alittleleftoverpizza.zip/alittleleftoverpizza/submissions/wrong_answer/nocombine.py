import math

np = int(input().strip())
counts = {'S': 0, 'M': 0, 'L': 0}
tot = 0
for _ in range(np):
    sz, slices = input().strip().split()
    slices = int(slices)
    if slices > 0:
        tot += 1

print(tot)

