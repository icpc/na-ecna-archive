import math

np = int(input().strip())
counts = {'S': 0, 'M': 0, 'L': 0}
for _ in range(np):
    sz, slices = input().strip().split()
    counts[sz] += int(slices)
tot = int(counts['S']/6+counts['M']/8+counts['L']/12)

print(tot)

