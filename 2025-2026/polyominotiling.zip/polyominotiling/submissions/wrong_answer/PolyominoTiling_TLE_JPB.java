import java.util.Scanner;

public class PolyominoTiling_TLE_JPB {

	public static int count;
	//a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z
	public static int[] upVal = {0,0,0,1,0,0,0,0,0,0,0,3,0,0,0,0,0,2,0,0,0,0,0,0,0,0};
	public static int[] lowVal =  {0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,3,0,0,1,0,0,0,0,0};
	public static int PRIME;

	public static int[][] upTable;
	public static int[][] lowTable;

	public static int[] supVal, slowVal;

	public static void main(String[] args) {

		PRIME = 2000000011;
		Scanner in = new Scanner(System.in);
		int len = in.nextInt();
		if (len%2 == 1) {
			System.out.println(0);
			System.exit(0);
		}
		String s = in.next();
		supVal = new int[len/2];
		slowVal = new int[len/2];
		upTable = new int[len/2][len/2];
		lowTable = new int[len/2][len/2];
		int count = 0;
		for(int i=0; i<len; i++) {
			count += countMatches(s, len/2);
			s = s.substring(1) + s.charAt(0);
		}
		System.out.println(count);;
	}

	public static int countMatches(String s, int len)
	{
		char [] sup = s.substring(0, len).toCharArray();
		char [] slow = s.substring(len).toCharArray();
		for(int i=0; i<len; i++) {
			supVal[i] = upVal[sup[i]-'a'];
			slowVal[i] = lowVal[slow[i]-'a'];
		}

		for(int i=0; i<len; i++) {
			upTable[i][i] = supVal[i];
//			System.out.printf("%7d", upTable[i][i]);
			for(int j=i+1; j<len; j++) {
				upTable[i][j] = (4*upTable[i][j-1] + supVal[j]) % PRIME;
//				System.out.printf("%7d", upTable[i][j]);
			}
//			System.out.println();
		}
		for(int i=0; i<len; i++) {
			lowTable[i][i] = slowVal[i];
//			System.out.printf("%7d", lowTable[i][i]);
			int mult = 1;
			for(int j=i+1; j<len; j++) {
				mult = (mult*4)%PRIME;
				lowTable[i][j] = (lowTable[i][j-1] + mult*slowVal[j]) % PRIME;
//				System.out.printf("%7d", lowTable[i][j]);
			}
//			System.out.println();
		}
		// check for X Y Xbar Ybar and X Y Z Xbar Ybar Zbar
		int count = 0;
		for(int j=0; j<len-1; j++) {
			if (upTable[0][j] == lowTable[0][j] && checkForMatch(0,j,len)) {
				if (upTable[j+1][len-1] == lowTable[j+1][len-1] && checkForMatch(j+1, len-1, len)) {
					count++;
//					System.out.println(0 + "-" + j + " " + (j+1) + "-" + (len-1));
				}
				for(int k=j+1; k<len-1; k++) {
					if (upTable[j+1][k] == lowTable[j+1][k] && checkForMatch(j+1, k, len) &&
							upTable[k+1][len-1] == lowTable[k+1][len-1] && checkForMatch(k+1, len-1, len)) {
						count++;
//						System.out.println(0 + "-" + j + " " + (j+1) + "-" + k + " " + (k+1) + "-" + (len-1));
					}
				}
			}
		}
		return count;

	}
	public static boolean checkForMatch(int start, int stop, int k)
	{
		int lowStart = stop;
		for(int i=start; i<=stop; i++) {
			if (supVal[i] != slowVal[lowStart])
				return false;
			lowStart--;
		}
		return true;
	}
}
