/**
 * Brute force implementation. Try each starting position for X,
 * and each possible length for X and Y. Then validate if the factorisation
 * has the desired backtrack property.
 *
 * This implementation has time complexity O(n^4)
 *
 * @author Finn Lidbetter
 */

import java.io.*;
import java.util.*;

public class brute_force{
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int solutionCount = 0;
        char[] seq = br.readLine().split(" ")[1].toCharArray();
        int n = seq.length;
        for (int xStart=0; xStart<n; xStart++) {
            for (int xLen=0; 2 * xLen<=n-4; xLen++) {
                for (int yLen=1; 2*(yLen+xLen)<=n-2; yLen++) {
                    int yStart = (xStart + xLen) % n;
                    int zStart = (yStart + yLen) % n;
                    int zLen = (n - (2 * (xLen + yLen))) / 2;
                    int xBarStart = (zStart + zLen) % n;
                    int xBarEnd = (xBarStart + xLen - 1 + n) % n;
                    int yBarStart = (xBarStart + xLen) % n;
                    int yBarEnd = (yBarStart + yLen - 1 + n) % n;
                    int zBarStart = (yBarStart + yLen) % n;
                    int zBarEnd = (zBarStart + zLen - 1 + n) % n;
                    boolean valid = true;
                    for (int i=0; i<xLen; i++) {
                        if (!isComplement(seq[(xStart + i) % n], seq[(xBarEnd - i + n) % n])) {
                            valid = false;
                            break;
                        }
                    }
                    if (!valid) {
                        continue;
                    }
                    for (int i=0; i<yLen; i++) {
                        if (!isComplement(seq[(yStart + i) % n], seq[(yBarEnd - i + n) % n])) {
                            valid = false;
                            break;
                        }
                    }
                    if (!valid) {
                        continue;
                    }
                    for (int i=0; i<zLen; i++) {
                        if (!isComplement(seq[(zStart + i) % n], seq[(zBarEnd - i + n) % n])) {
                            valid = false;
                            break;
                        }
                    }
                    if (valid) {
                        solutionCount++;
                    }
                }
            }
        }
        System.out.println(solutionCount);
    }
    static boolean isComplement(char c1, char c2) {
        if (c1 == 'u') {
            return c2 == 'd';
        }
        if (c1 == 'd') {
            return c2 == 'u';
        }
        if (c1 == 'l') {
            return c2 == 'r';
        }
        if (c1 == 'r') {
            return c2 == 'l';
        }
        return false;
    }
}
