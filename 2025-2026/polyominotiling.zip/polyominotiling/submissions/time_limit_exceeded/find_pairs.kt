/**
 * First, find pairs X, XBar where the number of characters between
 * X and XBar is equal to the number of characters between XBar and X.
 * Then iterate over each such pair. Check if we can factorize as XYXY
 * in O(1) and then check if we can factorize as XYZXYZ in O(n) by
 * trying each possible position to split.
 * Time complexity O(n^3).
 *
 * @author Finn Lidbetter
 */


const val MOD: Long = 1_000_000_007
const val MOD_INV_4: Long = 250_000_002

fun main() {
    val tokens = readLine()!!.split(" ")
    val n = tokens[0].toInt()
    val seq = tokens[1].toCharArray()
    println(solve(seq))
}

fun solve(seq: CharArray): Int {
    val n = seq.size
    var pseudoSquareCount = 0
    var pseudoHexagonCount = 0
    val backtrackPairs = findPairs(seq)
    for (xStartIndex in 0..n-1) {
        for (xLen in 1..(n/2)-1) {
            if (!backtrackPairs[xStartIndex][xLen]) {
                continue
            }
            val yStartIndex = (xStartIndex + xLen) % n
            val squareYLen = (n - 2 * xLen) / 2
            if (backtrackPairs[xStartIndex][xLen] && backtrackPairs[yStartIndex][squareYLen]) {
                pseudoSquareCount++
            }
            for (yLen in 1..(n - 2 * xLen - 2) / 2) {
                val zStartIndex = (yStartIndex + yLen) % n
                val zLen = (n - 2*(xLen + yLen)) / 2
                if (backtrackPairs[yStartIndex][yLen] && backtrackPairs[zStartIndex][zLen]) {
                    pseudoHexagonCount++
                }
            }
        }
    }
    //println("pseudoSquareCount: $pseudoSquareCount, pseudoHexagonCount: $pseudoHexagonCount")
    return pseudoSquareCount + pseudoHexagonCount
}

/**
 * Return an array pairs[i][j] where pairs[i][j] is True iff the string of length j
 * from index i has a backtrack equal to the substring of length j starting at
 * index (i + (n/2)) % n.
 */
fun findPairs(seq: CharArray): Array<BooleanArray> {
    val n = seq.size
    var result = Array(n) {
        BooleanArray(n)
    }
    var seqLong = seq.map { it ->
        mappedValue(it)
    }
    var seqComplementLong = seq.map { it ->
        mappedValue(complement(it))
    }
    var pows = LongArray(n)
    pows[0] = 1
    for (i in 1..n-1) {
        pows[i] = (pows[i-1] * 4) % MOD
    }
    for (j in 1..(n/2)-1) {
        //println("Length $j")
        var forwardHashes = LongArray(n)
        var currHash = 0L
        for (k in 0..j-1) {
            currHash *= 4
            currHash += seqLong[k]
            currHash %= MOD
        }
        forwardHashes[0] = currHash
        for (i in 1..n-1) {
            currHash -= (pows[j - 1] * seqLong[i - 1]) % MOD
            currHash = (currHash + MOD) % MOD
            currHash *= 4
            currHash += seqLong[(i + j - 1) % n]
            currHash %= MOD
            forwardHashes[i] = currHash
        }
        var backtrackHashes = LongArray(n)
        currHash = 0L
        for (k in 0..j-1) {
            val index = j - k - 1
            currHash *= 4
            currHash += seqComplementLong[index]
            currHash %= MOD
        }
        backtrackHashes[0] = currHash
        for (i in 1..n-1) {
            currHash -= seqComplementLong[i - 1]
            currHash = (currHash + MOD) % MOD
            currHash *= MOD_INV_4
            currHash %= MOD
            currHash += (pows[j - 1] * seqComplementLong[(i + j - 1) % n]) % MOD
            currHash %= MOD
            backtrackHashes[i] = currHash
        }
        /*
        println("Forward Hashes")
        println(forwardHashes.joinToString())
        println("Backtrack Hashes")
        println(backtrackHashes.joinToString())
        */
        for (i in 0..n-1) {
            if (forwardHashes[i] == backtrackHashes[(i + (n/2)) % n]) {
                result[i][j] = true
            }
        }
    }
    /*
    for (resultRow in result) {
        println(resultRow.joinToString())
    }
     */
    return result
}

fun complement(ch: Char): Char {
    if (ch == 'u') {
        return 'd'
    }
    if (ch == 'd') {
        return 'u'
    }
    if (ch == 'r') {
        return 'l'
    }
    if (ch == 'l') {
        return 'r'
    }
    return '0'
}

fun mappedValue(ch: Char): Long {
    if (ch == 'u') {
        return 0
    }
    if (ch == 'd') {
        return 1
    }
    if (ch == 'r') {
        return 2
    }
    if (ch == 'l') {
        return 3
    }
    return 987654321
}
