#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

signed char code[26] =
{-1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 2, -1, 
 -1, -1, -1, -1, 3, -1, -1, 4, -1, -1, -1, -1, -1
};

char instr[40000], fliprev[40000];
int counts[5];

char inv[5] = {0, 4, 3, 2, 1};
int k, inlen, hlen, inr, inl, flipr, flipl, midlen;

int ReadInt()
{
	char c;
	int r;
	c = getc(stdin);
	while(isspace(c)) {
		c = getc(stdin);
	}
	if(!isdigit(c)) {
		return -1;
	}
	r = c - '0';
	c = getc(stdin);
	while(isdigit(c)) {
		r = 10*r + (c - '0');
		c = getc(stdin);
	}
	return r;
}

int ReadString(int len)
{
	int i;
	char cd, c;
	for(i = 0; i < 5; i++) counts[i] = 0;
	c = getc(stdin);
	while(isspace(c)) {
		c = getc(stdin);
	}
	i = 0;
	while((i < len) && islower(c)) {
		if((cd = code[c - 'a']) < 0) {
			fprintf(stderr, " char %d: %c not valid\n", i+1, c);  
			return -3;
		}
		instr[i] = instr[i + len] = instr[i + 2*len] = instr[i + 3*len] = cd;
		counts[cd]++;
		i++;
		c = getc(stdin);
	}
	if(i < len) {
		fprintf(stderr, "num in chars %d < len %d\n", i, len);
		return -4;
	}
	return 0;
}

int CheckSides()
{
	char icd, fcd;
	int i, j, k, m, n,l, remlen, len3, ok, count = 0;
	// scan in rt flip left
	icd = instr[inr+1]; fcd = fliprev[flipl-1];
	i = inr+1; j = flipl - 1;
	remlen = hlen - midlen;
	for(k =1; k <= remlen ; k++, i++, j--) {
		if((instr[i] == fcd) && (fliprev[j] == icd)) {
			ok = 1;
			for(l = 0, m = inr + 2, n = j+1; l < k-2 ; l++, m++, n++) {
				if(instr[m] != fliprev[n]) {
					ok = 0;
					break;
				}
			}
			if(ok) {
				if(k == remlen) {
					count += 4;
				} else {
					len3 = remlen - k;
					for(l = 0, m = inl - len3, n = flipr +1; l < len3; l++, m++, n++) {
						if(instr[m] != fliprev[n]) {
							ok = 0;
							break;
						}
					}
					if(ok) {
						count += 6;
					}
				}
			}
		}
	}
	return count;
}

int CheckMatch(int flipbase)
{
	int i, j;
	//see how wide the match is
	i = inlen + hlen; j = flipbase;
	while((i < 2*inlen) && (instr[i] == fliprev[j])) {
		i++;
		j++;
	}
	inr = i- 1; flipr = j-1;
	i = inlen + hlen; j = flipbase;
	while((i > inlen) && (instr[i] == fliprev[j])){
		i--;
		j--;
	}
	inl = i+1; flipl = j+1;
	midlen = inr - inl + 1;
	if(midlen >= hlen) {
		return 0;
	}

	return CheckSides();
}

int main()
{
	int i, j, ret, count;
	char cd;
	if((inlen = ReadInt()) <= 0)  return (inlen - 1);
	if(inlen  > 10000) {
		fprintf(stderr, "inlen %d > 10000\n", inlen);
		return -1;
	}
	if(inlen  & 1) {
		fprintf(stderr, "inlen %d is odd\n", inlen);
		return -1;
	}
	hlen = inlen/2;
	if((ret = ReadString(inlen)) < 0) return ret;
	if((counts[1] != counts[4]) || (counts[2] != counts[3])) {
		fprintf(stderr, "dcnt %d ! = ucnt %d and/or lcnt %d != rcnt %d\n",
			counts[1], counts[4], counts[2], counts[3]);
	}
	for(i = 0, j = 4*inlen-1; i < 4*inlen ; i++, j--) {
		fliprev[j] = 5 -instr[i];
	}
	count = 0;
	cd = instr[inlen + hlen];
	for(i = inlen; i <2*inlen; i++) {
		if(cd == fliprev[i]) {
			count += CheckMatch(i);
		}
	}
	printf("%d\n", count);
#ifdef NOTDEF
	for(i = 0; i < inlen ; i++) {
		printf("%d ", instr[i]);
	}
	printf("\n");
	for(i = 0; i < inlen ; i++) {
		printf("%d ", fliprev[i]);
	}
	printf("\n");
	for(i = 1; i < 5; i++) {
		printf("\t%d: %d", i, counts[i]);
	}
	printf("\n");
#endif
	return 0;
}

