/**
 * Separately find the xyxy factorizations and xyzxyz factorizations.
 *
 * For the xyxy case, using a rolling hash to find the substrings
 * x and xBar where the number of characters between x and xBar is
 * equal to the number of characters between xBar and x. If the
 * strings formed between x and xBar and between xBar and x also
 * satisfy the property then we have an xyxy factorization.
 *
 * For the xyzxyz case we use the method of Gambini, Vuillon 2007.
 *
 * Assume that X will contain the first letter. We will multiply
 * our final answer by 6 to account for the cyclic rotations.
 *
 * First we find a pair, (X', XBar') of maximal length to get a factorization
 *    X U XBar V
 *
 * Assume that there is a factorization X Y Z XBar YBar ZBar where |X'|>|X|.
 * Then we can write X' = LXR (where at least one of L,R is nonempty) there is
 * some Y' such that X Y Z XBar YBar ZBar = X R Y' Z' RBar XBar LBar YBar' ZBar' L.
 * This gives
 *      Y = R Y'
 *      Z = Z' RBar.
 * Thus
 *      YBar = YBar' RBar
 *      ZBar = R ZBar'
 * We use this to rebuild X Y Z XBar YBar ZBar as
 *   X Y Z XBar YBar' RBar R ZBar'
 * But this gives
 *    RBar R
 * as a factor. This is impossible because the last letter of RBar is equal to
 * the complement of the first letter of R. So we have one of 'rl','lr','ud','du'
 * in the boundary string. This is impossible by the definition of the polyomino.
 *
 * So any factorization must have (X', XBar') of maximal length.
 *
 * So we have a factorization X' U XBar' V. We are only interested in continuing if |U| == |V|.
 * We then want to check if we can factorize U such that U = Y Z and V = YBar ZBar.
 * If such a factorization exists then it is provided by an occurrence of
 *    UBar = ZBar YBar
 * in
 *   V V = YBar ZBar YBar ZBar
 * So compute UBar and V V and use the Knuth-Morris-Pratt algorithm to count such occurrences.
 * Each occurrence corresponds to a different factorization U = Y Z.
 * Note that we need to exclude the case where Y or Z is empty, i.e., UBar = V.
 *
 * @author Finn Lidbetter
 */


const val MOD: Long = 1_000_000_007
const val MOD_INV_4: Long = 250_000_002
const val MOD2: Long = 100_000_007
const val MOD2_INV_4: Long = 25_000_002


fun main() {
    val tokens = readLine()!!.split(" ")
    val n = tokens[0].toInt()
    val seq = tokens[1].toCharArray()
    println(solve(seq))
}

fun solve(seq: CharArray): Int {
    val n = seq.size
    var pseudoSquareCount = 0
    var pseudoHexagonCount = 0
    val backtrackPairs = findPairs(seq)
    // Count pseudo-squares
    for (xStartIndex in 0..n-1) {
        for (xLen in 1..(n/2)-1) {
            val yStartIndex = (xStartIndex + xLen) % n
            val yLen = (n - 2 * xLen) / 2
            if (backtrackPairs[xStartIndex][xLen] && backtrackPairs[yStartIndex][yLen]) {
                pseudoSquareCount++
            }
        }
    }
    val zeroComplement = complement(seq[0])
    // Count pseudo-hexagons
    for (xBarIndex in 1..n-1) {
        if (seq[xBarIndex] != zeroComplement) {
            continue
        }
        var xL = 0
        var xR = 0
        var xBarL = xBarIndex
        var xBarR = xBarIndex
        // Expand to the left.
        while (seq[(xL - 1 + n) % n] == complement(seq[(xBarR + 1) % n])) {
            xL--
            xBarR++
            xL = (xL + n) % n
            xBarR %= n
        }
        // Expand to the right.
        while (seq[(xR + 1) % n] == complement(seq[(xBarL - 1 + n) % n])) {
            xR++
            xBarL--
            xR %= n
            xBarL = (xBarL + n) % n
        }
        // We have a factorization: X U XBar V
        var uL = (xR + 1) % n
        var uR = (xBarL - 1 + n) % n
        var vL = (xBarR + 1) % n
        var vR = (xL - 1 + n) % n
        var uLen = uR - uL + 1
        var vLen = vR - vL + 1
        if (uLen <= 0) {
            uLen += n
        }
        if (vLen <= 0) {
            vLen += n
        }
        if (uLen != vLen) {
            continue
        }

        // var uArray = CharArray(uLen) { '0' }
        var uComplementArray = CharArray(uLen) { '0' }
        for (uIndex in 0..uLen - 1) {
            uComplementArray[uIndex] = complement(seq[(uL + uIndex) % n])
            // uArray[uIndex] = seq[(uL + uIndex) % n]
        }
        val uBar = uComplementArray.reversed().joinToString("")
        // val u = uArray.joinToString("")
        var vvArray = CharArray(vLen * 2) { '0' }
        for (vvIndex in 0..2*vLen - 1) {
            vvArray[vvIndex] = seq[(vL + (vvIndex % vLen)) % n]
        }
        val vv = vvArray.joinToString("")

        /*
        var xLen = xR - xL + 1
        if (xLen <= 0) {
            xLen += n
        }
        var xArray = CharArray(xLen) { '0' }
        for (xIndex in 0..xLen - 1) {
            xArray[xIndex] = seq[(xL + xIndex) % n]
        }
        val x = xArray.joinToString("")
        var xBarLen = xBarR - xBarL + 1
        var xBarArray = CharArray(xLen) { '0' }
        for (xBarStrIndex in 0..xBarLen - 1) {
            xBarArray[xBarStrIndex] = seq[(xBarL + xBarStrIndex) % n]
        }
        val xBar = xBarArray.joinToString("")
        val v = vv.slice(0..vLen-1)
        println("x u xBar v: $x $u $xBar $v. uBar: $uBar, vv: $vv")
         */
        pseudoHexagonCount += 6 * kmp(vv, uBar)
        if (uBar==vv.slice(0..vLen-1)) {
            // Subtract 12 for the pseudo-hexagons that are actually pseduo-squares.
            pseudoHexagonCount -= 12
        }
    }
    //println("pseudoSquareCount: $pseudoSquareCount, pseudoHexagonCount: $pseudoHexagonCount")
    return pseudoSquareCount + pseudoHexagonCount
}

fun kmp(txt: String, pat: String): Int {
    val m: Int = pat.length
    val n: Int = txt.length
    var i = 0
    var j = 0
    var count = 0
    val arr = kmpHelper(pat, m)
    while (i < n) {
        if (pat[j] == txt[i]) {
            j++
            i++
        }
        if (j == m) {
            count++ // match at i-j
            j = arr[j - 1]
        } else if (i < n && pat[j] != txt[i]) {
            if (j != 0) j = arr[j - 1]
            else i = i + 1
        }
    }
    return count
}

fun kmpHelper(pat: String, m: Int): IntArray {
    val arr = IntArray(m)
    var i = 1
    var len = 0
    while (i < m) {
        if (pat[i] == pat[len]) {
            arr[i++] = ++len
        } else {
            if (len > 0) len = arr[len - 1]
            else i++
        }
    }
    return arr
}

/**
 * Return an array pairs[i][j] where pairs[i][j] is True iff the string of length j
 * from index i has a backtrack equal to the substring of length j starting at
 * index (i + (n/2)) % n.
 */
fun findPairs(seq: CharArray): Array<BooleanArray> {
    val n = seq.size
    var result = Array(n) {
        BooleanArray(n)
    }
    var seqLong = seq.map { it ->
        mappedValue(it)
    }
    var seqComplementLong = seq.map { it ->
        mappedValue(complement(it))
    }
    var pows1 = LongArray(n)
    var pows2 = LongArray(n)
    pows1[0] = 1
    pows2[0] = 1
    for (i in 1..n-1) {
        pows1[i] = (pows1[i-1] * 4) % MOD
        pows2[i] = (pows2[i-1] * 4) % MOD2
    }
    for (j in 1..(n/2)-1) {
        //println("Length $j")
        var forwardHashes1 = LongArray(n)
        var forwardHashes2 = LongArray(n)
        var currHash1 = 0L
        var currHash2 = 0L
        for (k in 0..j-1) {
            currHash1 *= 4
            currHash1 += seqLong[k]
            currHash1 %= MOD
            currHash2 *= 4
            currHash2 += seqLong[k]
            currHash2 %= MOD2
        }
        forwardHashes1[0] = currHash1
        forwardHashes2[0] = currHash2
        for (i in 1..n-1) {
            currHash1 -= (pows1[j - 1] * seqLong[i - 1]) % MOD
            currHash1 = (currHash1 + MOD) % MOD
            currHash1 *= 4
            currHash1 += seqLong[(i + j - 1) % n]
            currHash1 %= MOD
            forwardHashes1[i] = currHash1
            
            currHash2 -= (pows2[j - 1] * seqLong[i - 1]) % MOD2
            currHash2 = (currHash2 + MOD2) % MOD2
            currHash2 *= 4
            currHash2 += seqLong[(i + j - 1) % n]
            currHash2 %= MOD2
            forwardHashes2[i] = currHash2
        }
        var backtrackHashes1 = LongArray(n)
        var backtrackHashes2 = LongArray(n)
        currHash1 = 0L
        currHash2 = 0L
        for (k in 0..j-1) {
            val index = j - k - 1
            currHash1 *= 4
            currHash1 += seqComplementLong[index]
            currHash1 %= MOD
            
            currHash2 *= 4
            currHash2 += seqComplementLong[index]
            currHash2 %= MOD2
        }
        backtrackHashes1[0] = currHash1
        backtrackHashes2[0] = currHash2
        for (i in 1..n-1) {
            currHash1 -= seqComplementLong[i - 1]
            currHash1 = (currHash1 + MOD) % MOD
            currHash1 *= MOD_INV_4
            currHash1 %= MOD
            currHash1 += (pows1[j - 1] * seqComplementLong[(i + j - 1) % n]) % MOD
            currHash1 %= MOD
            backtrackHashes1[i] = currHash1
            
            currHash2 -= seqComplementLong[i - 1]
            currHash2 = (currHash2 + MOD2) % MOD2
            currHash2 *= MOD2_INV_4
            currHash2 %= MOD2
            currHash2 += (pows2[j - 1] * seqComplementLong[(i + j - 1) % n]) % MOD2
            currHash2 %= MOD2
            backtrackHashes2[i] = currHash2
        }
        /*
        println("Forward Hashes")
        println(forwardHashes.joinToString())
        println("Backtrack Hashes")
        println(backtrackHashes.joinToString())
        */
        for (i in 0..n-1) {
            if (forwardHashes1[i] == backtrackHashes1[(i + (n/2)) % n] && forwardHashes2[i] == backtrackHashes2[(i+(n/2)) % n]) {
                result[i][j] = true
            }
        }
    }
    /*
    for (resultRow in result) {
        println(resultRow.joinToString())
    }
     */
    return result
}

fun complement(ch: Char): Char {
    if (ch == 'u') {
        return 'd'
    }
    if (ch == 'd') {
        return 'u'
    }
    if (ch == 'r') {
        return 'l'
    }
    if (ch == 'l') {
        return 'r'
    }
    return '0'
}

fun mappedValue(ch: Char): Long {
    if (ch == 'u') {
        return 0
    }
    if (ch == 'd') {
        return 1
    }
    if (ch == 'r') {
        return 2
    }
    if (ch == 'l') {
        return 3
    }
    return 987654321
}
