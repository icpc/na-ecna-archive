#!/usr/bin/python3

import argparse
import random
import sys
from enum import Enum


INV_MAP = {'u': 'd', 'd': 'u', 'l': 'r', 'r': 'l'}

class TestCaseType(Enum):
    STAIRCASE = 'staircase'
    PSEUDO_SQUARE = 'pseudo_square'
    PSEUDO_HEX = 'pseudo_hex'

    def __str__(self):
        return self.value


K_MIN = 4
K_MAX = 10000
DEFAULT_K = 40
# We will reseed this with the provided seed or a random seed.
RNG = random.Random(0)


def bounded_int(string, val_min, val_max, name='Value'):
    value = int(string)
    if value < val_min or value > val_max:
        raise argparse.ArgumentTypeError(f'{name} must be in range [{val_min}, {val_max}]')
    return value


def bounded_k(string):
    return bounded_int(string, K_MIN, K_MAX, 'k')


def _parse_args():
    parser = argparse.ArgumentParser('')
    parser.add_argument(
        'k',
        type=bounded_k,
        default=DEFAULT_K,
        help='The value of k.'
    )
    parser.add_argument(
        '--test-case-type',
        type=TestCaseType,
        choices=list(TestCaseType),
        default=TestCaseType.STAIRCASE,
        help='Test case type.',
    )
    parser.add_argument(
        '--seed', type=int, default=random.randint(0, 10000),
        help='The random number to seed the random number generator with.'
    )
    parser.add_argument(
        '--test-name', type=str,
        help='The name for the test case. E.g., "025-small-cases" will produce files '
             '025-small-cases.in and 025-small-cases.desc. If no name is specified, '
             'output will be printed to stdout.'
    )
    return parser.parse_args()


def _validate_with_context(args):
    """Function for any validation that involves more than one argument."""
    assert args.k % 2 == 0, "k must be even"
    if args.test_case_type is TestCaseType.STAIRCASE:
        assert args.k % 4 == 2 and args.k >= 6, "staircase test requires k%4==2 and k>=6"


def _generate_staircase(k):
    size = (k - 2) // 4
    staircase_str =  "ur" * size + "r" + "dl" * size + "l"
    return f"{k} {staircase_str}"

def _valid_path(step_str):
    x, y = 0, 0
    positions = set()
    for step in step_str:
        if step == 'u':
            y += 1
        elif step == 'd':
            y -= 1
        elif step == 'l':
            x -= 1
        elif step == 'r':
            x += 1
        if (x, y) in positions:
            return False
        positions.add((x, y))
    if x != 0 or y != 0:
        return False
    return True

def _generate_pseudo_square(k):
    x_len = RNG.randint(1, (k-2) // 2)
    y_len = (k - 2 * x_len) // 2
    x = ''.join(RNG.choice(['u', 'r']) for _ in range(x_len))
    y = ''.join(RNG.choice(['d', 'r']) for _ in range(y_len))
    x_bar = x.replace('u', 'd').replace('r', 'l')[::-1]
    y_bar = y.replace('d', 'u').replace('r', 'l')[::-1]
    path = f"{x}{y}{x_bar}{y_bar}"
    loop_count = 0
    while not _valid_path(path):
        x = ''.join(RNG.choice(['u', 'r']) for _ in range(x_len))
        y = ''.join(RNG.choice(['d', 'r']) for _ in range(y_len))
        x_bar = x.replace('u', 'd').replace('r', 'l')[::-1]
        y_bar = y.replace('d', 'u').replace('r', 'l')[::-1]
        path = f"{x}{y}{x_bar}{y_bar}"
        loop_count += 1
    return f"{k} {path}"

def _generate_pseudo_hex(k):
    half_k = k // 2
    indices = [i for i in range(half_k - 1)]
    split_points = RNG.sample(indices, 2)
    split_points.sort()
    x_len = split_points[0] + 1
    y_len = split_points[1] - split_points[0]
    z_len = half_k - 1 - split_points[1]
    change_index = RNG.randint(0, half_k - 1)
    x_arr = []
    y_arr = []
    z_arr = []
    for i in range(half_k):
        if i < change_index:
            ch = RNG.choice(['u', 'r'])
        else:
            ch = RNG.choice(['r', 'd'])
        if i < x_len:
            x_arr.append(ch)
        elif i < y_len:
            y_arr.append(ch)
        else:
            z_arr.append(ch)
    x = ''.join(x_arr)
    y = ''.join(y_arr)
    z = ''.join(z_arr)
    x_bar = ''.join([INV_MAP[ch] for ch in reversed(x)])
    y_bar = ''.join([INV_MAP[ch] for ch in reversed(y)])
    z_bar = ''.join([INV_MAP[ch] for ch in reversed(z)])
    path = f"{x}{y}{z}{x_bar}{y_bar}{z_bar}"
    loop_count = 0
    while not _valid_path(path):
        indices = [i for i in range(half_k - 1)]
        split_points = RNG.sample(indices, 2)
        split_points.sort()
        x_len = split_points[0] + 1
        y_len = split_points[1] - split_points[0]
        z_len = half_k - 1 - split_points[1]
        change_index = RNG.randint(0, half_k - 1)
        x_arr = []
        y_arr = []
        z_arr = []
        for i in range(half_k):
            if i < change_index:
                ch = RNG.choice(['u', 'r'])
            else:
                ch = RNG.choice(['r', 'd'])
            if i < x_len:
                x_arr.append(ch)
            elif i < y_len :
                y_arr.append(ch)
            else:
                z_arr.append(ch)
        x = ''.join(x_arr)
        y = ''.join(y_arr)
        z = ''.join(z_arr)
        x_bar = ''.join([INV_MAP[ch] for ch in reversed(x)])
        y_bar = ''.join([INV_MAP[ch] for ch in reversed(y)])
        z_bar = ''.join([INV_MAP[ch] for ch in reversed(z)])
        path = f"{x}{y}{z}{x_bar}{y_bar}{z_bar}"
        loop_count += 1
    return f"{k} {path}"

def generate_output_lines(args):
    """Function to generate a list of output lines."""
    if args.test_case_type is TestCaseType.STAIRCASE:
        return [_generate_staircase(args.k)]
    elif args.test_case_type is TestCaseType.PSEUDO_SQUARE:
        return [_generate_pseudo_square(args.k)]
    elif args.test_case_type is TestCaseType.PSEUDO_HEX:
        return [_generate_pseudo_hex(args.k)]
    return []


def main():
    global RNG
    args = _parse_args()
    _validate_with_context(args)
    RNG = random.Random(args.seed)

    output_lines = generate_output_lines(args)

    output = '\n'.join(output_lines) + '\n'
    command = ' '.join(sys.argv)
    if '--seed' not in sys.argv:
        command += f' --seed {args.seed}'
    if args.test_name is not None:
        test_input_file_name = args.test_name + '.in'
        test_desc_file_name = args.test_name + '.desc'
        with open(test_input_file_name, 'w') as test_input_file:
            test_input_file.write(output)
        with open(test_desc_file_name, 'w') as test_desc_file:
            test_desc_file.write(f'Produced by:\n\t{command}\n')
    else:
        sys.stdout.write(output)


if __name__ == '__main__':
    main()
